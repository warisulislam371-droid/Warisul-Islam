export interface Vendor {
  id: string;
  businessName: string;
  ownerName: string;
  mobile: string;
  email: string;
  gstNumber?: string;
  panNumber?: string;
  tradeLicense: string; // mandatory document url/mock name
  businessAddress: string;
  bankDetails?: {
    accountName: string;
    accountNumber: string;
    bankName: string;
    ifscCode: string;
  };
  status: 'Pending' | 'Approved' | 'Rejected' | 'Suspended';
  rating: number;
  productCount: number;
  logoUrl?: string;
  verified: boolean;
  commissionRate?: number; // vendor-specific override (percentage)
  trustLevel?: 'Pending Verification' | 'Verified' | 'Premium Verified' | 'Trusted Seller';
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  brand: string;
  description: string;
  imageUrl: string;
  stock: number;
  mrp: number; // Maximum Retail Price (MRP)
  vendorPrice: number; // The amount the vendor wants to receive
  gstRate?: number; // GST rate (optional)
  moq: number; // Minimum Order Quantity (MOQ)
  sellingPrice: number; // Vendor's price (receives this) - kept for backward compatibility (equals vendorPrice)
  commissionPercent: number; // e.g. 10%
  customerPrice: number; // Calculated Automatically
  customerPriceOverride?: number; // Manual pricing override set by Super Admin
  vendorId: string;
  vendorName: string;
  rating: number;
  discountPercent?: number; // Calculated automatically based on MRP and customerPrice
  approved: boolean; // Must be approved by Admin
}

export interface OrderItem {
  productId: string;
  productName: string;
  vendorId: string;
  vendorName: string;
  quantity: number;
  unitPrice: number; // Customer price at order time
  sellingPrice: number; // Vendor selling price
  commissionAmount: number; // Admin commission
  total: number;
}

export type OrderStatus =
  | 'Pending'
  | 'Confirmed'
  | 'Processing'
  | 'Packed'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled'
  | 'Returned'
  | 'Refunded';

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  billingDetails: {
    name: string;
    mobile: string;
    email: string;
    address: string;
    state: string;
    city: string;
    pinCode: string;
  };
  paymentMethod: string;
  paymentStatus: 'Pending' | 'Paid' | 'Refunded';
  items: OrderItem[];
  subtotal: number; // Sum of customer price * qty
  discount: number;
  total: number; // Subtotal - Discount
  status: OrderStatus;
  createdAt: string;
  courierName?: string;
  trackingNumber?: string;
}

export interface Review {
  id: string;
  productId: string;
  productName: string;
  customerName: string;
  rating: number;
  comment: string;
  createdAt: string;
  approved: boolean;
}

export interface Coupon {
  id: string;
  code: string;
  type: 'Percentage' | 'Fixed';
  value: number;
  minPurchase: number;
  active: boolean;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  userRole: 'Customer' | 'Vendor';
  subject: string;
  category: string;
  status: 'Open' | 'Replied' | 'Closed';
  createdAt: string;
  messages: {
    sender: 'User' | 'Admin';
    text: string;
    timestamp: string;
  }[];
}

export interface WalletTransaction {
  id: string;
  type: 'Credit' | 'Debit';
  amount: number;
  description: string;
  date: string;
}

export interface WithdrawalRequest {
  id: string;
  vendorId: string;
  vendorName: string;
  amount: number;
  bankDetails: {
    accountName: string;
    accountNumber: string;
    bankName: string;
    ifscCode: string;
  };
  status: 'Pending' | 'Approved' | 'Rejected' | 'Paid';
  createdAt: string;
}

export interface Banner {
  id: string;
  imageUrl: string;
  title: string;
  subtitle: string;
  linkTo: string;
}

export interface ActivityLog {
  id: string;
  user: string;
  action: string;
  timestamp: string;
  role?: string;
  ipAddress?: string;
  device?: string;
}

export interface Notification {
  id: string;
  targetUser: string; // 'all', 'vendors', 'customers', or specific userId
  type: 'Email' | 'SMS' | 'WhatsApp' | 'Push';
  title: string;
  message: string;
  createdAt: string;
}

export interface CMSPage {
  slug: string;
  title: string;
  content: string;
}
