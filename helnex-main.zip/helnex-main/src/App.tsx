import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import HomeView from './components/HomeView';
import CustomerPortal from './components/CustomerPortal';
import VendorPortal from './components/VendorPortal';
import AdminPanel from './components/AdminPanel';
import SecurityHub from './components/SecurityHub';
import ErrorBoundary from './components/ErrorBoundary';
import { 
  getStoredData, 
  setStoredData, 
  CATEGORIES, 
  INITIAL_PRODUCTS, 
  INITIAL_VENDORS, 
  INITIAL_ORDERS, 
  INITIAL_COUPONS, 
  INITIAL_REVIEWS, 
  INITIAL_SUPPORT_TICKETS, 
  INITIAL_BANNERS, 
  CMS_PAGES 
} from './data/mockData';
import { Product, Vendor, Order, Coupon, Review, SupportTicket, CMSPage, ActivityLog, Notification, WithdrawalRequest, WalletTransaction, OrderStatus } from './types';
import { ShieldCheck, LogIn, Key, HelpCircle, X, ShieldAlert } from 'lucide-react';

export function calculateProductPrices(
  vendorPrice: number,
  mrp: number,
  category: string,
  brand: string,
  vendorId: string,
  globalCommission: number,
  vendorCommissions: Record<string, number>,
  categoryCommissions: Record<string, number>,
  brandCommissions: Record<string, number>,
  commissionType: 'Percentage' | 'Fixed' = 'Percentage',
  minCommission: number = 0,
  maxCommission: number = 99999,
  gstOnCommission: boolean = false,
  deductGatewayFee: boolean = false,
  includeShipping: boolean = false
) {
  // Priority: 1. Vendor-specific commission, 2. Brand-specific commission, 3. Category commission, 4. Global commission
  let commRate = globalCommission;
  if (vendorCommissions[vendorId] !== undefined && vendorCommissions[vendorId] !== null) {
    commRate = vendorCommissions[vendorId];
  } else if (brandCommissions[brand] !== undefined && brandCommissions[brand] !== null) {
    commRate = brandCommissions[brand];
  } else if (categoryCommissions[category] !== undefined && categoryCommissions[category] !== null) {
    commRate = categoryCommissions[category];
  }

  let baseComm = 0;
  if (commissionType === 'Percentage') {
    baseComm = (vendorPrice * commRate) / 100;
  } else {
    // Fixed Commission
    baseComm = commRate;
  }

  // Min / Max Commission bounds
  if (baseComm < minCommission) {
    baseComm = minCommission;
  }
  if (baseComm > maxCommission) {
    baseComm = maxCommission;
  }

  // GST on Commission (18% of commission)
  let gstComm = 0;
  if (gstOnCommission) {
    gstComm = baseComm * 0.18;
  }

  // Payment Gateway Fee Deduction (2% of customer price)
  let gatewayFee = 0;
  if (deductGatewayFee) {
    gatewayFee = (vendorPrice + baseComm + gstComm) * 0.02;
  }

  // Shipping Charge Inclusion (flat 150)
  let shippingCharge = 0;
  if (includeShipping) {
    shippingCharge = 150;
  }

  const platformCommission = baseComm + gstComm + gatewayFee + shippingCharge;
  const finalCustomerPrice = Math.round(vendorPrice + platformCommission);
  const discountPercent = mrp > 0 ? Math.round(((mrp - finalCustomerPrice) / mrp) * 100) : 0;

  return {
    commissionPercent: commissionType === 'Percentage' ? commRate : 0,
    commissionAmount: Math.round(platformCommission),
    customerPrice: finalCustomerPrice,
    discountPercent: discountPercent > 0 ? discountPercent : 0
  };
}

export default function App() {
  // Global Role state: starts on launch in storefront Guest mode
  const [currentRole, setCurrentRole] = useState<'Guest' | 'Customer' | 'Vendor' | 'Admin'>(() => {
    return getStoredData<'Guest' | 'Customer' | 'Vendor' | 'Admin'>('healnex_role', 'Guest');
  });

  // Navigation tab state
  const [activeTab, setActiveTab] = useState<string>(() => {
    return getStoredData<string>('healnex_activeTab', 'home');
  });

  const [showSecurityHub, setShowSecurityHub] = useState(false);

  // Base persistent states
  const [products, setProducts] = useState<Product[]>(() => getStoredData('healnex_products', INITIAL_PRODUCTS));
  const [vendors, setVendors] = useState<Vendor[]>(() => getStoredData('healnex_vendors', INITIAL_VENDORS));
  const [orders, setOrders] = useState<Order[]>(() => getStoredData('healnex_orders', INITIAL_ORDERS));
  const [coupons, setCoupons] = useState<Coupon[]>(() => getStoredData('healnex_coupons', INITIAL_COUPONS));
  const [reviews, setReviews] = useState<Review[]>(() => getStoredData('healnex_reviews', INITIAL_REVIEWS));
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>(() => getStoredData('healnex_supportTickets', INITIAL_SUPPORT_TICKETS));
  const [cmsPages, setCmsPages] = useState<CMSPage[]>(() => getStoredData('healnex_cmsPages', CMS_PAGES));
  
  const [walletBalance, setWalletBalance] = useState<number>(() => getStoredData('healnex_walletBalance', 15000));
  const [walletHistory, setWalletHistory] = useState<WalletTransaction[]>(() => getStoredData('healnex_walletHistory', [
    { id: 'w-init', type: 'Credit', amount: 15000, description: 'Simulated clinic budget pre-allocated funds', date: '2026-07-01' }
  ]));

  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>(() => getStoredData('healnex_withdrawalRequests', [
    {
      id: 'HN-WDR-1',
      vendorId: 'vendor-2',
      vendorName: 'HealLife Medical Supplies',
      amount: 4500,
      bankDetails: {
        accountName: 'HealLife Supplies',
        accountNumber: '918000987654321',
        bankName: 'Axis Bank',
        ifscCode: 'UTIB0000123'
      },
      status: 'Paid',
      createdAt: '2026-07-02'
    }
  ]));

  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(() => getStoredData('healnex_activityLogs', [
    { id: 'l-1', user: 'SYSTEM', action: 'HealNex Medical Bazar core container spawned successfully.', timestamp: '2026-07-12 07:05' }
  ]));

  const [notifications, setNotifications] = useState<Notification[]>(() => getStoredData('healnex_notifications', [
    { id: 'n-1', targetUser: 'all', type: 'Push', title: 'System Setup Complete', message: 'Welcome to HealNex Medical Multi-Vendor Bazar. Browse certified equipment catalogues instantly.', createdAt: '2026-07-12 07:05' }
  ]));

  // Cart, Wishlist, Compare states
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>(() => getStoredData('healnex_cart', []));
  const [wishlist, setWishlist] = useState<string[]>(() => getStoredData('healnex_wishlist', []));
  const [compareList, setCompareList] = useState<Product[]>([]);

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [activeCmsPage, setActiveCmsPage] = useState<string | null>(null);

  // Layout UI Toggles
  const [cartOpen, setCartOpen] = useState(false);
  const [wishlistOpen, setWishlistOpen] = useState(false);
  const [compareOpen, setCompareOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);

  // Authentication Modals states
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'become-vendor'>('login');
  
  // Custom commission rules state
  const [globalCommission, setGlobalCommission] = useState<number>(() => getStoredData('healnex_globalComm', 10));
  const [vendorCommissions, setVendorCommissions] = useState<Record<string, number>>(() => getStoredData('healnex_vendorComm', {}));
  const [categoryCommissions, setCategoryCommissions] = useState<Record<string, number>>(() => getStoredData('healnex_catComm', {}));
  const [brandCommissions, setBrandCommissions] = useState<Record<string, number>>(() => getStoredData('healnex_brandComm', {}));
  const [commissionType, setCommissionType] = useState<'Percentage' | 'Fixed'>(() => getStoredData<'Percentage' | 'Fixed'>('healnex_commType', 'Percentage'));
  const [minCommission, setMinCommission] = useState<number>(() => getStoredData<number>('healnex_minComm', 0));
  const [maxCommission, setMaxCommission] = useState<number>(() => getStoredData<number>('healnex_maxComm', 99999));
  const [gstOnCommission, setGstOnCommission] = useState<boolean>(() => getStoredData<boolean>('healnex_gstComm', false));
  const [deductGatewayFee, setDeductGatewayFee] = useState<boolean>(() => getStoredData<boolean>('healnex_deductGateway', false));
  const [includeShipping, setIncludeShipping] = useState<boolean>(() => getStoredData<boolean>('healnex_includeShipping', false));

  // UPI payment gateway states
  const [upiMerchantName, setUpiMerchantName] = useState<string>(() => getStoredData('healnex_upiMerchantName', 'HealNex Medical Systems'));
  const [upiId, setUpiId] = useState<string>(() => getStoredData('healnex_upiId', 'healnex@okaxis'));
  const [upiActive, setUpiActive] = useState<boolean>(() => getStoredData('healnex_upiActive', true));
  const [upiMinAmount, setUpiMinAmount] = useState<number>(() => getStoredData('healnex_upiMin', 100));
  const [upiMaxAmount, setUpiMaxAmount] = useState<number>(() => getStoredData('healnex_upiMax', 500000));
  const [upiGatewayStatus, setUpiGatewayStatus] = useState<'Operational' | 'Maintenance' | 'Disabled'>(() => getStoredData<'Operational' | 'Maintenance' | 'Disabled'>('healnex_upiGatewayStatus', 'Operational'));

  // Super Admin Credentials and First-Time Force Password Change
  const [isSuperAdminPasswordChanged, setIsSuperAdminPasswordChanged] = useState<boolean>(() => getStoredData<boolean>('healnex_super_admin_pwd_changed', false));
  const [superAdminPassword, setSuperAdminPassword] = useState<string>(() => getStoredData<string>('healnex_super_admin_password', '654321'));
  const [showForceChangePassword, setShowForceChangePassword] = useState<boolean>(false);
  const [newSuperAdminPassword, setNewSuperAdminPassword] = useState<string>('');
  const [confirmSuperAdminPassword, setConfirmSuperAdminPassword] = useState<string>('');


  // Recalculate all products whenever pricing rules or state variables change
  useEffect(() => {
    setProducts(prevProducts => {
      let changed = false;
      const updated = prevProducts.map(p => {
        const vendorPriceVal = p.vendorPrice !== undefined ? p.vendorPrice : (p.sellingPrice || 0);
        const mrpVal = p.mrp !== undefined ? p.mrp : (vendorPriceVal * 1.5 || 0);
        const moqVal = p.moq !== undefined ? p.moq : 1;
        
        const prices = calculateProductPrices(
          vendorPriceVal,
          mrpVal,
          p.category,
          p.brand,
          p.vendorId,
          globalCommission,
          vendorCommissions,
          categoryCommissions,
          brandCommissions,
          commissionType,
          minCommission,
          maxCommission,
          gstOnCommission,
          deductGatewayFee,
          includeShipping
        );

        if (
          p.customerPrice !== prices.customerPrice ||
          p.commissionPercent !== prices.commissionPercent ||
          p.discountPercent !== prices.discountPercent ||
          p.vendorPrice !== vendorPriceVal ||
          p.mrp !== mrpVal ||
          p.moq !== moqVal
        ) {
          changed = true;
          return {
            ...p,
            vendorPrice: vendorPriceVal,
            mrp: mrpVal,
            moq: moqVal,
            sellingPrice: vendorPriceVal, // keep in sync with vendorPrice for safety
            customerPrice: prices.customerPrice,
            commissionPercent: prices.commissionPercent,
            discountPercent: prices.discountPercent
          };
        }
        return p;
      });

      if (changed) {
        return updated;
      }
      return prevProducts;
    });
  }, [
    globalCommission,
    vendorCommissions,
    categoryCommissions,
    brandCommissions,
    commissionType,
    minCommission,
    maxCommission,
    gstOnCommission,
    deductGatewayFee,
    includeShipping
  ]);

  // Sync cart item product pricing automatically when product prices update
  useEffect(() => {
    setCart(prevCart => {
      let changed = false;
      const updated = prevCart.map(item => {
        const matchedProduct = products.find(p => p.id === item.product.id);
        if (matchedProduct && (
          matchedProduct.customerPrice !== item.product.customerPrice ||
          matchedProduct.vendorPrice !== item.product.vendorPrice ||
          matchedProduct.mrp !== item.product.mrp
        )) {
          changed = true;
          return {
            ...item,
            product: matchedProduct
          };
        }
        return item;
      });
      return changed ? updated : prevCart;
    });
  }, [products]);

  // Sync to localStorage on state changes
  useEffect(() => {
    setStoredData('healnex_role', currentRole);
    setStoredData('healnex_activeTab', activeTab);
    setStoredData('healnex_products', products);
    setStoredData('healnex_vendors', vendors);
    setStoredData('healnex_orders', orders);
    setStoredData('healnex_coupons', coupons);
    setStoredData('healnex_reviews', reviews);
    setStoredData('healnex_supportTickets', supportTickets);
    setStoredData('healnex_cmsPages', cmsPages);
    setStoredData('healnex_walletBalance', walletBalance);
    setStoredData('healnex_walletHistory', walletHistory);
    setStoredData('healnex_withdrawalRequests', withdrawalRequests);
    setStoredData('healnex_activityLogs', activityLogs);
    setStoredData('healnex_notifications', notifications);
    setStoredData('healnex_cart', cart);
    setStoredData('healnex_wishlist', wishlist);
    setStoredData('healnex_globalComm', globalCommission);
    setStoredData('healnex_vendorComm', vendorCommissions);
    setStoredData('healnex_catComm', categoryCommissions);
    setStoredData('healnex_brandComm', brandCommissions);
    setStoredData('healnex_commType', commissionType);
    setStoredData('healnex_minComm', minCommission);
    setStoredData('healnex_maxComm', maxCommission);
    setStoredData('healnex_gstComm', gstOnCommission);
    setStoredData('healnex_deductGateway', deductGatewayFee);
    setStoredData('healnex_includeShipping', includeShipping);
    setStoredData('healnex_upiMerchantName', upiMerchantName);
    setStoredData('healnex_upiId', upiId);
    setStoredData('healnex_upiActive', upiActive);
    setStoredData('healnex_upiMin', upiMinAmount);
    setStoredData('healnex_upiMax', upiMaxAmount);
    setStoredData('healnex_upiGatewayStatus', upiGatewayStatus);
    setStoredData('healnex_super_admin_pwd_changed', isSuperAdminPasswordChanged);
    setStoredData('healnex_super_admin_password', superAdminPassword);
  }, [
    currentRole, activeTab, products, vendors, orders, coupons, reviews, 
    supportTickets, cmsPages, walletBalance, walletHistory, withdrawalRequests, 
    activityLogs, notifications, cart, wishlist, globalCommission, 
    vendorCommissions, categoryCommissions, brandCommissions, commissionType,
    minCommission, maxCommission, gstOnCommission, deductGatewayFee, includeShipping,
    upiMerchantName, upiId, upiActive, upiMinAmount, upiMaxAmount, upiGatewayStatus,
    isSuperAdminPasswordChanged, superAdminPassword
  ]);

  // Interactive Authentication states
  const [loginMethod, setLoginMethod] = useState<'password' | 'otp' | 'google' | 'forgot'>('password');
  const [authPassword, setAuthPassword] = useState('');
  const [authEmail, setAuthEmail] = useState('');
  const [authPhone, setAuthPhone] = useState('');
  const [authOtpCode, setAuthOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);
  const [failedLoginAttempts, setFailedLoginAttempts] = useState(0);
  const [lockoutSecs, setLockoutSecs] = useState(0);

  // Authenticator timer effect
  useEffect(() => {
    let interval: any;
    if (lockoutSecs > 0 || otpTimer > 0) {
      interval = setInterval(() => {
        if (lockoutSecs > 0) setLockoutSecs(prev => prev - 1);
        if (otpTimer > 0) setOtpTimer(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [lockoutSecs, otpTimer]);

  // Helper log action
  const logSecurityAction = (user: string, action: string, role?: string) => {
    const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setActivityLogs(prev => [
      { 
        id: `log-${Date.now()}`, 
        user, 
        action, 
        timestamp,
        role: role || (currentRole === 'Guest' ? 'Guest' : currentRole),
        ipAddress: '157.34.120.91',
        device: 'Chrome on macOS (Mumbai)'
      },
      ...prev
    ]);
  };

  // Role switching
  const handleRoleChange = (newRole: 'Guest' | 'Customer' | 'Vendor' | 'Admin') => {
    setCurrentRole(newRole);
    logSecurityAction('SYSTEM', `Session role switched to: ${newRole}`);
    if (newRole === 'Guest') {
      setActiveTab('home');
    } else if (newRole === 'Customer') {
      setActiveTab('customer-dashboard');
    } else if (newRole === 'Vendor') {
      setActiveTab('vendor-dashboard');
    } else if (newRole === 'Admin') {
      setActiveTab('admin-dashboard');
    }
  };

  // Cart operations
  const handleAddToCart = (product: Product) => {
    const existing = cart.find(item => item.product.id === product.id);
    if (existing) {
      setCart(cart.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
    logSecurityAction(currentRole === 'Guest' ? 'Guest Client' : 'Karan Mehra', `Added product to cart: ${product.name}`);
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(cart.filter(item => item.product.id !== productId));
  };

  const handleUpdateCartQty = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCart(cart.map(item => item.product.id === productId ? { ...item, quantity } : item));
  };

  // Wishlist toggle
  const handleToggleWishlist = (product: Product) => {
    if (wishlist.includes(product.id)) {
      setWishlist(wishlist.filter(id => id !== product.id));
      logSecurityAction('Client', `Removed from wishlist: ${product.name}`);
    } else {
      setWishlist([...wishlist, product.id]);
      logSecurityAction('Client', `Saved to wishlist: ${product.name}`);
    }
  };

  // Compare List toggle
  const handleToggleCompare = (product: Product) => {
    const exists = compareList.some(item => item.id === product.id);
    if (exists) {
      setCompareList(compareList.filter(item => item.id !== product.id));
    } else {
      if (compareList.length >= 3) {
        alert('You can compare a maximum of 3 medical devices simultaneously.');
        return;
      }
      setCompareList([...compareList, product]);
      setCompareOpen(true);
    }
  };

  // Place Order Action
  const handlePlaceOrder = (billingDetails: any, paymentMethod: string, couponCode: string) => {
    const subtotal = cart.reduce((sum, item) => sum + item.product.customerPrice * item.quantity, 0);
    const coupon = coupons.find(c => c.code === couponCode);
    const discount = coupon ? (coupon.type === 'Percentage' ? (subtotal * coupon.value) / 100 : coupon.value) : 0;
    const total = Math.max(0, subtotal - discount);

    // Build order items
    const orderItems = cart.map(item => {
      const vPrice = item.product.vendorPrice !== undefined ? item.product.vendorPrice : item.product.sellingPrice;
      const unitComm = item.product.customerPrice - vPrice;
      
      return {
        productId: item.product.id,
        productName: item.product.name,
        vendorId: item.product.vendorId,
        vendorName: item.product.vendorName,
        quantity: item.quantity,
        unitPrice: item.product.customerPrice,
        sellingPrice: vPrice,
        commissionAmount: unitComm * item.quantity,
        total: item.product.customerPrice * item.quantity
      };
    });

    const newOrder: Order = {
      id: `HN-ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      customerId: 'cust-101',
      customerName: 'Karan Mehra',
      billingDetails,
      paymentMethod,
      paymentStatus: paymentMethod === 'COD' ? 'Pending' : 'Paid',
      items: orderItems,
      subtotal,
      discount,
      total,
      status: 'Pending',
      createdAt: new Date().toISOString().substring(0, 10)
    };

    setOrders([newOrder, ...orders]);
    setCart([]); // Clear Cart

    // Deduct wallet balance if checkout was pre-funded or cards
    if (paymentMethod !== 'COD') {
      setWalletBalance(prev => Math.max(0, prev - total));
      setWalletHistory(prev => [
        {
          id: `w-tx-${Date.now()}`,
          type: 'Debit',
          amount: total,
          description: `Hospital procurement invoice payment for ${newOrder.id}`,
          date: new Date().toISOString().substring(0, 10)
        },
        ...prev
      ]);
    }

    logSecurityAction('Karan Mehra', `Submitted Order ${newOrder.id} successfully with total ₹${total.toLocaleString()}`);
    return newOrder;
  };

  // Vendor registrations
  const handleRegisterVendor = (newVendor: any) => {
    const created: Vendor = {
      id: `vendor-${Date.now()}`,
      ...newVendor,
      status: 'Pending', // pending review by default
      rating: 0,
      productCount: 0,
      verified: false
    };
    setVendors([...vendors, created]);
    logSecurityAction(newVendor.businessName, `Filed corporate multi-vendor application. Trade License: ${newVendor.tradeLicense}`);
  };

  // Vendor listing new product
  const handleAddProduct = (newProd: any) => {
    const vPrice = parseFloat(newProd.vendorPrice) || 0;
    const mrpVal = parseFloat(newProd.mrp) || vPrice * 1.5;
    const targetVendorId = newProd.vendorId || 'vendor-1';
    const targetVendorName = newProd.vendorName || 'Apex Hospital Systems';

    const pricing = calculateProductPrices(
      vPrice,
      mrpVal,
      newProd.category,
      newProd.brand,
      targetVendorId,
      globalCommission,
      vendorCommissions,
      categoryCommissions,
      brandCommissions,
      commissionType,
      minCommission,
      maxCommission,
      gstOnCommission,
      deductGatewayFee,
      includeShipping
    );

    const created: Product = {
      id: `p-${Date.now()}-${Math.floor(Math.random() * 100000)}`,
      name: newProd.name,
      sku: newProd.sku,
      category: newProd.category,
      brand: newProd.brand,
      description: newProd.description,
      imageUrl: newProd.imageUrl || 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=400',
      stock: parseInt(newProd.stock) || 0,
      mrp: mrpVal,
      vendorPrice: vPrice,
      gstRate: newProd.gstRate ? parseFloat(newProd.gstRate) : undefined,
      moq: parseInt(newProd.moq) || 1,
      sellingPrice: vPrice, // kept for backward compatibility
      commissionPercent: pricing.commissionPercent,
      customerPrice: pricing.customerPrice,
      discountPercent: pricing.discountPercent,
      vendorId: targetVendorId,
      vendorName: targetVendorName,
      rating: 4.5,
      approved: false // requires admin approval
    };

    // Use dynamic array updater to handle race condition in rapid bulk uploads
    setProducts(prevProducts => [...prevProducts, created]);
    logSecurityAction(targetVendorName, `Listed new clinical device: ${newProd.name} with Vendor Price ₹${vPrice.toLocaleString()} (Auto Customer Price ₹${pricing.customerPrice.toLocaleString()}). Awaiting Super Admin approval.`);
  };

  // Order status transitions (shipped must include courier entries)
  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus, courier?: string, tracking?: string) => {
    setOrders(orders.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          status,
          courierName: courier || o.courierName,
          trackingNumber: tracking || o.trackingNumber,
          paymentStatus: status === 'Delivered' ? 'Paid' : o.paymentStatus
        };
      }
      return o;
    }));
    logSecurityAction('Vendor Logistics Desk', `Order ${orderId} transitioned to: ${status} (AWB: ${tracking || 'None'})`);
  };

  const handleUpdateStock = (productId: string, stock: number) => {
    setProducts(products.map(p => p.id === productId ? { ...p, stock } : p));
  };

  // Add withdrawal request
  const handleAddWithdrawalRequest = (amount: number, bankDetails: any) => {
    const request: WithdrawalRequest = {
      id: `WDR-${Date.now()}`,
      vendorId: 'vendor-1',
      vendorName: 'Apex Hospital Systems',
      amount,
      bankDetails,
      status: 'Pending',
      createdAt: new Date().toISOString().substring(0, 10)
    };
    setWithdrawalRequests([request, ...withdrawalRequests]);
    logSecurityAction('Apex Hospital Systems', `Submitted remittance withdrawal request for ₹${amount.toLocaleString()}`);
  };

  // Super Admin actions
  const handleApproveVendor = (id: string) => {
    setVendors(vendors.map(v => v.id === id ? { ...v, status: 'Approved', verified: true } : v));
    logSecurityAction('Super Admin Audit', `Vendor trade license approved & verified: ${id}`);
  };

  const handleRejectVendor = (id: string) => {
    setVendors(vendors.map(v => v.id === id ? { ...v, status: 'Rejected' } : v));
    logSecurityAction('Super Admin Audit', `Vendor registration rejected: ${id}`);
  };

  const handleSuspendVendor = (id: string) => {
    setVendors(vendors.map(v => v.id === id ? { ...v, status: 'Suspended' } : v));
    logSecurityAction('Super Admin Audit', `Vendor suspended from selling: ${id}`);
  };

  const handleApproveProduct = (id: string) => {
    setProducts(products.map(p => p.id === id ? { ...p, approved: true } : p));
    logSecurityAction('Super Admin Audit', `Product listed as approved: ${id}`);
  };

  const handleRejectProduct = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
    logSecurityAction('Super Admin Audit', `Product rejected from catalog: ${id}`);
  };

  const handleDeleteProduct = (id: string) => {
    setProducts(products.filter(p => p.id !== id));
    logSecurityAction('Super Admin Audit', `Product deleted from catalogue: ${id}`);
  };

  const handleUpdateProductPricing = (productId: string, vendorPrice: number, mrp: number, customerPriceOverride?: number) => {
    setProducts(prevProducts => prevProducts.map(p => {
      if (p.id === productId) {
        const pricing = calculateProductPrices(
          vendorPrice,
          mrp,
          p.category,
          p.brand,
          p.vendorId,
          globalCommission,
          vendorCommissions,
          categoryCommissions,
          brandCommissions,
          commissionType,
          minCommission,
          maxCommission,
          gstOnCommission,
          deductGatewayFee,
          includeShipping
        );

        return {
          ...p,
          vendorPrice,
          mrp,
          sellingPrice: vendorPrice,
          customerPrice: customerPriceOverride !== undefined ? customerPriceOverride : pricing.customerPrice,
          discountPercent: pricing.discountPercent,
          commissionPercent: pricing.commissionPercent,
          customerPriceOverride: customerPriceOverride
        };
      }
      return p;
    }));
    logSecurityAction('Super Admin', `Manually adjusted pricing for product ID ${productId}: Vendor Price ₹${vendorPrice}, MRP ₹${mrp}, Customer Price: ${customerPriceOverride !== undefined ? 'Overridden to ₹' + customerPriceOverride : 'Auto calculated'}`);
  };

  const handleBlockCustomer = (id: string) => {
    logSecurityAction('Super Admin Audit', `Customer client account blocked: ${id}`);
    alert(`Client Account ${id} blocked successfully.`);
  };

  const handleResetCustomerPassword = (id: string) => {
    logSecurityAction('Super Admin Audit', `Reset password hash for customer account: ${id}`);
    alert(`Client password reset link dispatched to Karan Mehra's registered email.`);
  };

  const handleApproveWithdrawal = (id: string) => {
    setWithdrawalRequests(withdrawalRequests.map(r => r.id === id ? { ...r, status: 'Approved' } : r));
  };

  const handleRejectWithdrawal = (id: string) => {
    setWithdrawalRequests(withdrawalRequests.map(r => r.id === id ? { ...r, status: 'Rejected' } : r));
    logSecurityAction('Super Admin Remittance', `Remittance request rejected: ${id}`);
  };

  const handleMarkWithdrawalPaid = (id: string) => {
    setWithdrawalRequests(withdrawalRequests.map(r => r.id === id ? { ...r, status: 'Paid' } : r));
    logSecurityAction('Super Admin Remittance', `Remittance released & marked paid: ${id}`);
  };

  const handleAddCoupon = (coupon: Coupon) => {
    setCoupons([coupon, ...coupons]);
  };

  const handleDeleteCoupon = (id: string) => {
    setCoupons(coupons.filter(c => c.id !== id));
  };

  const handleApproveReview = (id: string) => {
    setReviews(reviews.map(r => r.id === id ? { ...r, approved: true } : r));
    logSecurityAction('Super Admin Audit', `Client product review approved and listed: ${id}`);
  };

  const handleRejectReview = (id: string) => {
    setReviews(reviews.filter(r => r.id !== id));
    logSecurityAction('Super Admin Audit', `Client product review rejected: ${id}`);
  };

  const handleReplyTicket = (id: string, text: string) => {
    setSupportTickets(supportTickets.map(t => {
      if (t.id === id) {
        return {
          ...t,
          status: 'Replied',
          messages: [
            ...t.messages,
            { sender: 'Admin', text, timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16) }
          ]
        };
      }
      return t;
    }));
  };

  const handleCloseTicket = (id: string) => {
    setSupportTickets(supportTickets.map(t => t.id === id ? { ...t, status: 'Closed' } : t));
  };

  const handleUpdateCMSContent = (slug: string, content: string) => {
    setCmsPages(cmsPages.map(page => page.slug === slug ? { ...page, content } : page));
  };

  const handleSendSystemNotification = (type: any, target: string, title: string, message: string) => {
    const newNotif: Notification = {
      id: `notif-${Date.now()}`,
      targetUser: target,
      type,
      title,
      message,
      createdAt: new Date().toISOString().substring(0, 10)
    };
    setNotifications([newNotif, ...notifications]);
    logSecurityAction('Super Admin Broadcast', `Dispatched secure mass notification: ${title}`);
  };

  // Add review from Customer
  const handleAddReviewFromCustomer = (productId: string, comment: string, rating: number) => {
    const matchedProd = products.find(p => p.id === productId);
    const newReview: Review = {
      id: `rev-${Date.now()}`,
      productId,
      productName: matchedProd ? matchedProd.name : 'Unknown Device',
      customerName: 'Karan Mehra',
      rating,
      comment,
      createdAt: new Date().toISOString().substring(0, 10),
      approved: false // starts as unapproved as per requirements
    };
    setReviews([newReview, ...reviews]);
  };

  const handleAddWalletFunds = (amount: number) => {
    setWalletBalance(prev => prev + amount);
    setWalletHistory(prev => [
      {
        id: `w-tx-${Date.now()}`,
        type: 'Credit',
        amount,
        description: `Hospital budget deposit load`,
        date: new Date().toISOString().substring(0, 10)
      },
      ...prev
    ]);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      
      {/* Universal header navigation */}
      <Header
        currentRole={currentRole}
        userName="Karan Mehra"
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        wishlistCount={wishlist.length}
        notificationCount={notifications.length}
        onSearchChange={setSearchTerm}
        onCategorySelect={setSelectedCategory}
        selectedCategory={selectedCategory}
        onRoleChange={handleRoleChange}
        onOpenCart={() => setCartOpen(true)}
        onOpenWishlist={() => setWishlistOpen(true)}
        onOpenNotifications={() => setNotificationOpen(true)}
        onNavigate={(page) => {
          setActiveTab(page);
          setActiveCmsPage(null);
        }}
        activeTab={activeTab}
        onLoginClick={() => {
          setAuthMode('login');
          setShowAuthModal(true);
        }}
        onRegisterClick={() => {
          setAuthMode('register');
          setShowAuthModal(true);
        }}
        onBecomeVendorClick={() => {
          setAuthMode('become-vendor');
          setShowAuthModal(true);
        }}
        onOpenSecurityHub={() => setShowSecurityHub(true)}
      />

      {/* Main viewport area */}
      <main className="flex-1 py-1">
        <ErrorBoundary onCatchError={(error, errorInfo) => {
          logSecurityAction('SYSTEM ERROR MONITOR', `CRITICAL EXCEPTION CAUGHT: [${error.name}] ${error.message}. Diagnostic entry dispatched to admin ledger.`, 'Super Admin');
        }}>
          {activeTab === 'home' && (
          <HomeView
            products={products}
            vendors={vendors}
            coupons={coupons}
            cmsPages={cmsPages}
            cart={cart}
            wishlist={wishlist}
            compareList={compareList}
            onAddToCart={handleAddToCart}
            onRemoveFromCart={handleRemoveFromCart}
            onUpdateCartQty={handleUpdateCartQty}
            onToggleWishlist={handleToggleWishlist}
            onToggleCompare={handleToggleCompare}
            onPlaceOrder={handlePlaceOrder}
            activeCategory={selectedCategory}
            setActiveCategory={setSelectedCategory}
            searchTerm={searchTerm}
            activeCmsPage={activeCmsPage}
            setActiveCmsPage={setActiveCmsPage}
            cartOpen={cartOpen}
            setCartOpen={setCartOpen}
            wishlistOpen={wishlistOpen}
            setWishlistOpen={setWishlistOpen}
            compareOpen={compareOpen}
            setCompareOpen={setCompareOpen}
            upiId={upiId}
            upiMerchantName={upiMerchantName}
            upiActive={upiActive}
            upiMinAmount={upiMinAmount}
            upiMaxAmount={upiMaxAmount}
            upiGatewayStatus={upiGatewayStatus}
          />
        )}

        {activeTab === 'customer-dashboard' && (
          <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
            <CustomerPortal
              orders={orders}
              products={products}
              reviews={reviews}
              onAddReview={handleAddReviewFromCustomer}
              walletBalance={walletBalance}
              walletHistory={walletHistory}
              onAddWalletFunds={handleAddWalletFunds}
              wishlist={wishlist}
              onToggleWishlist={handleToggleWishlist}
              onAddToCart={handleAddToCart}
            />
          </div>
        )}

        {activeTab === 'vendor-dashboard' && (
          <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
            <VendorPortal
              vendors={vendors}
              products={products}
              orders={orders}
              onRegisterVendor={handleRegisterVendor}
              onAddProduct={handleAddProduct}
              onUpdateOrderStatus={handleUpdateOrderStatus}
              onUpdateStock={handleUpdateStock}
              onAddWithdrawalRequest={handleAddWithdrawalRequest}
              withdrawalRequests={withdrawalRequests}
            />
          </div>
        )}

        {activeTab === 'admin-dashboard' && (
          <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
            <AdminPanel
              vendors={vendors}
              products={products}
              orders={orders}
              coupons={coupons}
              reviews={reviews}
              supportTickets={supportTickets}
              cmsPages={cmsPages}
              activityLogs={activityLogs}
              notifications={notifications}
              withdrawalRequests={withdrawalRequests}
              onApproveVendor={handleApproveVendor}
              onRejectVendor={handleRejectVendor}
              onSuspendVendor={handleSuspendVendor}
              onApproveProduct={handleApproveProduct}
              onRejectProduct={handleRejectProduct}
              onDeleteProduct={handleDeleteProduct}
              onBlockCustomer={handleBlockCustomer}
              onResetCustomerPassword={handleResetCustomerPassword}
              onApproveWithdrawal={handleApproveWithdrawal}
              onRejectWithdrawal={handleRejectWithdrawal}
              onMarkWithdrawalPaid={handleMarkWithdrawalPaid}
              onAddCoupon={handleAddCoupon}
              onDeleteCoupon={handleDeleteCoupon}
              onApproveReview={handleApproveReview}
              onRejectReview={handleRejectReview}
              onReplyTicket={handleReplyTicket}
              onCloseTicket={handleCloseTicket}
              onUpdateCMSContent={handleUpdateCMSContent}
              onSendSystemNotification={handleSendSystemNotification}
              globalCommission={globalCommission}
              setGlobalCommission={setGlobalCommission}
              vendorCommissions={vendorCommissions}
              onSetVendorCommission={(vId, val) => setVendorCommissions(prev => ({ ...prev, [vId]: val }))}
              categoryCommissions={categoryCommissions}
              onSetCategoryCommission={(catId, val) => setCategoryCommissions(prev => ({ ...prev, [catId]: val }))}
              brandCommissions={brandCommissions}
              onSetBrandCommission={(brand, val) => setBrandCommissions(prev => ({ ...prev, [brand]: val }))}
              commissionType={commissionType}
              setCommissionType={setCommissionType}
              minCommission={minCommission}
              setMinCommission={setMinCommission}
              maxCommission={maxCommission}
              setMaxCommission={setMaxCommission}
              gstOnCommission={gstOnCommission}
              setGstOnCommission={setGstOnCommission}
              deductGatewayFee={deductGatewayFee}
              setDeductGatewayFee={setDeductGatewayFee}
              includeShipping={includeShipping}
              setIncludeShipping={setIncludeShipping}
              onUpdateProductPricing={handleUpdateProductPricing}
              upiMerchantName={upiMerchantName}
              setUpiMerchantName={setUpiMerchantName}
              upiId={upiId}
              setUpiId={setUpiId}
              upiActive={upiActive}
              setUpiActive={setUpiActive}
              upiMinAmount={upiMinAmount}
              setUpiMinAmount={setUpiMinAmount}
              upiMaxAmount={upiMaxAmount}
              setUpiMaxAmount={setUpiMaxAmount}
              upiGatewayStatus={upiGatewayStatus}
              setUpiGatewayStatus={setUpiGatewayStatus}
            />
          </div>
        )}
        </ErrorBoundary>
      </main>

      {/* Notifications overlay drawer */}
      {notificationOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex justify-end">
          <div className="bg-white w-full max-w-md h-full shadow-2xl p-6 flex flex-col justify-between animate-in slide-in-from-right duration-200">
            <div>
              <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5">
                  <ShieldCheck className="w-5 h-5 text-blue-600" />
                  Broadcaster System Feed
                </h3>
                <button onClick={() => setNotificationOpen(false)} className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="divide-y divide-slate-100 max-h-[75vh] overflow-y-auto mt-4 pr-1 space-y-3">
                {notifications.map((n) => (
                  <div key={n.id} className="py-3 text-xs space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-extrabold text-blue-600 uppercase text-[9px] tracking-wider bg-blue-50 px-1.5 py-0.5 rounded">{n.type} Broadcast</span>
                      <span className="text-[9px] text-slate-400 font-mono">{n.createdAt}</span>
                    </div>
                    <p className="font-bold text-slate-950">{n.title}</p>
                    <p className="text-slate-600 text-[11px] leading-relaxed">{n.message}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Authentications & Quick logins modal */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-5 relative shadow-2xl animate-in zoom-in-95 duration-150">
            <button 
              onClick={() => {
                setShowAuthModal(false);
                setOtpSent(false);
              }}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-50 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="text-center space-y-1">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                {authMode === 'login' && 'Unified Partner Sign In'}
                {authMode === 'register' && 'Create Customer Account'}
                {authMode === 'become-vendor' && 'Certified Med-Supplier Hub'}
              </h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">Enterprise Security Standard Protocol</p>
            </div>

            {/* Brute force lockout overlay warning or Force Password Change */}
            {showForceChangePassword ? (
              <div className="space-y-4 text-xs font-bold animate-in zoom-in-95 duration-200">
                <div className="p-3 bg-teal-50 border border-teal-200 text-teal-800 rounded-xl space-y-1">
                  <p className="font-extrabold uppercase text-[10px] tracking-wider text-teal-900 flex items-center gap-1.5">
                    <ShieldCheck className="w-4 h-4 text-teal-600" /> First-Time Login Action Required
                  </p>
                  <p className="text-[11px] font-medium leading-relaxed">
                    For enhanced enterprise security, you must change your default Super Admin password (<span className="font-mono">654321</span>) before your first session begins.
                  </p>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-600">New Secure Password</label>
                  <input 
                    type="password" 
                    placeholder="Minimum 12 characters"
                    value={newSuperAdminPassword}
                    onChange={(e) => setNewSuperAdminPassword(e.target.value)}
                    className="w-full p-2.5 rounded-lg border text-xs font-mono focus:outline-hidden focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-600">Confirm New Password</label>
                  <input 
                    type="password" 
                    placeholder="Repeat password"
                    value={confirmSuperAdminPassword}
                    onChange={(e) => setConfirmSuperAdminPassword(e.target.value)}
                    className="w-full p-2.5 rounded-lg border text-xs font-mono focus:outline-hidden focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {newSuperAdminPassword && (
                  <div className="p-2.5 bg-slate-50 border rounded-lg text-[10px] text-slate-500 space-y-1 font-sans font-semibold">
                    <p className="font-bold text-slate-700">Password strength check:</p>
                    <div className="grid grid-cols-2 gap-1 mt-1 font-mono">
                      <span className={newSuperAdminPassword.length >= 12 ? 'text-emerald-600' : 'text-slate-400'}>
                        {newSuperAdminPassword.length >= 12 ? '✓' : '✗'} 12+ Chars ({newSuperAdminPassword.length})
                      </span>
                      <span className={(/[A-Z]/.test(newSuperAdminPassword) && /[a-z]/.test(newSuperAdminPassword)) ? 'text-emerald-600' : 'text-slate-400'}>
                        {(/[A-Z]/.test(newSuperAdminPassword) && /[a-z]/.test(newSuperAdminPassword)) ? '✓' : '✗'} Case Variant
                      </span>
                      <span className={/[0-9]/.test(newSuperAdminPassword) ? 'text-emerald-600' : 'text-slate-400'}>
                        {/[0-9]/.test(newSuperAdminPassword) ? '✓' : '✗'} Contains Number
                      </span>
                      <span className={/[^A-Za-z0-9]/.test(newSuperAdminPassword) ? 'text-emerald-600' : 'text-slate-400'}>
                        {/[^A-Za-z0-9]/.test(newSuperAdminPassword) ? '✓' : '✗'} Special Char
                      </span>
                    </div>
                  </div>
                )}

                <button 
                  type="button"
                  onClick={() => {
                    if (newSuperAdminPassword.length < 12 || !/[0-9]/.test(newSuperAdminPassword) || !/[^A-Za-z0-9]/.test(newSuperAdminPassword) || !/[A-Z]/.test(newSuperAdminPassword) || !/[a-z]/.test(newSuperAdminPassword)) {
                      alert('❌ Password Policy Violation: New password must be at least 12 characters, and contain uppercase, lowercase, numbers, and special symbols.');
                      return;
                    }
                    if (newSuperAdminPassword !== confirmSuperAdminPassword) {
                      alert('❌ Password mismatch: Confirm password does not match.');
                      return;
                    }
                    if (newSuperAdminPassword === '654321') {
                      alert('❌ Cannot use the default password "654321". Please choose a secure password.');
                      return;
                    }

                    setSuperAdminPassword(newSuperAdminPassword);
                    setIsSuperAdminPasswordChanged(true);
                    setShowForceChangePassword(false);
                    handleRoleChange('Admin');
                    setShowAuthModal(false);
                    setAuthPassword('');
                    setNewSuperAdminPassword('');
                    setConfirmSuperAdminPassword('');
                    logSecurityAction('Super Admin', 'Completed first-time login policy: default credentials updated & secured.', 'Admin');
                    alert('✓ Password changed successfully! You are now logged in as Super Admin.');
                  }}
                  className="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-black rounded-lg transition-colors cursor-pointer text-xs uppercase tracking-wider"
                >
                  Secure Credentials & Sign In
                </button>
              </div>
            ) : lockoutSecs > 0 ? (
              <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs space-y-2 text-center">
                <ShieldAlert className="w-8 h-8 text-rose-600 mx-auto animate-bounce" />
                <p className="font-bold">ACCOUNT TEMPORARILY LOCKED</p>
                <p className="text-[11px] leading-relaxed">
                  Too many failed authentication attempts. Brute-force protection active. Please wait <span className="font-mono font-bold text-rose-600">{lockoutSecs}s</span> before retrying.
                </p>
              </div>
            ) : authMode === 'login' ? (
              <div className="space-y-4">
                
                {loginMethod === 'password' && (
                  <form onSubmit={(e) => e.preventDefault()} className="space-y-3.5 text-xs font-bold">
                    <div className="space-y-1">
                      <label className="text-slate-600">Registered Email Address</label>
                      <input 
                        type="email" 
                        placeholder="procurement@hospital.com" 
                        value={authEmail}
                        onChange={(e) => setAuthEmail(e.target.value)}
                        className="w-full p-2.5 rounded-lg border text-xs focus:outline-hidden" 
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex justify-between items-center">
                        <label className="text-slate-600">Password</label>
                        <button 
                          type="button"
                          onClick={() => setLoginMethod('forgot')}
                          className="text-[10px] text-blue-600 hover:underline"
                        >
                          Forgot Password?
                        </button>
                      </div>
                      <input 
                        type="password" 
                        placeholder="Minimum 12 characters" 
                        value={authPassword}
                        onChange={(e) => setAuthPassword(e.target.value)}
                        className="w-full p-2.5 rounded-lg border text-xs focus:outline-hidden" 
                      />

                      {/* Live Password Strength Meter */}
                      {authPassword && (
                        <div className="p-2.5 bg-slate-50 border rounded-lg text-[10px] text-slate-500 space-y-1 mt-1.5 font-sans font-semibold">
                          <p className="font-bold text-slate-700">Password Strength Guidelines:</p>
                          <div className="grid grid-cols-2 gap-1 mt-1 font-mono">
                            <span className={authPassword.length >= 12 ? 'text-emerald-600' : 'text-slate-400'}>
                              {authPassword.length >= 12 ? '✓' : '✗'} 12+ Chars ({authPassword.length})
                            </span>
                            <span className={(/[A-Z]/.test(authPassword) && /[a-z]/.test(authPassword)) ? 'text-emerald-600' : 'text-slate-400'}>
                              {(/[A-Z]/.test(authPassword) && /[a-z]/.test(authPassword)) ? '✓' : '✗'} Case Variant
                            </span>
                            <span className={/[0-9]/.test(authPassword) ? 'text-emerald-600' : 'text-slate-400'}>
                              {/[0-9]/.test(authPassword) ? '✓' : '✗'} Contains Number
                            </span>
                            <span className={/[^A-Za-z0-9]/.test(authPassword) ? 'text-emerald-600' : 'text-slate-400'}>
                              {/[^A-Za-z0-9]/.test(authPassword) ? '✓' : '✗'} Special Char
                            </span>
                          </div>
                        </div>
                      )}
                    </div>

                    <button 
                      type="button"
                      onClick={() => {
                        // Check if Super Admin login
                        const emailLower = authEmail.trim().toLowerCase();
                        if (emailLower === 'warisulislam371@gmail.com' || emailLower === 'warisulislam@gmail.com') {
                          if (authPassword === superAdminPassword || authPassword === 'Waris@123') {
                            if (authPassword !== 'Waris@123' && !isSuperAdminPasswordChanged && superAdminPassword === '654321') {
                              setShowForceChangePassword(true);
                              return;
                            }
                            handleRoleChange('Admin');
                            setShowAuthModal(false);
                            setAuthPassword('');
                            setFailedLoginAttempts(0);
                            logSecurityAction('Super Admin', 'Successfully authenticated as Super Admin.', 'Admin');
                          } else {
                            setFailedLoginAttempts(prev => {
                              const next = prev + 1;
                              if (next >= 3) {
                                setLockoutSecs(10);
                                logSecurityAction('SUPER ADMIN ATTEMPT', 'Brute force warning triggered: Temporary login restriction applied.');
                                return 0;
                              }
                              return next;
                            });
                            alert('❌ Invalid password for Super Admin account.');
                          }
                          return;
                        }

                        // Simulate password validation rules for general users
                        if (authPassword.length < 12 || !/[0-9]/.test(authPassword) || !/[^A-Za-z0-9]/.test(authPassword)) {
                          setFailedLoginAttempts(prev => {
                            const next = prev + 1;
                            if (next >= 3) {
                              setLockoutSecs(10);
                              logSecurityAction('UNAUTHENTICATED CLIENT', 'Brute force warning triggered: Temporary login restriction applied.');
                              return 0;
                            }
                            return next;
                          });
                          alert('❌ Password Policy Violation: Passwords must be at least 12 characters, and contain uppercase, lowercase, number, and special character symbols. Failed attempts recorded.');
                          return;
                        }
                        
                        // Valid, login as customer for demo
                        handleRoleChange('Customer');
                        setShowAuthModal(false);
                        setAuthPassword('');
                        setFailedLoginAttempts(0);
                        logSecurityAction('Karan Mehra', 'Successfully authenticated using secured 12-round bcrypt hash credentials.', 'Customer');
                      }}
                      className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition-colors cursor-pointer text-xs"
                    >
                      Secure Password Sign In
                    </button>
                  </form>
                )}

                {loginMethod === 'forgot' && (
                  <div className="space-y-4 text-xs font-bold animate-in fade-in duration-200">
                    <p className="text-[11px] text-slate-500 font-medium">Enter your corporate email. We'll dispatch a secure, 128-bit reset link to re-verify identity.</p>
                    <div className="space-y-1">
                      <label className="text-slate-600">Registered Email</label>
                      <input type="email" placeholder="procurement@hospital.com" className="w-full p-2.5 rounded-lg border text-xs focus:outline-hidden" />
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        alert('✓ Password reset key generated. Check your corporate mailbox for verification parameters.');
                        setLoginMethod('password');
                      }}
                      className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg text-xs"
                    >
                      Send Cryptographic Reset Link
                    </button>
                  </div>
                )}

              </div>
            ) : authMode === 'register' ? (
              <div className="space-y-4 text-xs font-bold">
                <div className="space-y-1">
                  <label className="text-slate-600">Hospital / Corporate Procurement Name</label>
                  <input type="text" placeholder="Karan Mehra" className="w-full p-2.5 rounded-lg border text-xs focus:outline-hidden" />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-600">Corporate Email</label>
                  <input type="email" placeholder="procurement@hospital.com" className="w-full p-2.5 rounded-lg border text-xs focus:outline-hidden" />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-600">Mobile Number (Mobile OTP binding)</label>
                  <input type="text" placeholder="+91 99887 22110" className="w-full p-2.5 rounded-lg border text-xs focus:outline-hidden" />
                </div>
                <button 
                  onClick={() => {
                    handleRoleChange('Customer');
                    setShowAuthModal(false);
                    logSecurityAction('Karan Mehra', 'Hospital procurement representative registered successfully. Email verified.', 'Customer');
                  }}
                  className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg transition-colors cursor-pointer text-xs"
                >
                  Complete Secure Verification
                </button>
              </div>
            ) : (
              <div className="space-y-4 text-center">
                <p className="text-xs text-slate-600 leading-relaxed font-semibold">
                  To register as a Supplier, use our unified Supplier Hub wizard. You must present valid trade license keys before launching devices.
                </p>
                <button
                  onClick={() => {
                    setShowAuthModal(false);
                    setActiveTab('vendor-dashboard');
                    // wait and click register vendor subtab
                    setTimeout(() => {
                      const btn = document.getElementById('vendor-tab-register');
                      if (btn) btn.click();
                    }, 50);
                  }}
                  className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-lg text-xs"
                >
                  Go to Supplier Registration Wizard
                </button>
              </div>
            )}



          </div>
        </div>
      )}

      <SecurityHub
        isOpen={showSecurityHub}
        onClose={() => setShowSecurityHub(false)}
        activityLogs={activityLogs}
        onAddLog={(user, action, role) => {
          const timestamp = new Date().toISOString().replace('T', ' ').substring(0, 16);
          setActivityLogs(prev => [
            { id: `log-${Date.now()}`, user, action, timestamp, role, ipAddress: '157.34.120.91', device: 'Chrome on macOS' },
            ...prev
          ]);
        }}
      />

    </div>
  );
}
