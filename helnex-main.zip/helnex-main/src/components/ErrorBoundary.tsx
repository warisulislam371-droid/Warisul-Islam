import React, { Component, ErrorInfo, ReactNode } from 'react';
import { ShieldAlert, RefreshCw, Terminal, Copy, Check, ArrowRight } from 'lucide-react';

interface Props {
  children: ReactNode;
  onCatchError: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  copied: boolean;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    errorInfo: null,
    copied: false
  };

  public static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    this.setState({ errorInfo });
    // Trigger the callback to register this crash into the administrative security audit logs
    this.props.onCatchError(error, errorInfo);
  }

  private handleCopyStack = () => {
    if (!this.state.error) return;
    const report = `
=== HEALNEX CLIENT-SIDE RUNTIME EXCEPTION REPORT ===
Error Name: ${this.state.error.name}
Error Message: ${this.state.error.message}
Error Stack: ${this.state.error.stack}
Component Stack: ${this.state.errorInfo?.componentStack}
Timestamp: ${new Date().toISOString()}
===================================================
    `.trim();

    navigator.clipboard.writeText(report).then(() => {
      this.setState({ copied: true });
      setTimeout(() => this.setState({ copied: false }), 2000);
    });
  };

  private handleSecureBoot = () => {
    // Clear potentially corrupted local state and perform an optimized secure reload
    localStorage.removeItem('healnex_products');
    localStorage.removeItem('healnex_vendors');
    localStorage.removeItem('healnex_orders');
    localStorage.removeItem('healnex_cart');
    localStorage.removeItem('healnex_activeTab');
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4 font-sans select-none">
          <div className="max-w-2xl w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 space-y-6 shadow-2xl animate-in zoom-in-95 duration-200">
            
            {/* Header / Threat Indicator */}
            <div className="flex items-center gap-4 border-b border-slate-800/80 pb-5">
              <div className="w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center shrink-0">
                <ShieldAlert className="w-6 h-6 text-rose-500 animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] bg-rose-500/15 text-rose-400 border border-rose-500/20 px-2 py-0.5 rounded font-mono font-bold uppercase tracking-wider">
                  WAF Threat Interception
                </span>
                <h2 className="text-base font-black text-white uppercase tracking-wider mt-1 font-mono">
                  UI Rendering Crash Intercepted
                </h2>
              </div>
            </div>

            {/* Error Briefing */}
            <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl space-y-1.5 font-mono text-xs">
              <p className="text-slate-500 uppercase font-black text-[9px] tracking-wider">Exception Type</p>
              <p className="text-rose-400 font-bold">{this.state.error?.name || 'Error'}</p>
              
              <p className="text-slate-500 uppercase font-black text-[9px] tracking-wider pt-2">Exception Message</p>
              <p className="text-slate-200 leading-relaxed">{this.state.error?.message || 'A client-side runtime script crash was caught.'}</p>
            </div>

            {/* Error Trace Sandbox Tab */}
            <div className="space-y-1">
              <div className="flex justify-between items-center px-1">
                <span className="text-[9px] text-slate-500 uppercase font-black tracking-wider flex items-center gap-1">
                  <Terminal className="w-3.5 h-3.5 text-blue-500" />
                  <span>Interactive Exception Trace</span>
                </span>
                <button
                  onClick={this.handleCopyStack}
                  className="flex items-center gap-1.5 text-[10px] text-slate-400 hover:text-white transition-colors cursor-pointer"
                >
                  {this.state.copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-bold">Trace Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Diagnostic Report</span>
                    </>
                  )}
                </button>
              </div>

              <div className="max-h-48 overflow-y-auto bg-slate-950/80 border border-slate-850 rounded-xl p-4 font-mono text-[10px] text-slate-400 space-y-3 leading-relaxed">
                <div>
                  <p className="text-slate-600 font-bold">// Stack Trace</p>
                  <pre className="whitespace-pre-wrap break-all text-slate-300 mt-1">
                    {this.state.error?.stack || 'No trace available'}
                  </pre>
                </div>
                {this.state.errorInfo?.componentStack && (
                  <div>
                    <p className="text-slate-600 font-bold">// Component Hierarchy Trace</p>
                    <pre className="whitespace-pre-wrap break-all text-slate-400 mt-1">
                      {this.state.errorInfo.componentStack}
                    </pre>
                  </div>
                )}
              </div>
            </div>

            {/* Threat Mitigation Actions */}
            <div className="space-y-3 pt-2">
              <p className="text-[10px] text-slate-400 font-semibold leading-relaxed text-center">
                The incident has been logged into the **HealNex Immutable Audit Ledger**. Access rights, device profiles, and telemetry packets have been stored for Admin evaluation.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <button
                  onClick={() => window.location.reload()}
                  className="flex items-center justify-center gap-2 py-2.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 hover:text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Reload Page Buffer</span>
                </button>
                <button
                  onClick={this.handleSecureBoot}
                  className="flex items-center justify-center gap-2 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-black rounded-xl transition-all cursor-pointer shadow-lg shadow-rose-950/20"
                >
                  <span>Secure-Boot Recovery Reset</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
