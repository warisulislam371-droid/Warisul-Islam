import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  ShieldCheck, 
  Key, 
  Lock, 
  RefreshCw, 
  Database, 
  Smartphone, 
  Globe, 
  Server, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  X, 
  Terminal, 
  Fingerprint, 
  Activity,
  Cpu
} from 'lucide-react';
import { ActivityLog } from '../types';

interface SecurityHubProps {
  isOpen: boolean;
  onClose: () => void;
  activityLogs: ActivityLog[];
  onAddLog: (user: string, action: string, role?: string) => void;
}

export default function SecurityHub({ isOpen, onClose, activityLogs, onAddLog }: SecurityHubProps) {
  // Input Validation Sandbox state
  const [testInput, setTestInput] = useState('');
  const [sanitizedResult, setSanitizedResult] = useState('');
  const [attackTypeDetected, setAttackTypeDetected] = useState<string | null>(null);

  // 2FA Authenticator state
  const [totpCode, setTotpCode] = useState('489 102');
  const [totpProgress, setTotpProgress] = useState(18);

  // Active sessions state
  const [sessions, setSessions] = useState([
    { id: 'sess-1', device: 'Chrome on macOS (Mumbai)', ip: '157.34.120.91', active: true, location: 'Mumbai, IN' },
    { id: 'sess-2', device: 'Safari on iPhone (Delhi)', ip: '103.88.22.14', active: false, location: 'New Delhi, IN' },
    { id: 'sess-3', device: 'Firefox on Windows (Kolkata)', ip: '49.207.181.5', active: false, location: 'Kolkata, IN' }
  ]);

  // Backups state
  const [backupLogs, setBackupLogs] = useState([
    { filename: 'HN_BAK_20260712_0200.sql', size: '12.4 MB', date: '2026-07-12 02:00', type: 'Daily Incremental' },
    { filename: 'HN_BAK_20260711_0200.sql', size: '12.3 MB', date: '2026-07-11 02:00', type: 'Daily Incremental' },
    { filename: 'HN_BAK_20260705_0000.sql', size: '84.8 MB', date: '2026-07-05 00:00', type: 'Weekly Full Archive' }
  ]);
  const [restoringFile, setRestoringFile] = useState<string | null>(null);
  const [restoreProgress, setRestoreProgress] = useState(0);

  // TOTP code generator simulation
  useEffect(() => {
    const timer = setInterval(() => {
      setTotpProgress((prev) => {
        if (prev <= 1) {
          // Generate new code
          const newCode = Math.floor(100000 + Math.random() * 900000).toString();
          setTotpCode(`${newCode.substring(0, 3)} ${newCode.substring(3, 6)}`);
          return 30;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Live Input sanitization simulation
  const handleTestInput = (val: string) => {
    setTestInput(val);
    let result = val;
    let attack = null;

    if (val.toLowerCase().includes('select') || val.toLowerCase().includes('union') || val.toLowerCase().includes("'") || val.toLowerCase().includes('or 1=1')) {
      attack = 'SQL Injection (SQLi)';
      // Sanitize SQL characters
      result = result.replace(/['"\\;]/g, '').replace(/or\s+1\s*=\s*1/gi, '[blocked]');
    } else if (val.toLowerCase().includes('<script>') || val.toLowerCase().includes('javascript:') || val.toLowerCase().includes('onload=') || val.toLowerCase().includes('onerror=')) {
      attack = 'Cross-Site Scripting (XSS)';
      // HTML Entity encoding
      result = result.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/script/gi, '[stripped]');
    } else if (val.toLowerCase().includes('sh ') || val.toLowerCase().includes('rm -') || val.toLowerCase().includes('curl ')) {
      attack = 'Command Injection';
      result = '[CMD EXPR STRIPPED]';
    }

    setAttackTypeDetected(attack);
    setSanitizedResult(result);
  };

  // Session revoke simulation
  const handleRevokeSession = (id: string, device: string) => {
    setSessions(sessions.filter(s => s.id !== id));
    onAddLog('SYSTEM SECURITY', `Revoked active user session key on remote device: ${device}`, 'Customer');
  };

  // Restore backup simulation
  const handleRestoreBackup = (filename: string) => {
    setRestoringFile(filename);
    setRestoreProgress(0);
    onAddLog('SUPER ADMIN', `Initiated full system roll-back restore from safe archive: ${filename}`, 'Super Admin');

    const interval = setInterval(() => {
      setRestoreProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setRestoringFile(null);
            alert(`✓ Database integrity restore from ${filename} completed successfully. Local storage tables synchronized.`);
          }, 400);
          return 100;
        }
        return prev + 10;
      });
    }, 150);
  };

  // Create new manual backup
  const handleCreateNewBackup = () => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const filename = `HN_BAK_MANUAL_${Date.now().toString().substring(6)}.sql`;
    const newBak = {
      filename,
      size: '12.5 MB',
      date: now,
      type: 'Manual Ad-hoc Backup'
    };
    setBackupLogs([newBak, ...backupLogs]);
    onAddLog('SUPER ADMIN', `Dispatched standard hot-backup creation command. Secure archive saved: ${filename}`, 'Super Admin');
    alert(`✓ Real-time medical catalog table state snapshot completed. File: ${filename}`);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl animate-in zoom-in-95 duration-150">
        
        {/* Header bar */}
        <div className="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center">
              <Shield className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-widest font-mono">HealNex Enterprise Trust Center</h3>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold mt-0.5 font-mono">Active Defense Core v4.11-Prod</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            id="close-security-hub"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Tabs area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* Core Security Badges / Trust indicators */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex gap-3 items-start">
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-slate-100">PCI DSS Standard</p>
                <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">No raw card digits cached. Full Stripe tokenization integration.</p>
              </div>
            </div>
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex gap-3 items-start">
              <Lock className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-slate-100">TLS 1.3 Encryption</p>
                <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">End-to-end data transmission packets encrypted with perfect secrecy.</p>
              </div>
            </div>
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex gap-3 items-start">
              <Key className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-slate-100">Bcrypt Password Hash</p>
                <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">12-rounds salt algorithm shields hospital logins against brute-force.</p>
              </div>
            </div>
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex gap-3 items-start">
              <Database className="w-5 h-5 text-purple-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-slate-100">Secure Audit Ledger</p>
                <p className="text-[10px] text-slate-400 mt-1 leading-relaxed">Immutable timestamp logs track administrative and pricing updates.</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

            {/* Column 1: Verification, 2FA, Active Sessions */}
            <div className="space-y-6 md:col-span-2">
              
              {/* Active Sessions Panel */}
              <div className="border border-slate-800 rounded-xl bg-slate-950 p-5 space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-emerald-400" />
                    <h4 className="text-xs font-black uppercase text-slate-200 tracking-wider font-mono">Active Device Sessions</h4>
                  </div>
                  <span className="text-[9px] bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded font-mono font-bold">Secure Cookie Binding</span>
                </div>

                <div className="divide-y divide-slate-800/80 text-xs">
                  {sessions.map((s) => (
                    <div key={s.id} className="py-3 first:pt-0 last:pb-0 flex justify-between items-center gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-200">{s.device}</span>
                          {s.active && (
                            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[8px] font-black px-1.5 py-0.2 rounded uppercase">This Device</span>
                          )}
                        </div>
                        <p className="text-[10px] text-slate-500 mt-0.5 font-mono">IP: {s.ip} • Loc: {s.location}</p>
                      </div>
                      {!s.active && (
                        <button
                          onClick={() => handleRevokeSession(s.id, s.device)}
                          className="px-2.5 py-1 bg-rose-900/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 hover:border-rose-700 text-[10px] font-bold rounded"
                        >
                          Revoke
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Input Sanitizer / Injection Shield Live Sandbox */}
              <div className="border border-slate-800 rounded-xl bg-slate-950 p-5 space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-blue-400" />
                    <h4 className="text-xs font-black uppercase text-slate-200 tracking-wider font-mono">WAF Input Sanitizer Sandbox</h4>
                  </div>
                  <span className="text-[9px] bg-blue-500/10 text-blue-400 px-2 py-0.5 rounded font-mono font-bold">XSS / SQLi Interceptor</span>
                </div>

                <p className="text-[11px] text-slate-400 leading-relaxed font-medium">
                  Type malicious scripts or SQL expressions in the tester below to observe the HealNex Web Application Firewall (WAF) filter raw query fields instantaneously.
                </p>

                <div className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-[9px] text-slate-500 uppercase font-bold">Simulated Client Input Payload</label>
                    <input 
                      type="text"
                      placeholder="e.g. <script>alert('hack')</script> or ' OR 1=1 --"
                      value={testInput}
                      onChange={(e) => handleTestInput(e.target.value)}
                      className="w-full p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 placeholder-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-[11px]">
                    <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-850 space-y-1">
                      <span className="text-[9px] text-slate-500 uppercase font-black tracking-wider block">Threat Auditing Status</span>
                      {attackTypeDetected ? (
                        <div className="flex items-center gap-1.5 text-rose-400 font-bold">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          <span>Detected {attackTypeDetected}!</span>
                        </div>
                      ) : testInput ? (
                        <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                          <CheckCircle className="w-3.5 h-3.5" />
                          <span>Payload Clean (Passed)</span>
                        </div>
                      ) : (
                        <span className="text-slate-600 italic">Awaiting Input...</span>
                      )}
                    </div>

                    <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-850 space-y-1">
                      <span className="text-[9px] text-slate-500 uppercase font-black tracking-wider block">Sanitized Buffer Written</span>
                      {testInput ? (
                        <code className="text-emerald-400 block font-mono font-bold break-all">{sanitizedResult}</code>
                      ) : (
                        <span className="text-slate-600 italic">No buffer written...</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

            </div>

            {/* Column 2: 2FA Simulator, Backups */}
            <div className="space-y-6">

              {/* 2FA Authenticator Widget */}
              <div className="border border-slate-800 rounded-xl bg-slate-950 p-5 space-y-4">
                <div className="flex items-center gap-2">
                  <Fingerprint className="w-4 h-4 text-blue-400" />
                  <h4 className="text-xs font-black uppercase text-slate-200 tracking-wider font-mono">MFA Multi-Factor TOTP</h4>
                </div>

                <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-center space-y-3">
                  <p className="text-[10px] text-slate-400 font-mono uppercase tracking-widest font-black">Admin / Vendor 2FA Code</p>
                  
                  <div className="text-2xl font-black font-mono tracking-widest text-blue-400 animate-pulse">
                    {totpCode}
                  </div>

                  <div className="flex items-center justify-center gap-2 text-[10px] text-slate-500 font-mono font-semibold">
                    <Clock className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                    <span>Rotates in {totpProgress}s</span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-slate-850 h-1.5 rounded-full overflow-hidden">
                    <div 
                      className="bg-blue-500 h-full transition-all duration-1000 ease-linear"
                      style={{ width: `${(totpProgress / 30) * 100}%` }}
                    ></div>
                  </div>
                </div>

                <p className="text-[10px] text-slate-500 leading-relaxed font-semibold">
                  MFA security intercepts administrative panel loads and custom pricing adjustments. Fully compatible with Google Authenticator standard RFC 6238 key generation.
                </p>
              </div>

              {/* Disaster Recovery Backups Console */}
              <div className="border border-slate-800 rounded-xl bg-slate-950 p-5 space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <Database className="w-4 h-4 text-purple-400" />
                    <h4 className="text-xs font-black uppercase text-slate-200 tracking-wider font-mono">System Recovery Backups</h4>
                  </div>
                  <button 
                    onClick={handleCreateNewBackup}
                    className="p-1 text-slate-400 hover:text-white hover:bg-slate-850 rounded"
                    title="Snapshot Now"
                  >
                    <Cpu className="w-4 h-4 text-purple-400" />
                  </button>
                </div>

                {restoringFile ? (
                  <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 text-center space-y-2 text-xs">
                    <div className="flex items-center justify-center gap-2 font-mono">
                      <RefreshCw className="w-4 h-4 text-purple-400 animate-spin" />
                      <span className="font-bold text-slate-200 uppercase">Restoring {restoringFile}...</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-purple-500 h-full transition-all" style={{ width: `${restoreProgress}%` }}></div>
                    </div>
                    <span className="text-[9px] text-slate-500 font-mono">{restoreProgress}% block-level integrity match</span>
                  </div>
                ) : (
                  <div className="space-y-2.5 text-[10px] font-mono">
                    {backupLogs.map((b) => (
                      <div key={b.filename} className="p-2.5 bg-slate-900/80 rounded-lg border border-slate-850 flex justify-between items-center gap-2">
                        <div className="space-y-0.5">
                          <p className="font-bold text-slate-200 truncate max-w-[130px]">{b.filename}</p>
                          <p className="text-slate-500 font-semibold">{b.type} ({b.size})</p>
                        </div>
                        <button
                          onClick={() => handleRestoreBackup(b.filename)}
                          className="px-2 py-1 bg-purple-900/40 hover:bg-purple-900/60 text-purple-300 border border-purple-800/40 hover:border-purple-600 text-[9px] font-black rounded cursor-pointer"
                        >
                          Restore
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <button
                  onClick={handleCreateNewBackup}
                  className="w-full py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-200 hover:text-white text-[10px] font-black uppercase rounded-lg transition-colors cursor-pointer"
                >
                  Hot-Backup Snapshot Database
                </button>
              </div>

            </div>

          </div>

          {/* Security Headers matrix compliance and diagnostics */}
          <div className="border border-slate-800 rounded-xl bg-slate-950 p-5 space-y-4 text-xs font-mono">
            <h4 className="text-xs font-black uppercase text-slate-200 tracking-wider flex items-center gap-1.5">
              <Server className="w-4 h-4 text-indigo-400" />
              <span>HTTP Compliance Network Security Headers Checklist</span>
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
              {[
                { name: 'HTTPS Enforcement', val: 'Active (TLS_1.3)' },
                { name: 'HSTS Max-Age', val: 'Enabled (31536000)' },
                { name: 'CSP Filter', val: 'Strict (No-Inline)' },
                { name: 'X-Frame-Options', val: 'SAMEORIGIN' },
                { name: 'Referrer-Policy', val: 'Strict-Origin' }
              ].map((h) => (
                <div key={h.name} className="p-2.5 bg-slate-900 border border-slate-850 rounded-lg space-y-1">
                  <span className="text-[8px] text-slate-500 uppercase font-black block leading-tight">{h.name}</span>
                  <span className="text-[10px] text-emerald-400 font-bold block">{h.val}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Console Footing */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 text-center text-[10px] text-slate-500 font-mono">
          <p>HealNex Med Bazar Platform Trust Monitor • Encrypted via AES-256-GCM Session Keys</p>
        </div>

      </div>
    </div>
  );
}
