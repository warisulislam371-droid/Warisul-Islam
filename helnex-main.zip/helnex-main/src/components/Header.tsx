import React, { useState } from 'react';
import { 
  Search, 
  ShoppingBag, 
  Heart, 
  Bell, 
  Store, 
  User, 
  LogOut, 
  LayoutDashboard, 
  ChevronDown, 
  UserCheck, 
  Settings, 
  Package, 
  ClipboardList, 
  IndianRupee,
  ShieldCheck
} from 'lucide-react';
import { CATEGORIES } from '../data/mockData';

interface HeaderProps {
  currentRole: 'Guest' | 'Customer' | 'Vendor' | 'Admin';
  userName: string;
  cartCount: number;
  wishlistCount: number;
  notificationCount: number;
  onSearchChange: (val: string) => void;
  onCategorySelect: (catId: string) => void;
  selectedCategory: string;
  onRoleChange: (role: 'Guest' | 'Customer' | 'Vendor' | 'Admin') => void;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenNotifications: () => void;
  onNavigate: (page: string) => void;
  activeTab: string;
  onLoginClick: () => void;
  onRegisterClick: () => void;
  onBecomeVendorClick: () => void;
  onOpenSecurityHub: () => void;
}

export default function Header({
  currentRole,
  userName,
  cartCount,
  wishlistCount,
  notificationCount,
  onSearchChange,
  onCategorySelect,
  selectedCategory,
  onRoleChange,
  onOpenCart,
  onOpenWishlist,
  onOpenNotifications,
  onNavigate,
  activeTab,
  onLoginClick,
  onRegisterClick,
  onBecomeVendorClick,
  onOpenSecurityHub
}: HeaderProps) {
  const [showCatMenu, setShowCatMenu] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      {/* Top Banner Alert / Role Switcher for Testability */}
      <div className="bg-slate-950 text-white text-[11px] py-1.5 px-4 flex flex-wrap justify-between items-center gap-2 border-b border-slate-800">
        <div className="flex items-center gap-3 font-mono text-slate-300">
          <div className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>HealNex Sandbox Mode</span>
          </div>
          <button
            onClick={onOpenSecurityHub}
            className="flex items-center gap-1 px-2 py-0.5 bg-blue-900/80 hover:bg-blue-800 text-blue-200 hover:text-white rounded text-[10px] font-sans font-bold border border-blue-800 transition-all cursor-pointer"
            id="header-security-hub-btn"
          >
            <ShieldCheck className="w-3 h-3 text-blue-400" />
            <span>🔒 Trust & Security Hub</span>
          </button>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-sans">Active Role:</span>
          <span className="px-2.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] font-mono font-bold text-blue-400">
            {currentRole}
          </span>
        </div>
      </div>

      {/* Main Header Container */}
      <div className="max-w-7xl mx-auto px-4 lg:px-6 py-3 flex flex-col md:flex-row gap-4 items-center justify-between">
        {/* Left Side: Logo */}
        <div 
          onClick={() => onNavigate('home')} 
          className="flex items-center gap-2.5 cursor-pointer select-none group"
          id="hn-logo-btn"
        >
          <div className="w-9 h-9 rounded-lg bg-slate-950 flex items-center justify-center group-hover:bg-slate-800 transition-colors">
            <span className="text-white font-black text-lg tracking-tighter flex items-center justify-center font-display">
              HN
            </span>
          </div>
          <div>
            <span className="text-lg font-bold tracking-tight text-slate-900 block leading-none font-display">
              Heal<span className="text-emerald-600 font-semibold">Nex</span>
            </span>
            <span className="text-[9px] font-mono tracking-widest text-slate-400 uppercase font-bold block mt-0.5">
              MED BAZAR
            </span>
          </div>
        </div>

        {/* Center: Category & Search Bar */}
        <div className="flex-1 max-w-xl w-full flex items-center gap-2 border border-slate-200 rounded-lg px-2.5 py-1.5 bg-slate-50/50 focus-within:border-slate-800 focus-within:bg-white focus-within:ring-2 focus-within:ring-slate-150 transition-all">
          
          {/* Category Dropdown inside Search Bar */}
          <div className="relative">
            <button
              onClick={() => setShowCatMenu(!showCatMenu)}
              className="flex items-center gap-1 px-2.5 py-0.5 text-xs font-semibold text-slate-600 hover:text-slate-900 border-r border-slate-200 select-none whitespace-nowrap"
              id="category-dropdown-btn"
            >
              {selectedCategory === 'all' 
                ? 'All Categories' 
                : CATEGORIES.find(c => c.id === selectedCategory)?.name || 'All'}
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showCatMenu && (
              <div className="absolute top-full left-0 mt-2 w-60 bg-white border border-slate-200 rounded-lg shadow-md py-1.5 z-50 animate-in fade-in duration-100">
                <button
                  onClick={() => {
                    onCategorySelect('all');
                    setShowCatMenu(false);
                  }}
                  className={`w-full text-left px-3.5 py-1.5 text-xs font-medium ${
                    selectedCategory === 'all' ? 'bg-slate-100 text-slate-900' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  All Categories
                </button>
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      onCategorySelect(cat.id);
                      setShowCatMenu(false);
                    }}
                    className={`w-full text-left px-3.5 py-1.5 text-xs font-medium flex items-center justify-between ${
                      selectedCategory === cat.id ? 'bg-slate-100 text-slate-900' : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span>{cat.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Search Input */}
          <div className="flex-1 flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <input
              type="text"
              placeholder="Search equipment, diagnostics, ICU products..."
              className="w-full bg-transparent border-none text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden"
              onChange={(e) => onSearchChange(e.target.value)}
              id="search-input-box"
            />
          </div>
        </div>

        {/* Upper Right Corner - Actions based on Role */}
        <div className="flex items-center gap-3 shrink-0">
          
          {/* Guest Role View */}
          {currentRole === 'Guest' && (
            <div className="flex items-center gap-2">
              <button 
                onClick={onBecomeVendorClick}
                className="hidden lg:flex items-center gap-1 px-3 py-1.5 bg-emerald-50/50 hover:bg-emerald-50 text-emerald-800 text-xs font-semibold rounded-lg transition-colors border border-emerald-100"
                id="header-become-vendor-btn"
              >
                <Store className="w-3.5 h-3.5 text-emerald-600" />
                Become Vendor
              </button>
              <button 
                onClick={onLoginClick}
                className="px-3 py-1.5 text-xs font-medium text-slate-700 hover:text-slate-900 border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors"
                id="header-login-btn"
              >
                Login
              </button>
              <button 
                onClick={onRegisterClick}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium rounded-lg transition-all"
                id="header-register-btn"
              >
                Register
              </button>
            </div>
          )}

          {/* Customer Role View */}
          {currentRole === 'Customer' && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('customer-dashboard')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  activeTab === 'customer-dashboard' 
                    ? 'bg-slate-100 text-slate-900 font-semibold' 
                    : 'text-slate-600 hover:bg-slate-50'
                }`}
                id="cust-nav-dashboard"
              >
                <User className="w-3.5 h-3.5 text-slate-500" />
                My Account
              </button>
              <button
                onClick={() => {
                  onNavigate('customer-dashboard');
                  setTimeout(() => {
                    const btn = document.getElementById('cust-tab-orders');
                    if (btn) btn.click();
                  }, 50);
                }}
                className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-50"
                id="cust-nav-orders"
              >
                <ClipboardList className="w-3.5 h-3.5 text-slate-500" />
                My Orders
              </button>
            </div>
          )}

          {/* Vendor Role View */}
          {currentRole === 'Vendor' && (
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => onNavigate('vendor-dashboard')}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-900 text-white hover:bg-slate-800 transition-colors`}
                id="vendor-nav-dashboard"
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                Dashboard
              </button>
              <button
                onClick={() => {
                  onNavigate('vendor-dashboard');
                  setTimeout(() => {
                    const btn = document.getElementById('vendor-tab-products');
                    if (btn) btn.click();
                  }, 50);
                }}
                className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-50"
                id="vendor-nav-products"
              >
                <Package className="w-3.5 h-3.5 text-slate-500" />
                Products
              </button>
              <button
                onClick={() => {
                  onNavigate('vendor-dashboard');
                  setTimeout(() => {
                    const btn = document.getElementById('vendor-tab-orders');
                    if (btn) btn.click();
                  }, 50);
                }}
                className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-50"
                id="vendor-nav-orders"
              >
                <ClipboardList className="w-3.5 h-3.5 text-slate-500" />
                Orders
              </button>
              <button
                onClick={() => {
                  onNavigate('vendor-dashboard');
                  setTimeout(() => {
                    const btn = document.getElementById('vendor-tab-earnings');
                    if (btn) btn.click();
                  }, 50);
                }}
                className="hidden md:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-50"
                id="vendor-nav-earnings"
              >
                <IndianRupee className="w-3.5 h-3.5 text-slate-500" />
                Earnings
              </button>
            </div>
          )}

          {/* Admin Role View */}
          {currentRole === 'Admin' && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('admin-dashboard')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 text-white hover:bg-slate-800 transition-colors`}
                id="admin-nav-dashboard"
              >
                <UserCheck className="w-3.5 h-3.5" />
                Admin Panel
              </button>
            </div>
          )}

          {/* Standard Utility Icons for Guest & Customers */}
          <div className="flex items-center gap-1 border-l border-slate-200 pl-2.5">
            
            {/* Wishlist Button (Always show for guest and customers) */}
            {(currentRole === 'Guest' || currentRole === 'Customer') && (
              <button
                onClick={onOpenWishlist}
                className="relative p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer"
                title="Wishlist"
                id="header-wishlist-icon"
              >
                <Heart className="w-4 h-4" />
                {wishlistCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-slate-900 text-white text-[8px] font-black rounded-full flex items-center justify-center">
                    {wishlistCount}
                  </span>
                )}
              </button>
            )}

            {/* Shopping Cart Button */}
            {(currentRole === 'Guest' || currentRole === 'Customer') && (
              <button
                onClick={onOpenCart}
                className="relative p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer"
                title="Shopping Cart"
                id="header-cart-icon"
              >
                <ShoppingBag className="w-4 h-4" />
                {cartCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-slate-900 text-white text-[8px] font-black rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>
            )}

            {/* Notification Alert Bell */}
            <button
              onClick={onOpenNotifications}
              className="relative p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer"
              title="Notifications"
              id="header-bell-icon"
            >
              <Bell className="w-4 h-4" />
              {notificationCount > 0 && (
                <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
              )}
            </button>

            {/* Log Out button for Authenticated Roles */}
            {currentRole !== 'Guest' && (
              <button
                onClick={() => onRoleChange('Guest')}
                className="p-1.5 rounded-lg text-rose-500 hover:text-rose-700 hover:bg-rose-50/50 transition-colors cursor-pointer ml-0.5"
                title="Log Out"
                id="header-logout-btn"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>

        </div>
      </div>
    </header>
  );
}
