import React, { useState } from 'react';
import { 
  FileSpreadsheet, 
  Download, 
  Upload, 
  CheckCircle, 
  AlertTriangle, 
  Check, 
  X, 
  PlusCircle 
} from 'lucide-react';
import { Vendor, Product } from '../types';
import { CATEGORIES } from '../data/mockData';

interface BulkUploadProps {
  activeVendor: Vendor | null;
  onAddProduct: (newProduct: Omit<Product, 'id' | 'vendorId' | 'vendorName' | 'rating' | 'approved'> & { vendorId?: string; vendorName?: string }) => void;
  onSuccess: (count: number) => void;
}

export const BulkUpload: React.FC<BulkUploadProps> = ({ 
  activeVendor, 
  onAddProduct,
  onSuccess
}) => {
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [csvFileName, setCsvFileName] = useState<string>('');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [csvData, setCsvData] = useState<any[]>([]);
  const [csvErrors, setCsvErrors] = useState<string[]>([]);
  const [csvStatusMessage, setCsvStatusMessage] = useState<string>('');
  const [csvUploadSuccess, setCsvUploadSuccess] = useState<boolean>(false);

  // CSV Template Downloader
  const downloadTemplateCSV = () => {
    const csvContent = "SKU,Name,MRP,Vendor Price,Stock,Category,Brand,Description,MOQ,GST Rate\n" +
      "SKU-DEL-VENT88,ICU Respiratory Ventilator v2,185000,120000,12,ICU Equipment,ApexTech,Dual compressor intensive care medical grade ventilator.,1,18\n" +
      "SKU-DEL-ECG05,12-Channel Portable ECG Monitor,45000,32000,25,ECG Machine,HealHealth,Lightweight 12-channel electrocardiograph with thermo printer.,2,12\n" +
      "SKU-DEL-OXCON3,Medical Oxygen Concentrator 10L,68000,45000,30,Homecare Devices,OxigenX,High purity 93% oxygen concentrator dual flow outlet.,1,18";
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "HealNex_Bulk_Product_Template.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle Drag & Drop and manual file uploading
  const handleCsvFileUpload = (file: File) => {
    if (!file.name.endsWith('.csv')) {
      setCsvErrors(['Only standard .csv files are supported. Please verify file extension.']);
      return;
    }
    setCsvFile(file);
    setCsvFileName(file.name);
    setCsvErrors([]);
    setCsvData([]);
    setCsvUploadSuccess(false);
    setCsvStatusMessage('');

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) {
        setCsvErrors(['Could not read file content.']);
        return;
      }
      processCsvText(text);
    };
    reader.onerror = () => {
      setCsvErrors(['Error reading the CSV file.']);
    };
    reader.readAsText(file);
  };

  const processCsvText = (text: string) => {
    try {
      const cleanText = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
      const lines = cleanText.split('\n').filter(line => line.trim().length > 0);
      
      if (lines.length < 2) {
        setCsvErrors(['The uploaded CSV is empty or only contains headers. Please fill in some data rows.']);
        return;
      }

      // Pure JS CSV line splitter that respects surrounding quotes
      const parseLine = (line: string): string[] => {
        const result: string[] = [];
        let cur = '';
        let insideQuote = false;
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          if (char === '"') {
            insideQuote = !insideQuote;
          } else if (char === ',' && !insideQuote) {
            result.push(cur.trim());
            cur = '';
          } else {
            cur += char;
          }
        }
        result.push(cur.trim());
        return result;
      };

      const headers = parseLine(lines[0]);
      
      // Mandatory headers check: SKU, Name, MRP, Vendor Price, Stock (case-insensitive & whitespace normalized)
      const normalizedHeaders = headers.map(h => h.toLowerCase().replace(/_/g, ' ').replace(/\s+/g, ' ').trim());
      
      const requiredFields = ['sku', 'name', 'mrp', 'vendor price', 'stock'];
      const missingFields = requiredFields.filter(f => !normalizedHeaders.includes(f));

      if (missingFields.length > 0) {
        setCsvErrors([
          `Validation Failed: The CSV is missing mandatory columns: ${missingFields.map(f => `"${f.toUpperCase()}"`).join(', ')}.`,
          `Detected columns in your file: ${headers.map(h => `"${h}"`).join(', ')}. Please use our official CSV template.`
        ]);
        return;
      }

      // Find indices of headers
      const idxSku = normalizedHeaders.indexOf('sku');
      const idxName = normalizedHeaders.indexOf('name');
      const idxMrp = normalizedHeaders.indexOf('mrp');
      const idxVendorPrice = normalizedHeaders.indexOf('vendor price');
      const idxStock = normalizedHeaders.indexOf('stock');
      
      // Optional headers
      const idxCategory = normalizedHeaders.indexOf('category');
      const idxBrand = normalizedHeaders.indexOf('brand');
      const idxDescription = normalizedHeaders.indexOf('description');
      const idxMoq = normalizedHeaders.indexOf('moq');
      const idxGst = normalizedHeaders.indexOf('gst rate');

      const parsedRows: any[] = [];

      for (let i = 1; i < lines.length; i++) {
        const rowData = parseLine(lines[i]);
        // Skip empty lines
        if (rowData.length === 0 || (rowData.length === 1 && rowData[0] === '')) continue;

        const rowNum = i + 1;
        const currentErrors: string[] = [];

        const sku = rowData[idxSku] || '';
        const name = rowData[idxName] || '';
        const mrpStr = rowData[idxMrp] || '';
        const vendorPriceStr = rowData[idxVendorPrice] || '';
        const stockStr = rowData[idxStock] || '';

        // Validation logic
        if (!sku) {
          currentErrors.push('SKU code is mandatory.');
        }
        if (!name) {
          currentErrors.push('Product Name is mandatory.');
        }

        const mrp = parseFloat(mrpStr);
        if (isNaN(mrp) || mrp <= 0) {
          currentErrors.push(`Invalid MRP: "${mrpStr}". Must be positive number.`);
        }

        const vendorPrice = parseFloat(vendorPriceStr);
        if (isNaN(vendorPrice) || vendorPrice <= 0) {
          currentErrors.push(`Invalid Vendor Price: "${vendorPriceStr}". Must be positive number.`);
        }

        const stock = parseInt(stockStr);
        if (isNaN(stock) || stock < 0) {
          currentErrors.push(`Invalid Stock: "${stockStr}". Must be 0 or higher integer.`);
        }

        if (!isNaN(mrp) && !isNaN(vendorPrice) && mrp < vendorPrice) {
          currentErrors.push(`Price mismatch: MRP (₹${mrp}) cannot be lower than the Vendor Price (₹${vendorPrice}).`);
        }

        const category = idxCategory !== -1 && rowData[idxCategory] ? rowData[idxCategory] : 'ICU Equipment';
        const brand = idxBrand !== -1 && rowData[idxBrand] ? rowData[idxBrand] : activeVendor?.businessName || 'ApexTech';
        const description = idxDescription !== -1 && rowData[idxDescription] ? rowData[idxDescription] : `${name} medical device listed under brand ${brand}.`;
        const moq = idxMoq !== -1 && rowData[idxMoq] ? parseInt(rowData[idxMoq]) || 1 : 1;
        const gstRate = idxGst !== -1 && rowData[idxGst] ? parseFloat(rowData[idxGst]) || 18 : 18;

        parsedRows.push({
          rowNum,
          sku,
          name,
          mrp,
          vendorPrice,
          stock,
          category,
          brand,
          description,
          moq,
          gstRate,
          isValid: currentErrors.length === 0,
          errors: currentErrors
        });
      }

      setCsvData(parsedRows);
    } catch (e: any) {
      setCsvErrors([`Internal parsing error: ${e.message}. Please check your CSV formatting.`]);
    }
  };

  const handleConfirmCsvUpload = () => {
    const validRows = csvData.filter(r => r.isValid);
    if (validRows.length === 0) {
      alert('Cannot import products: Zero valid rows detected. Please resolve template warnings or headers.');
      return;
    }

    validRows.forEach(row => {
      onAddProduct({
        name: row.name,
        sku: row.sku,
        category: row.category,
        brand: row.brand,
        description: row.description,
        imageUrl: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=400',
        stock: row.stock,
        mrp: row.mrp,
        vendorPrice: row.vendorPrice,
        sellingPrice: row.vendorPrice,
        moq: row.moq,
        gstRate: row.gstRate,
        commissionPercent: 10,
        customerPrice: Math.round(row.vendorPrice * 1.1),
        vendorId: activeVendor?.id,
        vendorName: activeVendor?.businessName
      });
    });

    const parsedCount = validRows.length;
    setCsvUploadSuccess(true);
    setCsvStatusMessage(`✓ Successfully parsed and imported ${parsedCount} clinical devices to the Super Admin approval queues!`);
    onSuccess(parsedCount);

    // Reset states after visual notification
    setTimeout(() => {
      setCsvFile(null);
      setCsvFileName('');
      setCsvData([]);
      setCsvErrors([]);
      setCsvUploadSuccess(false);
      setCsvStatusMessage('');
    }, 4000);
  };

  return (
    <div className="space-y-6">
      {csvUploadSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold flex items-start gap-2.5 animate-in zoom-in-95">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-extrabold uppercase text-[10px] tracking-wider text-emerald-950">Bulk Import Dispatched</p>
            <p className="mt-1 font-semibold">{csvStatusMessage}</p>
          </div>
        </div>
      )}

      {csvErrors.length > 0 && (
        <div className="p-4 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs font-bold space-y-2">
          <div className="flex items-center gap-2 text-rose-950 uppercase text-[10px] tracking-wider font-extrabold">
            <AlertTriangle className="w-4 h-4 text-rose-600" />
            <span>Spreadsheet Import Warning</span>
          </div>
          <ul className="list-disc pl-5 space-y-1 font-medium text-[11px] leading-relaxed">
            {csvErrors.map((err, idx) => (
              <li key={idx}>{err}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        {/* Step 1: Template Info */}
        <div className="md:col-span-2 p-4 bg-white rounded-xl border border-slate-200/80 space-y-4">
          <div className="space-y-1">
            <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider">Step 1</span>
            <h4 className="text-xs font-black text-slate-900 uppercase">Download CSV Schema</h4>
            <p className="text-[10px] text-slate-500 font-semibold leading-relaxed">
              Download our predefined catalog template. The following column structures are validated prior to insertion:
            </p>
          </div>

          <div className="space-y-2.5 font-mono text-[10px] font-semibold">
            <div className="p-2.5 bg-slate-50 rounded-lg border space-y-1.5">
              <p className="text-[9px] text-slate-400 uppercase tracking-widest">Mandatory Headers</p>
              <div className="flex flex-wrap gap-1">
                {['SKU', 'Name', 'MRP', 'Vendor Price', 'Stock'].map(h => (
                  <span key={h} className="bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded border border-blue-100">{h}</span>
                ))}
              </div>
            </div>

            <div className="p-2.5 bg-slate-50 rounded-lg border space-y-1.5">
              <p className="text-[9px] text-slate-400 uppercase tracking-widest">Optional Headers (Fallback-enabled)</p>
              <div className="flex flex-wrap gap-1">
                {['Category', 'Brand', 'Description', 'MOQ', 'GST Rate'].map(h => (
                  <span key={h} className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded border border-slate-200">{h}</span>
                ))}
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={downloadTemplateCSV}
            className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg border border-slate-300 transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <Download className="w-4 h-4 text-slate-600" />
            <span>Get Catalog Template (.CSV)</span>
          </button>
        </div>

        {/* Step 2: Drag & Drop Zone */}
        <div className="md:col-span-3 flex flex-col justify-between">
          <div className="space-y-2">
            <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider">Step 2</span>
            <h4 className="text-xs font-black text-slate-900 uppercase">Upload Completed CSV Catalog</h4>
            <p className="text-[10px] text-slate-500 font-semibold leading-relaxed">
              Drag and drop your spreadsheet into the system or click below to manually attach. The spreadsheet is parsed on-device instantly.
            </p>
          </div>

          <div
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                handleCsvFileUpload(e.dataTransfer.files[0]);
              }
            }}
            className={`mt-4 flex-1 min-h-[140px] border-2 border-dashed rounded-xl flex flex-col items-center justify-center p-6 text-center transition-all cursor-pointer ${
              isDragging 
                ? 'border-teal-500 bg-teal-50/40' 
                : csvFileName 
                  ? 'border-emerald-500 bg-emerald-50/10' 
                  : 'border-slate-300 hover:border-slate-400 hover:bg-slate-50/50'
            }`}
            onClick={() => {
              const input = document.getElementById('csv-file-manual-picker');
              if (input) input.click();
            }}
          >
            <input
              type="file"
              id="csv-file-manual-picker"
              accept=".csv"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleCsvFileUpload(e.target.files[0]);
                }
              }}
            />

            {csvFileName ? (
              <div className="space-y-2">
                <FileSpreadsheet className="w-10 h-10 text-emerald-600 mx-auto" />
                <div className="space-y-0.5">
                  <p className="text-xs font-extrabold text-slate-900 font-mono truncate max-w-xs">{csvFileName}</p>
                  <p className="text-[9px] text-slate-400 font-bold">Size: {Math.round((csvFile?.size || 0) / 102) / 10} KB • Status: Parsed</p>
                </div>
                <span className="inline-block mt-1 text-[10px] text-teal-700 bg-teal-50 border border-teal-200 px-2 py-0.5 rounded-full font-bold">
                  Click or Drop to Replace File
                </span>
              </div>
            ) : (
              <div className="space-y-2">
                <Upload className="w-10 h-10 text-slate-400 mx-auto" />
                <div>
                  <p className="text-xs font-bold text-slate-700">Drag & Drop Catalog CSV here</p>
                  <p className="text-[10px] text-slate-400 mt-1">or click to browse your desktop storage</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Step 3: Parse and Live Validation Preview Grid */}
      {csvData.length > 0 && (
        <div className="pt-4 border-t border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <div className="flex items-center gap-1.5">
                <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider">Step 3</span>
                <h4 className="text-xs font-black text-slate-900 uppercase">Spreadsheet Diagnostics & Validation Preview</h4>
              </div>
              <p className="text-[10px] text-slate-500 font-semibold mt-1">
                {csvData.filter(r => r.isValid).length} of {csvData.length} records verified successfully. Invalid rows must be corrected inside your spreadsheet or skipped.
              </p>
            </div>

            <button
              type="button"
              onClick={handleConfirmCsvUpload}
              disabled={csvData.filter(r => r.isValid).length === 0}
              className={`px-5 py-2.5 rounded-xl text-xs font-bold tracking-wider uppercase transition-all flex items-center gap-2 ${
                csvData.filter(r => r.isValid).length > 0
                  ? 'bg-emerald-600 text-white shadow-xs hover:bg-emerald-700 cursor-pointer'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <PlusCircle className="w-4 h-4" />
              <span>Import {csvData.filter(r => r.isValid).length} Verified Devices</span>
            </button>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden max-h-[350px] overflow-y-auto">
            <table className="w-full text-left border-collapse text-[11px] font-medium font-sans">
              <thead>
                <tr className="bg-slate-100 text-slate-600 border-b border-slate-200 uppercase font-black text-[9px] tracking-wider">
                  <th className="p-3">Row</th>
                  <th className="p-3">SKU Code</th>
                  <th className="p-3">Product Title</th>
                  <th className="p-3 text-right">MRP</th>
                  <th className="p-3 text-right">Vendor Price</th>
                  <th className="p-3 text-center">Stock</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Import Diagnostics</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-150 font-semibold">
                {csvData.map((row, idx) => (
                  <tr 
                    key={idx} 
                    className={`hover:bg-slate-50 transition-colors ${
                      row.isValid ? 'bg-emerald-50/20' : 'bg-rose-50/30'
                    }`}
                  >
                    <td className="p-3 text-slate-400 font-mono">#{row.rowNum}</td>
                    <td className="p-3 font-mono text-slate-700">{row.sku}</td>
                    <td className="p-3 text-slate-900 max-w-[150px] truncate">{row.name}</td>
                    <td className="p-3 text-right text-slate-600 font-mono">₹{row.mrp ? row.mrp.toLocaleString() : '-'}</td>
                    <td className="p-3 text-right text-slate-950 font-extrabold font-mono">₹{row.vendorPrice ? row.vendorPrice.toLocaleString() : '-'}</td>
                    <td className="p-3 text-center font-mono text-slate-700">{row.stock}</td>
                    <td className="p-3 text-slate-500 font-medium">{row.category}</td>
                    <td className="p-3">
                      {row.isValid ? (
                        <span className="inline-flex items-center gap-1 text-[10px] text-emerald-700 bg-emerald-100/60 px-2 py-0.5 rounded font-bold uppercase">
                          <Check className="w-3 h-3" /> Ready
                        </span>
                      ) : (
                        <div className="space-y-1 text-rose-700">
                          <span className="inline-flex items-center gap-1 text-[9px] text-rose-700 bg-rose-100 px-1.5 py-0.5 rounded font-black uppercase">
                            <X className="w-2.5 h-2.5" /> Blocked
                          </span>
                          <div className="text-[9px] font-medium leading-tight text-rose-600/90 pl-1">
                            {row.errors.map((err: string, i: number) => (
                              <p key={i}>• {err}</p>
                            ))}
                          </div>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
