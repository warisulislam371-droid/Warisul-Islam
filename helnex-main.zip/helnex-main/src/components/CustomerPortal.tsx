import React, { useState } from 'react';
import { 
  User, 
  ClipboardList, 
  Heart, 
  MapPin, 
  Star, 
  Wallet, 
  ChevronRight, 
  AlertCircle, 
  CheckCircle, 
  Plus, 
  ArrowUpRight, 
  Package, 
  MessageSquare, 
  Eye 
} from 'lucide-react';
import { Order, Product, Review, WalletTransaction } from '../types';

interface CustomerPortalProps {
  orders: Order[];
  products: Product[];
  reviews: Review[];
  onAddReview: (productId: string, comment: string, rating: number) => void;
  walletBalance: number;
  walletHistory: WalletTransaction[];
  onAddWalletFunds: (amount: number) => void;
  wishlist: string[];
  onToggleWishlist: (p: Product) => void;
  onAddToCart: (p: Product) => void;
}

export default function CustomerPortal({
  orders,
  products,
  reviews,
  onAddReview,
  walletBalance,
  walletHistory,
  onAddWalletFunds,
  wishlist,
  onToggleWishlist,
  onAddToCart
}: CustomerPortalProps) {
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'reviews' | 'addresses' | 'wallet'>('orders');
  const [addFundsAmount, setAddFundsAmount] = useState<string>('');
  const [selectedOrderDetails, setSelectedOrderDetails] = useState<Order | null>(null);

  // Review states
  const [reviewProduct, setReviewProduct] = useState<string>('');
  const [reviewComment, setReviewComment] = useState<string>('');
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [reviewSuccess, setReviewSuccess] = useState<boolean>(false);

  // Address templates
  const [addresses, setAddresses] = useState([
    { id: '1', title: 'Fortis Hospital Main Wing', address: 'Apt 4B, Skyview Towers, Koramangala', city: 'Bengaluru', state: 'Karnataka', zip: '560034', isDefault: true },
    { id: '2', title: 'Dr. Karan Mehra Clinic', address: '22 Sector 5, Outer Ring Rd', city: 'Bengaluru', state: 'Karnataka', zip: '560102', isDefault: false }
  ]);

  const [newAddrTitle, setNewAddrTitle] = useState('');
  const [newAddrBody, setNewAddrBody] = useState('');
  const [newAddrCity, setNewAddrCity] = useState('');
  const [newAddrState, setNewAddrState] = useState('');
  const [newAddrZip, setNewAddrZip] = useState('');

  const handleAddAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddrTitle || !newAddrBody) return;
    setAddresses([
      ...addresses,
      {
        id: Date.now().toString(),
        title: newAddrTitle,
        address: newAddrBody,
        city: newAddrCity,
        state: newAddrState,
        zip: newAddrZip,
        isDefault: false
      }
    ]);
    setNewAddrTitle('');
    setNewAddrBody('');
    setNewAddrCity('');
    setNewAddrState('');
    setNewAddrZip('');
  };

  const submitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewProduct || !reviewComment) return;
    onAddReview(reviewProduct, reviewComment, reviewRating);
    setReviewSuccess(true);
    setReviewComment('');
    setReviewProduct('');
    setReviewRating(5);
    setTimeout(() => setReviewSuccess(false), 4000);
  };

  const handleWalletSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(addFundsAmount);
    if (isNaN(parsed) || parsed <= 0) return;
    onAddWalletFunds(parsed);
    setAddFundsAmount('');
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 grid grid-cols-1 md:grid-cols-4 overflow-hidden min-h-[70vh]">
      
      {/* Sidebar Nav */}
      <div className="bg-slate-50/50 border-r border-slate-200 p-6 flex flex-col justify-between">
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-slate-950 rounded-lg text-white flex items-center justify-center font-bold text-base shadow-sm font-display">
              KM
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900">Karan Mehra</p>
              <p className="text-[10px] text-slate-400 font-mono">Procurement Manager</p>
            </div>
          </div>

          <div className="space-y-1">
            {[
              { id: 'orders', label: 'My Orders', icon: ClipboardList },
              { id: 'wallet', label: 'My Wallet', icon: Wallet },
              { id: 'reviews', label: 'Add Product Review', icon: Star },
              { id: 'addresses', label: 'Saved Hospital Addresses', icon: MapPin },
              { id: 'profile', label: 'Account Profile', icon: User }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  id={`cust-tab-${tab.id}`}
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    setSelectedOrderDetails(null);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-md text-xs font-medium transition-all flex items-center gap-2.5 ${
                    activeTab === tab.id 
                      ? 'bg-slate-950 text-white shadow-xs' 
                      : 'text-slate-600 hover:bg-slate-200/40'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Display Wallet Balance inside Sidebar */}
        <div className="bg-slate-950 text-white p-4 rounded-lg mt-6 border border-slate-800">
          <p className="text-[9px] font-mono tracking-wider uppercase text-slate-400">Wallet Balance</p>
          <p className="text-lg font-bold mt-1 font-mono">₹{walletBalance.toLocaleString()}</p>
        </div>
      </div>

      {/* Workspace Area */}
      <div className="md:col-span-3 p-6 lg:p-8 space-y-6">
        
        {/* Active Tab Workspace rendering */}
        {activeTab === 'profile' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Account Profile</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-bold">
              <div className="space-y-1">
                <label className="text-slate-500">Full Name</label>
                <input type="text" readOnly value="Karan Mehra" className="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-800" />
              </div>
              <div className="space-y-1">
                <label className="text-slate-500">Registered Email</label>
                <input type="email" readOnly value="karan@outlook.com" className="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-800" />
              </div>
              <div className="space-y-1">
                <label className="text-slate-500">Phone</label>
                <input type="text" readOnly value="+91 99887 22110" className="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-800" />
              </div>
              <div className="space-y-1">
                <label className="text-slate-500">Role Designation</label>
                <input type="text" readOnly value="Procurement Representative" className="w-full p-2.5 bg-slate-100 border border-slate-200 rounded-lg text-slate-800" />
              </div>
            </div>
            <div className="p-3.5 bg-blue-50 text-blue-700 text-[11px] font-medium rounded-lg">
              🔒 Contact administrative desks or open a support ticket to modify core clinic license keys.
            </div>
          </div>
        )}

        {activeTab === 'orders' && !selectedOrderDetails && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Hospital Procurement History</h2>
              <span className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded font-bold">{orders.length} Orders Total</span>
            </div>

            {orders.length === 0 ? (
              <div className="text-center py-12 space-y-2 border-2 border-dashed border-slate-100 rounded-xl">
                <ClipboardList className="w-10 h-10 text-slate-300 mx-auto" />
                <p className="text-xs text-slate-600 font-bold">No orders logged.</p>
                <p className="text-[10px] text-slate-400">Head back to the storefront to browse certified equipments.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((o) => (
                  <div key={o.id} className="border border-slate-200 rounded-xl p-4 space-y-3 bg-white hover:border-slate-300 transition-colors">
                    <div className="flex flex-wrap justify-between items-center gap-2 border-b border-slate-100 pb-3">
                      <div>
                        <p className="text-xs font-black text-slate-950">{o.id}</p>
                        <p className="text-[10px] text-slate-500">{o.createdAt}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-full ${
                          o.status === 'Delivered' ? 'bg-emerald-100 text-emerald-700' :
                          o.status === 'Cancelled' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {o.status}
                        </span>
                        <button
                          onClick={() => setSelectedOrderDetails(o)}
                          className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-0.5"
                        >
                          <Eye className="w-3.5 h-3.5" /> Details
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold uppercase">Items ordered:</p>
                        <div className="mt-1 space-y-0.5">
                          {o.items.map((it, i) => (
                            <p key={i} className="font-bold text-slate-800 line-clamp-1">
                              • {it.quantity}x {it.productName}
                            </p>
                          ))}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-[10px] text-slate-400 font-bold uppercase">Total Bill:</p>
                        <p className="text-sm font-extrabold text-slate-950 mt-1">₹{o.total.toLocaleString()}</p>
                        <p className="text-[10px] text-emerald-600 font-semibold">{o.paymentStatus === 'Paid' ? '✓ Fully Paid' : 'Pending Payment'}</p>
                      </div>
                    </div>

                    {/* Active courier status tracking */}
                    {o.courierName && o.trackingNumber && (
                      <div className="bg-slate-50 p-2.5 rounded-lg text-[10px] font-mono text-slate-600 flex flex-wrap justify-between">
                        <span>Courier Partner: <strong className="text-slate-800">{o.courierName}</strong></span>
                        <span>Tracking ID: <strong className="text-slate-800">{o.trackingNumber}</strong></span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Selected Order Details View */}
        {activeTab === 'orders' && selectedOrderDetails && (
          <div className="space-y-6">
            <button
              onClick={() => setSelectedOrderDetails(null)}
              className="text-xs font-bold text-blue-600 hover:underline flex items-center gap-1 cursor-pointer"
            >
              ← Back to Orders list
            </button>

            <div className="border border-slate-200 rounded-2xl p-6 bg-white space-y-6">
              <div className="flex flex-wrap justify-between items-center border-b border-slate-100 pb-4">
                <div>
                  <h3 className="text-sm font-extrabold text-slate-950 uppercase tracking-widest">Order Detail Sheet</h3>
                  <p className="text-xs text-slate-500 font-mono mt-1">Reference ID: {selectedOrderDetails.id} • Date: {selectedOrderDetails.createdAt}</p>
                </div>
                <span className="text-xs bg-blue-50 text-blue-700 px-3 py-1 rounded-full font-black uppercase tracking-widest">
                  {selectedOrderDetails.status}
                </span>
              </div>

              {/* Courier Status Timeline */}
              <div className="space-y-3.5">
                <p className="text-[10px] uppercase font-black tracking-wider text-slate-400">Order Dispatch Timeline</p>
                <div className="flex justify-between text-center max-w-lg text-[10px] font-bold">
                  {[
                    { st: 'Pending', label: 'Ordered' },
                    { st: 'Processing', label: 'Verified' },
                    { st: 'Shipped', label: 'Shipped' },
                    { st: 'Delivered', label: 'Arrived' }
                  ].map((step, idx) => {
                    const statuses = ['Pending', 'Confirmed', 'Processing', 'Packed', 'Shipped', 'Delivered'];
                    const currentIdx = statuses.indexOf(selectedOrderDetails.status);
                    const stepIdx = statuses.indexOf(step.st);
                    const isCompleted = currentIdx >= stepIdx;

                    return (
                      <div key={idx} className="flex flex-col items-center gap-1.5 flex-1 relative">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center border font-sans text-[10px] ${
                          isCompleted ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-100 text-slate-400 border-slate-200'
                        }`}>
                          {isCompleted ? '✓' : idx + 1}
                        </div>
                        <span className={isCompleted ? 'text-slate-900 font-extrabold' : 'text-slate-400'}>{step.label}</span>
                      </div>
                    );
                  })}
                </div>

                {selectedOrderDetails.courierName && (
                  <div className="bg-blue-50 text-blue-800 p-3 rounded-lg border border-blue-100 text-xs font-mono">
                    <p className="font-extrabold uppercase text-[9px]">Courier Handover Receipt</p>
                    <p className="mt-1">Carrier Name: {selectedOrderDetails.courierName}</p>
                    <p>AWB Tracking ID: {selectedOrderDetails.trackingNumber}</p>
                    <p className="text-[10px] text-blue-600 font-semibold mt-2">✓ Safely dispatched to hospital destination.</p>
                  </div>
                )}
              </div>

              {/* Items Table */}
              <div className="space-y-2">
                <p className="text-[10px] uppercase font-black tracking-wider text-slate-400">Products Sheet</p>
                <div className="border border-slate-100 rounded-xl overflow-hidden divide-y text-xs">
                  {selectedOrderDetails.items.map((item, idx) => (
                    <div key={idx} className="p-3 flex justify-between bg-slate-50/50">
                      <div>
                        <p className="font-bold text-slate-900">{item.productName}</p>
                        <p className="text-[10px] text-slate-500 font-semibold">Vendor: {item.vendorName}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-mono text-slate-900 font-bold">₹{item.total.toLocaleString()}</p>
                        <p className="text-[10px] text-slate-500">Qty: {item.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Addresses & Totals */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                <div className="space-y-1">
                  <p className="text-[10px] font-black text-slate-400 uppercase">Hospital Delivery Destination</p>
                  <p className="font-bold text-slate-800 mt-1">{selectedOrderDetails.billingDetails.name}</p>
                  <p className="text-slate-600">{selectedOrderDetails.billingDetails.address}</p>
                  <p className="text-slate-600">{selectedOrderDetails.billingDetails.city}, {selectedOrderDetails.billingDetails.state} - {selectedOrderDetails.billingDetails.pinCode}</p>
                  <p className="text-slate-500">Tel: {selectedOrderDetails.billingDetails.mobile}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-xl space-y-1.5 font-semibold text-slate-600 text-right">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span className="text-slate-900 font-bold">₹{selectedOrderDetails.subtotal.toLocaleString()}</span>
                  </div>
                  {selectedOrderDetails.discount > 0 && (
                    <div className="flex justify-between text-emerald-600">
                      <span>Coupon Saved:</span>
                      <span className="font-bold">- ₹{selectedOrderDetails.discount.toLocaleString()}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-900 font-bold text-sm pt-2 border-t">
                    <span>Total Paid:</span>
                    <span className="text-blue-700 font-black">₹{selectedOrderDetails.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'wallet' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Hospital Payment Wallet</h2>
              <span className="text-xs text-slate-500 font-mono">Instant OTP validation</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Wallet Card */}
              <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-5 text-white shadow-md relative overflow-hidden md:col-span-1">
                <div className="space-y-3 relative z-10">
                  <Wallet className="w-8 h-8 text-blue-200" />
                  <div>
                    <p className="text-[10px] text-blue-200 font-bold uppercase tracking-widest">Active Balance</p>
                    <p className="text-2xl font-black">₹{walletBalance.toLocaleString()}</p>
                  </div>
                </div>
                {/* Background designs */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-xl"></div>
              </div>

              {/* Fund deposit */}
              <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 md:col-span-2 space-y-3.5">
                <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Simulate Bank Deposit</h3>
                <form onSubmit={handleWalletSubmit} className="flex gap-2">
                  <input
                    type="number"
                    placeholder="Enter deposit amount (₹)"
                    value={addFundsAmount}
                    onChange={(e) => setAddFundsAmount(e.target.value)}
                    className="flex-1 p-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-800 bg-white"
                  />
                  <button
                    type="submit"
                    className="px-4 bg-emerald-500 text-slate-950 font-black text-xs rounded-lg hover:bg-emerald-600 transition-colors"
                  >
                    Load Funds
                  </button>
                </form>
                <div className="flex gap-2">
                  {[2000, 5000, 10000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setAddFundsAmount(amt.toString())}
                      className="px-3 py-1 bg-white border text-[10px] font-bold rounded-md hover:bg-slate-100 text-slate-700"
                    >
                      + ₹{amt.toLocaleString()}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Wallet logs */}
            <div className="space-y-3">
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Deposit & Transaction History</h3>
              {walletHistory.length === 0 ? (
                <p className="text-slate-400 text-xs">No transactions recorded.</p>
              ) : (
                <div className="border border-slate-100 rounded-xl divide-y text-xs bg-white">
                  {walletHistory.map((t) => (
                    <div key={t.id} className="p-3 flex justify-between items-center hover:bg-slate-50/50">
                      <div className="space-y-0.5">
                        <p className="font-bold text-slate-800">{t.description}</p>
                        <p className="text-[9px] text-slate-400">{t.date}</p>
                      </div>
                      <span className={`font-black font-mono ${t.type === 'Credit' ? 'text-emerald-600' : 'text-rose-500'}`}>
                        {t.type === 'Credit' ? '+' : '-'} ₹{t.amount.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Write a Performance Review</h2>
            
            {reviewSuccess && (
              <div className="p-3.5 bg-emerald-50 text-emerald-800 rounded-xl text-xs font-bold flex gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>Review submitted successfully! It is queued for Admin approval before showing on the product catalog.</span>
              </div>
            )}

            <form onSubmit={submitReview} className="space-y-4 text-xs font-bold">
              <div className="space-y-1">
                <label className="text-slate-600">Select Clinical Device</label>
                <select
                  value={reviewProduct}
                  onChange={(e) => setReviewProduct(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-slate-200 font-bold bg-white text-slate-800"
                >
                  <option value="">-- Choose a Product --</option>
                  {products.filter(p => p.approved).map((p) => (
                    <option key={p.id} value={p.id}>{p.name} (Brand: {p.brand})</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-600">Give a Rating</label>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setReviewRating(star)}
                      className={`text-lg ${reviewRating >= star ? 'text-amber-500' : 'text-slate-300'}`}
                    >
                      ★
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-600">Write Comments (Detailed Clinical Performance Feedback)</label>
                <textarea
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  rows={4}
                  className="w-full p-2.5 rounded-lg border border-slate-200 font-medium focus:outline-hidden"
                  placeholder="Tell other hospital buyers about safety guidelines, packaging, and sensor accuracy..."
                />
              </div>

              <button
                type="submit"
                disabled={!reviewProduct || !reviewComment}
                className="w-full py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl disabled:bg-slate-200 disabled:text-slate-400 shadow-md hover:bg-blue-700 transition-colors cursor-pointer"
              >
                Submit Review to Admin Audit Queue
              </button>
            </form>
          </div>
        )}

        {activeTab === 'addresses' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Saved Hospital Locations</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {addresses.map((a) => (
                <div key={a.id} className="border border-slate-200 rounded-xl p-4 space-y-2 relative bg-slate-50/30">
                  <p className="text-xs font-black text-slate-950 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    {a.title}
                    {a.isDefault && <span className="bg-emerald-100 text-emerald-700 text-[8px] px-1.5 py-0.5 rounded uppercase font-bold">Primary</span>}
                  </p>
                  <p className="text-[11px] text-slate-600">{a.address}</p>
                  <p className="text-[11px] text-slate-600">{a.city}, {a.state} - {a.zip}</p>
                </div>
              ))}
            </div>

            <div className="border-t border-slate-100 pt-6 space-y-3">
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Register New Delivery Site</h3>
              <form onSubmit={handleAddAddress} className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-bold">
                <div className="md:col-span-2 space-y-1">
                  <label className="text-slate-600">Location Tag (e.g. ICU Wing B)</label>
                  <input type="text" value={newAddrTitle} onChange={(e) => setNewAddrTitle(e.target.value)} className="w-full p-2.5 rounded-lg border border-slate-200" placeholder="e.g. Fortis Main Pharmacy" />
                </div>
                <div className="md:col-span-2 space-y-1">
                  <label className="text-slate-600">Street Address</label>
                  <input type="text" value={newAddrBody} onChange={(e) => setNewAddrBody(e.target.value)} className="w-full p-2.5 rounded-lg border border-slate-200" />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-600">City</label>
                  <input type="text" value={newAddrCity} onChange={(e) => setNewAddrCity(e.target.value)} className="w-full p-2.5 rounded-lg border border-slate-200" />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-600">State</label>
                  <input type="text" value={newAddrState} onChange={(e) => setNewAddrState(e.target.value)} className="w-full p-2.5 rounded-lg border border-slate-200" />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-600">ZIP Code</label>
                  <input type="text" value={newAddrZip} onChange={(e) => setNewAddrZip(e.target.value)} className="w-full p-2.5 rounded-lg border border-slate-200" />
                </div>
                <div className="md:col-span-2 pt-2">
                  <button type="submit" className="px-5 py-2.5 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-slate-800 transition-colors cursor-pointer">
                    Save Address
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
