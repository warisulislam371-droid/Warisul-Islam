import React, { useState } from 'react';
import { 
  Store, 
  Package, 
  ClipboardList, 
  PlusCircle, 
  TrendingUp, 
  ShieldCheck, 
  AlertCircle, 
  ArrowUpRight, 
  Upload, 
  IndianRupee, 
  Truck, 
  CheckCircle, 
  ChevronRight, 
  Check, 
  X,
  FileSpreadsheet,
  Download,
  AlertTriangle
} from 'lucide-react';
import { Vendor, Product, Order, WithdrawalRequest, OrderStatus } from '../types';
import { CATEGORIES } from '../data/mockData';
import { BulkUpload } from './BulkUpload';

interface VendorPortalProps {
  vendors: Vendor[];
  products: Product[];
  orders: Order[];
  onRegisterVendor: (newVendor: Omit<Vendor, 'id' | 'status' | 'rating' | 'productCount' | 'verified'>) => void;
  onAddProduct: (newProduct: Omit<Product, 'id' | 'vendorId' | 'vendorName' | 'rating' | 'approved'> & { vendorId?: string; vendorName?: string }) => void;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus, courier?: string, tracking?: string) => void;
  onUpdateStock: (productId: string, newStock: number) => void;
  onAddWithdrawalRequest: (amount: number, bankDetails: any) => void;
  withdrawalRequests: WithdrawalRequest[];
}

export default function VendorPortal({
  vendors,
  products,
  orders,
  onRegisterVendor,
  onAddProduct,
  onUpdateOrderStatus,
  onUpdateStock,
  onAddWithdrawalRequest,
  withdrawalRequests
}: VendorPortalProps) {
  // Let's assume vendor-1 ("Apex Hospital Systems") is logged in by default for testing.
  // We can let the user change the active vendor, or register a new one!
  const [activeVendorId, setActiveVendorId] = useState<string>('vendor-1');
  const activeVendor = vendors.find(v => v.id === activeVendorId) || vendors[0];

  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'withdraw' | 'register'>('overview');

  // Registration Form state
  const [regBusName, setRegBusName] = useState('');
  const [regOwnerName, setRegOwnerName] = useState('');
  const [regMobile, setRegMobile] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regGST, setRegGST] = useState('');
  const [regPAN, setRegPAN] = useState('');
  const [regAddress, setRegAddress] = useState('');
  const [regTradeLicense, setRegTradeLicense] = useState('TL-REG-8742X');
  const [regBankAccName, setRegBankAccName] = useState('');
  const [regBankAccNum, setRegBankAccNum] = useState('');
  const [regBankName, setRegBankName] = useState('');
  const [regBankIFSC, setRegBankIFSC] = useState('');
  const [regSuccess, setRegSuccess] = useState(false);

  // New Product Form state
  const [prodName, setProdName] = useState('');
  const [prodSKU, setProdSKU] = useState('');
  const [prodCat, setProdCat] = useState('ICU Equipment');
  const [prodBrand, setProdBrand] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodImg, setProdImg] = useState('https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=400');
  const [prodStock, setProdStock] = useState<string>('15');
  const [prodPrice, setProdPrice] = useState<string>('12000'); // Vendor price (what they want to receive)
  const [prodMrp, setProdMrp] = useState<string>('18000'); // Max Retail Price
  const [prodMoq, setProdMoq] = useState<string>('1'); // Min order quantity
  const [prodGstRate, setProdGstRate] = useState<string>('18'); // optional GST rate
  const [prodSuccess, setProdSuccess] = useState(false);

  // Logistics processing overlay state
  const [processingOrder, setProcessingOrder] = useState<Order | null>(null);
  const [courierNameInput, setCourierNameInput] = useState('');
  const [trackingNumInput, setTrackingNumInput] = useState('');

  // Withdrawal state
  const [withdrawAmt, setWithdrawAmt] = useState('');
  const [withdrawSuccess, setWithdrawSuccess] = useState(false);

  // Bulk CSV Upload State
  const [productAddMode, setProductAddMode] = useState<'single' | 'bulk'>('single');

  // Derived metrics for the active vendor
  const vendorProducts = products.filter(p => p.vendorId === activeVendor?.id);
  const vendorOrders = orders.filter(o => o.items.some(it => it.vendorId === activeVendor?.id));

  // Calculated earnings
  const totalEarnings = vendorOrders
    .filter(o => o.paymentStatus === 'Paid')
    .reduce((sum, o) => {
      // Sum the vendor's share of order items
      const vendorShare = o.items
        .filter(it => it.vendorId === activeVendor?.id)
        .reduce((s, it) => s + (it.sellingPrice * it.quantity), 0);
      return sum + vendorShare;
    }, 0);

  // Withdrawn sum
  const totalWithdrawn = withdrawalRequests
    .filter(r => r.vendorId === activeVendor?.id && r.status === 'Paid')
    .reduce((sum, r) => sum + r.amount, 0);

  const pendingWithdrawal = withdrawalRequests
    .filter(r => r.vendorId === activeVendor?.id && r.status === 'Pending')
    .reduce((sum, r) => sum + r.amount, 0);

  const availableWithdrawableBalance = Math.max(0, totalEarnings - totalWithdrawn - pendingWithdrawal);

  // Form submission: Vendor registration
  const handleRegisterVendor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regBusName || !regOwnerName || !regMobile || !regEmail || !regTradeLicense || !regAddress) {
      alert('Please fill out all mandatory fields.');
      return;
    }
    const newVendorData = {
      businessName: regBusName,
      ownerName: regOwnerName,
      mobile: regMobile,
      email: regEmail,
      gstNumber: regGST || undefined,
      panNumber: regPAN || undefined,
      tradeLicense: regTradeLicense,
      businessAddress: regAddress,
      bankDetails: regBankAccNum ? {
        accountName: regBankAccName || regOwnerName,
        accountNumber: regBankAccNum,
        bankName: regBankName,
        ifscCode: regBankIFSC
      } : undefined
    };
    onRegisterVendor(newVendorData);
    setRegSuccess(true);
    // Switch active vendor to the newly created vendor for verification
    setTimeout(() => {
      // Find the pending vendor and auto-select it
      const created = vendors.find(v => v.businessName === regBusName);
      if (created) {
        setActiveVendorId(created.id);
      } else {
        // Fallback to latest
        const latest = vendors[vendors.length - 1];
        if (latest) setActiveVendorId(latest.id);
      }
      setRegSuccess(false);
      setActiveTab('overview');
    }, 2500);
  };

  // Form submission: Product insertion
  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodName || !prodSKU || !prodBrand || !prodPrice) {
      alert('Please fill out all mandatory fields.');
      return;
    }
    const parsedPrice = parseFloat(prodPrice);
    const parsedStock = parseInt(prodStock) || 0;
    const parsedMrp = parseFloat(prodMrp) || parsedPrice * 1.5;
    const parsedMoq = parseInt(prodMoq) || 1;
    const parsedGst = prodGstRate ? parseFloat(prodGstRate) : undefined;
    
    if (isNaN(parsedPrice) || parsedPrice <= 0) return;

    onAddProduct({
      name: prodName,
      sku: prodSKU,
      category: prodCat,
      brand: prodBrand,
      description: prodDesc || `${prodName} medical product manufactured by ${activeVendor?.businessName}.`,
      imageUrl: prodImg,
      stock: parsedStock,
      mrp: parsedMrp,
      vendorPrice: parsedPrice,
      sellingPrice: parsedPrice,
      moq: parsedMoq,
      gstRate: parsedGst,
      commissionPercent: 10,
      customerPrice: Math.round(parsedPrice * 1.1) // fallback, gets re-calculated automatically in App.tsx
    });

    setProdSuccess(true);
    setProdName('');
    setProdSKU('');
    setProdBrand('');
    setProdDesc('');
    setProdPrice('12000');
    setProdMrp('18000');
    setProdMoq('1');
    setProdGstRate('18');
    setTimeout(() => {
      setProdSuccess(false);
      setActiveTab('products');
    }, 2000);
  };

  // Trigger dispatch logistics overlay
  const triggerShipping = (order: Order) => {
    setProcessingOrder(order);
    setCourierNameInput('Delhivery Healthcare Express');
    setTrackingNumInput(`AWB${Math.floor(10000000 + Math.random() * 90000000)}`);
  };

  const confirmShipping = () => {
    if (!processingOrder) return;
    if (!courierNameInput || !trackingNumInput) {
      alert('Courier Name and AWB Tracking Number are mandatory before shipping.');
      return;
    }
    onUpdateOrderStatus(processingOrder.id, 'Shipped', courierNameInput, trackingNumInput);
    setProcessingOrder(null);
  };

  // Withdrawal submission
  const handleWithdrawalRequestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(withdrawAmt);
    if (isNaN(amount) || amount <= 0 || amount > availableWithdrawableBalance) {
      alert('Invalid withdrawal amount or insufficient balance.');
      return;
    }
    const bankDetails = activeVendor?.bankDetails || {
      accountName: activeVendor?.ownerName || 'Vendor Master',
      accountNumber: '918000987654321',
      bankName: 'HDFC Bank',
      ifscCode: 'HDFC0000012'
    };
    onAddWithdrawalRequest(amount, bankDetails);
    setWithdrawAmt('');
    setWithdrawSuccess(true);
    setTimeout(() => setWithdrawSuccess(false), 3000);
  };

  return (
    <div className="bg-white rounded-lg border border-slate-200 grid grid-cols-1 lg:grid-cols-4 overflow-hidden min-h-[75vh]">
      
      {/* Sidebar Nav */}
      <div className="bg-slate-950 text-slate-300 p-6 flex flex-col justify-between border-r border-slate-800">
        <div className="space-y-6">
          
          {/* Active Vendor Selector */}
          <div className="space-y-2">
            <label className="text-[10px] uppercase font-bold tracking-widest text-slate-400 font-mono">Active Vendor Profile</label>
            <select
              value={activeVendorId}
              onChange={(e) => {
                setActiveVendorId(e.target.value);
                setActiveTab('overview');
              }}
              className="w-full p-2 rounded-md bg-slate-900 text-white text-xs font-semibold border border-slate-800 font-mono focus:outline-hidden"
              id="vendor-profile-select-box"
            >
              {vendors.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.businessName} ({v.status})
                </option>
              ))}
            </select>
          </div>

          <div className="border-t border-slate-800 pt-4 space-y-1">
            {[
              { id: 'overview', label: 'Supplier Console', icon: Store },
              { id: 'products', label: 'Manage Products', icon: Package },
              { id: 'orders', label: 'Client Orders', icon: ClipboardList },
              { id: 'withdraw', label: 'Withdrawal Center', icon: IndianRupee },
              { id: 'register', label: 'Register New Vendor', icon: PlusCircle }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  id={`vendor-tab-${tab.id}`}
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    setProcessingOrder(null);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-md text-xs font-medium transition-all flex items-center gap-2.5 ${
                    activeTab === tab.id 
                      ? 'bg-white text-slate-950 font-semibold' 
                      : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5 shrink-0" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Status indicator */}
        <div className="pt-6 border-t border-slate-800 text-xs text-slate-400 space-y-1 font-mono">
          <p className="text-[10px] uppercase tracking-wider font-semibold">Verification Status</p>
          <div className="flex items-center gap-1.5 mt-1">
            <span className={`w-1.5 h-1.5 rounded-full ${
              activeVendor?.status === 'Approved' ? 'bg-emerald-400' :
              activeVendor?.status === 'Rejected' ? 'bg-rose-500' : 'bg-amber-400'
            }`}></span>
            <span className="text-white font-semibold">{activeVendor?.status}</span>
          </div>
          {activeVendor?.status === 'Pending' && (
            <p className="text-[9px] text-slate-500 italic mt-1 leading-snug font-sans">Waiting for Admin trade license approval.</p>
          )}
        </div>
      </div>

      {/* Workspace Area */}
      <div className="lg:col-span-3 p-6 lg:p-8 space-y-6">

        {/* If vendor is not approved, lock access except overview and registration */}
        {activeVendor?.status !== 'Approved' && activeTab !== 'register' && activeTab !== 'overview' ? (
          <div className="bg-amber-50 p-6 rounded-2xl border border-amber-200 text-center max-w-lg mx-auto space-y-4">
            <AlertCircle className="w-12 h-12 text-amber-600 mx-auto" />
            <h3 className="text-sm font-black text-slate-900 uppercase">Vendor Under Super Admin Review</h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Your trade license <strong className="font-mono text-slate-800">({activeVendor?.tradeLicense})</strong> is currently queued for manual validation. Adding products and tracking orders is temporarily locked.
            </p>
            <p className="text-[10px] text-slate-500">
              💡 Tip: Quick-switch role to **Admin** using the top black bar, approve this vendor in "Vendor Approvals", and switch back.
            </p>
          </div>
        ) : (
          /* Active Tabs */
          <>
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">{activeVendor?.businessName}</h2>
                    <p className="text-slate-500 text-xs">Managing Director: {activeVendor?.ownerName} • License: {activeVendor?.tradeLicense}</p>
                  </div>
                  {activeVendor?.verified && (
                    <span className="bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold inline-flex items-center gap-1">
                      <ShieldCheck className="w-4 h-4" /> Verified Partner
                    </span>
                  )}
                </div>

                {/* Metrics Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="border border-slate-200 p-4 rounded-xl space-y-1.5">
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Withdrawable Earnings</p>
                    <p className="text-lg font-extrabold text-slate-900">₹{availableWithdrawableBalance.toLocaleString()}</p>
                    <p className="text-[9px] text-slate-400 font-mono">Gross: ₹{totalEarnings.toLocaleString()}</p>
                  </div>
                  <div className="border border-slate-200 p-4 rounded-xl space-y-1.5">
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Gross Orders</p>
                    <p className="text-lg font-extrabold text-slate-900">{vendorOrders.length}</p>
                    <p className="text-[9px] text-slate-400 font-medium">Pending packing: {vendorOrders.filter(o => o.status === 'Confirmed' || o.status === 'Pending').length}</p>
                  </div>
                  <div className="border border-slate-200 p-4 rounded-xl space-y-1.5">
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Listed Devices</p>
                    <p className="text-lg font-extrabold text-slate-900">{vendorProducts.length}</p>
                    <p className="text-[9px] text-emerald-600 font-semibold">Approved: {vendorProducts.filter(p => p.approved).length}</p>
                  </div>
                  <div className="border border-slate-200 p-4 rounded-xl space-y-1.5">
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Vendor Rating</p>
                    <p className="text-lg font-extrabold text-slate-900">★ {activeVendor?.rating || 'New'}</p>
                    <p className="text-[9px] text-slate-400 font-medium">Trust Rank: high</p>
                  </div>
                </div>

                {/* Pending Tasks Panel */}
                <div className="border border-slate-200 rounded-2xl p-5 space-y-4">
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Awaiting Logistics Handover</h3>
                  
                  {vendorOrders.filter(o => o.status === 'Pending' || o.status === 'Confirmed' || o.status === 'Processing' || o.status === 'Packed').length === 0 ? (
                    <p className="text-xs text-slate-500 italic">No pending orders require packing or shipping.</p>
                  ) : (
                    <div className="space-y-3">
                      {vendorOrders.filter(o => o.status === 'Pending' || o.status === 'Confirmed' || o.status === 'Processing' || o.status === 'Packed').map((o) => (
                        <div key={o.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex flex-wrap justify-between items-center gap-2 text-xs">
                          <div>
                            <p className="font-bold text-slate-900">{o.id} • {o.createdAt}</p>
                            <p className="text-[10px] text-slate-500">Destination: {o.billingDetails.city}, {o.billingDetails.state}</p>
                            <div className="mt-1 space-y-0.5">
                              {o.items.filter(it => it.vendorId === activeVendor?.id).map((it, i) => (
                                <p key={i} className="text-[10px] text-slate-700 font-medium">• {it.quantity}x {it.productName}</p>
                              ))}
                            </div>
                          </div>
                          
                          <div className="flex gap-2">
                            {o.status === 'Pending' && (
                              <button
                                onClick={() => onUpdateOrderStatus(o.id, 'Confirmed')}
                                className="px-3 py-1.5 bg-blue-600 text-white font-bold text-[10px] rounded hover:bg-blue-700"
                              >
                                Accept Order
                              </button>
                            )}
                            {o.status === 'Confirmed' && (
                              <button
                                onClick={() => onUpdateOrderStatus(o.id, 'Processing')}
                                className="px-3 py-1.5 bg-indigo-600 text-white font-bold text-[10px] rounded hover:bg-indigo-700"
                              >
                                Start Processing
                              </button>
                            )}
                            {o.status === 'Processing' && (
                              <button
                                onClick={() => onUpdateOrderStatus(o.id, 'Packed')}
                                className="px-3 py-1.5 bg-amber-500 text-slate-950 font-black text-[10px] rounded hover:bg-amber-600"
                              >
                                Pack Components
                              </button>
                            )}
                            {o.status === 'Packed' && (
                              <button
                                onClick={() => triggerShipping(o)}
                                className="px-3 py-1.5 bg-emerald-500 text-slate-950 font-black text-[10px] rounded hover:bg-emerald-600 flex items-center gap-1"
                              >
                                <Truck className="w-3.5 h-3.5" /> Ship Order
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'products' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center border-b border-slate-100 pb-4">
                  <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Device Directory</h2>
                  <button
                    onClick={() => {
                      const container = document.getElementById('add-product-form-container');
                      if (container) container.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="px-4 py-2 bg-blue-600 text-white text-xs font-bold rounded-lg shadow-xs hover:bg-blue-700 transition-colors"
                  >
                    Add New Product
                  </button>
                </div>

                {/* List of current products */}
                <div className="space-y-3">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Active Listings ({vendorProducts.length})</h3>
                  <div className="border border-slate-200 rounded-xl overflow-hidden divide-y text-xs">
                    {vendorProducts.map((p) => (
                      <div key={p.id} className="p-4 bg-white hover:bg-slate-50/50 flex flex-wrap justify-between items-center gap-4">
                        <div className="flex gap-3 items-center">
                          <div className="w-10 h-10 rounded overflow-hidden border bg-slate-50 shrink-0">
                            <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <p className="font-bold text-slate-900 line-clamp-1">{p.name}</p>
                            <p className="text-[10px] text-slate-500 font-mono">SKU: {p.sku} • Category: {p.category}</p>
                          </div>
                        </div>

                        {/* Automatic pricing visualization */}
                        <div className="p-2 bg-slate-50 rounded border text-[10px] font-mono space-y-0.5 text-slate-600">
                          <p>Your Payout: <strong className="text-emerald-700">₹{(p.vendorPrice || p.sellingPrice || 0).toLocaleString()}</strong></p>
                          <p>MRP: <strong>₹{(p.mrp || 0).toLocaleString()}</strong></p>
                          <p>MOQ: <strong>{p.moq || 1} units</strong></p>
                          <p>GST Rate: <strong>{p.gstRate || 18}%</strong></p>
                        </div>

                        {/* Stock controls */}
                        <div className="flex items-center gap-3">
                          <div className="space-y-1">
                            <p className="text-[9px] text-slate-400 font-bold uppercase">Stock Count</p>
                            <input
                              type="number"
                              value={p.stock}
                              onChange={(e) => onUpdateStock(p.id, parseInt(e.target.value) || 0)}
                              className="w-16 p-1 border border-slate-200 rounded text-center text-xs font-bold bg-white"
                            />
                          </div>

                          <div className="text-right">
                            <p className="text-[9px] text-slate-400 font-bold uppercase">Admin Status</p>
                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${p.approved ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                              {p.approved ? 'Approved' : 'Pending Approval'}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Add product form container with Single vs Bulk toggle */}
                <div id="add-product-form-container" className="border border-slate-200 rounded-2xl p-6 bg-slate-50/50 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-4">
                    <div>
                      <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">Product Creation Hub</h3>
                      <p className="text-[10px] text-slate-500 font-semibold">Select listing strategy: submit an individual device or upload inventory in bulk.</p>
                    </div>

                    <div className="flex p-1 bg-slate-200/80 rounded-xl w-fit text-[11px] font-bold shrink-0">
                      <button
                        type="button"
                        onClick={() => setProductAddMode('single')}
                        className={`px-4 py-2 rounded-lg transition-all cursor-pointer ${
                          productAddMode === 'single' 
                            ? 'bg-slate-900 text-white shadow-xs' 
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        Single Device Listing
                      </button>
                      <button
                        type="button"
                        onClick={() => setProductAddMode('bulk')}
                        className={`px-4 py-2 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                          productAddMode === 'bulk' 
                            ? 'bg-slate-900 text-white shadow-xs' 
                            : 'text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        <FileSpreadsheet className="w-3.5 h-3.5" />
                        <span>Bulk CSV Upload</span>
                      </button>
                    </div>
                  </div>
                  
                  {productAddMode === 'single' ? (
                    <>
                      {prodSuccess && (
                        <div className="p-3 bg-emerald-50 text-emerald-800 rounded-lg text-xs font-bold">
                          ✓ Device listed successfully! It has been dispatched to the Super Admin approval queue.
                        </div>
                      )}

                      <form onSubmit={handleAddProduct} className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-bold">
                        <div className="space-y-1">
                          <label className="text-slate-600">Product Name <span className="text-red-500">*</span></label>
                          <input type="text" value={prodName} onChange={(e) => setProdName(e.target.value)} placeholder="e.g. Digital ICU Respiratory Ventilator" className="w-full p-2.5 rounded-lg border border-slate-200 bg-white focus:outline-hidden text-xs" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-slate-600">Unique SKU Code <span className="text-red-500">*</span></label>
                          <input type="text" value={prodSKU} onChange={(e) => setProdSKU(e.target.value)} placeholder="e.g. SKU-APX-VENT99" className="w-full p-2.5 rounded-lg border border-slate-200 bg-white focus:outline-hidden text-xs" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-slate-600">Medical Category <span className="text-red-500">*</span></label>
                          <select
                            value={prodCat}
                            onChange={(e) => setProdCat(e.target.value)}
                            className="w-full p-2.5 rounded-lg border border-slate-200 bg-white text-slate-800 font-bold text-xs"
                          >
                            {CATEGORIES.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
                          </select>
                        </div>
                        <div className="space-y-1">
                          <label className="text-slate-600">Device Brand Name <span className="text-red-500">*</span></label>
                          <input type="text" value={prodBrand} onChange={(e) => setProdBrand(e.target.value)} placeholder="e.g. ApexTech Corp" className="w-full p-2.5 rounded-lg border border-slate-200 bg-white focus:outline-hidden text-xs" />
                        </div>
                        <div className="space-y-1 md:col-span-2">
                          <label className="text-slate-600">Clinical Specifications & Description</label>
                          <textarea value={prodDesc} onChange={(e) => setProdDesc(e.target.value)} rows={3} placeholder="Provide detailed physical and electrical requirements of the device..." className="w-full p-2.5 rounded-lg border border-slate-200 bg-white font-medium focus:outline-hidden text-xs" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-slate-600">Image Asset URL (Simulated)</label>
                          <input type="text" value={prodImg} onChange={(e) => setProdImg(e.target.value)} className="w-full p-2.5 rounded-lg border border-slate-200 bg-white focus:outline-hidden text-xs" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-slate-600">Initial Stock Volume</label>
                          <input type="number" value={prodStock} onChange={(e) => setProdStock(e.target.value)} className="w-full p-2.5 rounded-lg border border-slate-200 bg-white focus:outline-hidden text-xs" />
                        </div>

                        {/* Simple inputs for Vendor Price, MRP, GST Rate, and MOQ */}
                        <div className="md:col-span-2 bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-4">
                          <div>
                            <h4 className="text-[11px] font-black text-slate-800 uppercase tracking-wider">Commercial & Pricing Strategy</h4>
                            <p className="text-[10px] text-slate-400 font-semibold mt-0.5">Platform commission and final customer price will be computed automatically according to your tier agreements.</p>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div className="space-y-1">
                              <label className="text-slate-600 block text-[10px] uppercase">Vendor Price (Amount you want to receive) <span className="text-red-500">*</span></label>
                              <input
                                type="number"
                                value={prodPrice}
                                onChange={(e) => setProdPrice(e.target.value)}
                                placeholder="e.g. 10000"
                                className="w-full p-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-xs font-bold"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-slate-600 block text-[10px] uppercase">MRP (Max Retail Price) <span className="text-red-500">*</span></label>
                              <input
                                type="number"
                                value={prodMrp}
                                onChange={(e) => setProdMrp(e.target.value)}
                                placeholder="e.g. 15000"
                                className="w-full p-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-xs font-bold"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-slate-600 block text-[10px] uppercase">GST Rate (%) (Optional)</label>
                              <input
                                type="number"
                                value={prodGstRate}
                                onChange={(e) => setProdGstRate(e.target.value)}
                                placeholder="e.g. 18"
                                className="w-full p-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-xs font-bold"
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-slate-600 block text-[10px] uppercase">MOQ (Min Order Qty) <span className="text-red-500">*</span></label>
                              <input
                                type="number"
                                value={prodMoq}
                                onChange={(e) => setProdMoq(e.target.value)}
                                placeholder="e.g. 1"
                                className="w-full p-2 rounded-lg border border-slate-200 bg-white text-slate-800 text-xs font-bold"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="md:col-span-2 pt-2">
                          <button type="submit" className="w-full py-3 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-slate-800 transition-colors cursor-pointer uppercase tracking-wider">
                            Submit Device to Super Admin Queue
                          </button>
                        </div>
                      </form>
                    </>
                  ) : (
                    <BulkUpload 
                      activeVendor={activeVendor}
                      onAddProduct={onAddProduct}
                      onSuccess={(count) => {
                        setProductAddMode('single');
                        setActiveTab('products');
                      }}
                    />
                  )}
                </div>
              </div>
            )}

            {activeTab === 'orders' && (
              <div className="space-y-6">
                <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Client Inbound Orders ({vendorOrders.length})</h2>
                
                {vendorOrders.length === 0 ? (
                  <p className="text-xs text-slate-500 italic">No orders received yet.</p>
                ) : (
                  <div className="space-y-4">
                    {vendorOrders.map((o) => {
                      const vendorShareTotal = o.items
                        .filter(it => it.vendorId === activeVendor?.id)
                        .reduce((sum, it) => sum + (it.sellingPrice * it.quantity), 0);

                      return (
                        <div key={o.id} className="border border-slate-200 rounded-xl p-4 bg-white space-y-3">
                          <div className="flex flex-wrap justify-between items-center border-b border-slate-100 pb-2">
                            <div>
                              <p className="text-xs font-extrabold text-slate-950">{o.id}</p>
                              <p className="text-[10px] text-slate-500 font-mono">Client: {o.billingDetails.name} • Email: {o.billingDetails.email}</p>
                            </div>
                            <span className="text-[10px] bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-black uppercase">
                              {o.status}
                            </span>
                          </div>

                          <div className="text-xs space-y-2">
                            <div>
                              <p className="text-[10px] text-slate-400 font-bold uppercase">Your Items:</p>
                              {o.items.filter(it => it.vendorId === activeVendor?.id).map((it, i) => (
                                <p key={i} className="font-bold text-slate-800">
                                  • {it.productName} (Qty: {it.quantity}) @ ₹{it.sellingPrice.toLocaleString()}/ea
                                </p>
                              ))}
                            </div>

                            <div className="flex justify-between items-center pt-2 border-t border-slate-50">
                              <span className="text-slate-500">Your Net Earnings (90% Base):</span>
                              <span className="font-black text-slate-900 text-sm">₹{vendorShareTotal.toLocaleString()}</span>
                            </div>
                          </div>

                          {/* Order stage advancement */}
                          <div className="flex gap-2 justify-end pt-2">
                            {o.status === 'Pending' && (
                              <button onClick={() => onUpdateOrderStatus(o.id, 'Confirmed')} className="px-3 py-1.5 bg-blue-600 text-white font-bold text-[10px] rounded hover:bg-blue-700">
                                Accept Order
                              </button>
                            )}
                            {o.status === 'Confirmed' && (
                              <button onClick={() => onUpdateOrderStatus(o.id, 'Processing')} className="px-3 py-1.5 bg-indigo-600 text-white font-bold text-[10px] rounded hover:bg-indigo-700">
                                Start Processing
                              </button>
                            )}
                            {o.status === 'Processing' && (
                              <button onClick={() => onUpdateOrderStatus(o.id, 'Packed')} className="px-3 py-1.5 bg-amber-500 text-slate-950 font-black text-[10px] rounded hover:bg-amber-600">
                                Pack Components
                              </button>
                            )}
                            {o.status === 'Packed' && (
                              <button onClick={() => triggerShipping(o)} className="px-3 py-1.5 bg-emerald-500 text-slate-950 font-black text-[10px] rounded hover:bg-emerald-600 flex items-center gap-1">
                                <Truck className="w-3.5 h-3.5" /> Ship Order
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'withdraw' && (
              <div className="space-y-6">
                <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Withdrawal Request Hub</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Account overview */}
                  <div className="bg-slate-50 p-5 rounded-xl border space-y-4">
                    <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Balance Breakdown</h3>
                    
                    <div className="space-y-2 text-xs font-bold text-slate-600">
                      <div className="flex justify-between">
                        <span>Gross Earned Share:</span>
                        <span className="text-slate-900">₹{totalEarnings.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Paid Out Withdrawals:</span>
                        <span className="text-slate-900">₹{totalWithdrawn.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Awaiting Admin Check:</span>
                        <span className="text-amber-600">₹{pendingWithdrawal.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-sm font-black text-slate-900 border-t pt-2">
                        <span>Available to Withdraw:</span>
                        <span className="text-emerald-600">₹{availableWithdrawableBalance.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  {/* Submission form */}
                  <div className="border p-5 rounded-xl space-y-3.5">
                    <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest font-mono">Request Bank Remittance</h3>
                    
                    {withdrawSuccess && (
                      <div className="p-2 bg-emerald-50 text-emerald-800 rounded font-bold text-[11px]">
                        ✓ Withdrawal logged. Awaiting Super Admin processing.
                      </div>
                    )}

                    <form onSubmit={handleWithdrawalRequestSubmit} className="space-y-3 text-xs font-bold">
                      <div className="space-y-1">
                        <label className="text-slate-500">Remittance Amount (₹)</label>
                        <input
                          type="number"
                          max={availableWithdrawableBalance}
                          value={withdrawAmt}
                          onChange={(e) => setWithdrawAmt(e.target.value)}
                          placeholder="Amount in Rupees"
                          className="w-full p-2 border border-slate-200 rounded-lg text-xs"
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={!withdrawAmt || parseFloat(withdrawAmt) <= 0 || parseFloat(withdrawAmt) > availableWithdrawableBalance}
                        className="w-full py-2 bg-blue-600 text-white font-bold text-xs rounded-xl disabled:bg-slate-200 disabled:text-slate-400"
                      >
                        Submit Request
                      </button>
                    </form>
                  </div>

                </div>

                {/* Withdrawal log list */}
                <div className="space-y-3">
                  <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Remittance Slips</h3>
                  {withdrawalRequests.filter(r => r.vendorId === activeVendor?.id).length === 0 ? (
                    <p className="text-xs text-slate-500 italic">No withdrawal requests filed yet.</p>
                  ) : (
                    <div className="border rounded-xl overflow-hidden divide-y text-xs">
                      {withdrawalRequests.filter(r => r.vendorId === activeVendor?.id).map((r) => (
                        <div key={r.id} className="p-3 bg-white flex justify-between items-center">
                          <div>
                            <p className="font-bold text-slate-900">Request: ₹{r.amount.toLocaleString()}</p>
                            <p className="text-[10px] text-slate-500">Bank: {r.bankDetails.bankName} • Account: {r.bankDetails.accountNumber}</p>
                          </div>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            r.status === 'Paid' ? 'bg-emerald-100 text-emerald-700' :
                            r.status === 'Pending' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
                          }`}>
                            {r.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>
            )}
          </>
        )}

        {/* Global Supplier Registration view */}
        {activeTab === 'register' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Register New Supplier Corporate Account</h2>
            
            {regSuccess && (
              <div className="p-4 bg-emerald-50 text-emerald-800 rounded-2xl text-xs font-bold flex gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>Supplier Account created successfully! Your profile status is marked as "Pending Review". Log in as Admin to approve.</span>
              </div>
            )}

            <form onSubmit={handleRegisterVendor} className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-bold">
              <div className="space-y-1">
                <label className="text-slate-600">Company Business Name <span className="text-red-500">*</span></label>
                <input type="text" value={regBusName} onChange={(e) => setRegBusName(e.target.value)} placeholder="e.g. MedLink Diagnostic Systems" className="w-full p-2.5 rounded-lg border border-slate-200" />
              </div>
              <div className="space-y-1">
                <label className="text-slate-600">Managing Owner Name <span className="text-red-500">*</span></label>
                <input type="text" value={regOwnerName} onChange={(e) => setRegOwnerName(e.target.value)} placeholder="e.g. Dr. Somnath Roy" className="w-full p-2.5 rounded-lg border border-slate-200" />
              </div>
              <div className="space-y-1">
                <label className="text-slate-600">Active Mobile Number <span className="text-red-500">*</span></label>
                <input type="text" value={regMobile} onChange={(e) => setRegMobile(e.target.value)} placeholder="+91 xxxxx xxxxx" className="w-full p-2.5 rounded-lg border border-slate-200" />
              </div>
              <div className="space-y-1">
                <label className="text-slate-600">Official Email ID <span className="text-red-500">*</span></label>
                <input type="email" value={regEmail} onChange={(e) => setRegEmail(e.target.value)} placeholder="licensing@medlink.com" className="w-full p-2.5 rounded-lg border border-slate-200" />
              </div>
              <div className="space-y-1">
                <label className="text-slate-600">GST Registration Number</label>
                <input type="text" value={regGST} onChange={(e) => setRegGST(e.target.value)} placeholder="e.g. 19DDDDD3333D4Z2" className="w-full p-2.5 rounded-lg border border-slate-200 font-mono" />
              </div>
              <div className="space-y-1">
                <label className="text-slate-600">PAN Number</label>
                <input type="text" value={regPAN} onChange={(e) => setRegPAN(e.target.value)} placeholder="e.g. PQRST3456X" className="w-full p-2.5 rounded-lg border border-slate-200 font-mono" />
              </div>
              <div className="space-y-1 md:col-span-2">
                <label className="text-slate-600">Official Physical Warehouse Address <span className="text-red-500">*</span></label>
                <textarea value={regAddress} onChange={(e) => setRegAddress(e.target.value)} rows={3} placeholder="Provide full industrial park address, city, state, country..." className="w-full p-2.5 rounded-lg border border-slate-200 font-medium" />
              </div>

              {/* Trade License Mandatory submission */}
              <div className="md:col-span-2 p-4 bg-amber-50 rounded-xl border border-amber-200 space-y-3">
                <div className="flex gap-2">
                  <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                  <div className="space-y-1">
                    <p className="text-xs font-black text-slate-900">Mandatory Trade License Audit Submission <span className="text-red-500">*</span></p>
                    <p className="text-[10px] text-slate-600">Clinical grade medical instruments require valid government clearance trade licenses.</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-4 items-center">
                  <div className="space-y-1">
                    <label className="text-slate-500 block text-[10px]">Trade License Code Number</label>
                    <input type="text" value={regTradeLicense} onChange={(e) => setRegTradeLicense(e.target.value)} className="p-2 border border-slate-300 rounded text-xs bg-white font-mono" />
                  </div>
                  <div className="flex-1 min-w-[200px]">
                    <div className="border-2 border-dashed border-slate-300 rounded-lg p-4 text-center cursor-pointer bg-white hover:bg-slate-50">
                      <Upload className="w-6 h-6 text-slate-400 mx-auto" />
                      <p className="text-[10px] text-slate-500 font-bold mt-1">Upload Scanned PDF (Simulated)</p>
                      <p className="text-[9px] text-slate-400">trade_license_scanned.pdf</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Bank Details Optional */}
              <div className="md:col-span-2 border-t border-slate-100 pt-4 space-y-3">
                <h3 className="text-xs font-black text-slate-900 uppercase">Bank Remittance Accounts (Optional)</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-slate-500">Account Holder Name</label>
                    <input type="text" value={regBankAccName} onChange={(e) => setRegBankAccName(e.target.value)} className="w-full p-2 border border-slate-200 rounded-lg" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-500">Account Number</label>
                    <input type="text" value={regBankAccNum} onChange={(e) => setRegBankAccNum(e.target.value)} className="w-full p-2 border border-slate-200 rounded-lg" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-500">Bank Name</label>
                    <input type="text" value={regBankName} onChange={(e) => setRegBankName(e.target.value)} className="w-full p-2 border border-slate-200 rounded-lg" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-500">IFSC Code</label>
                    <input type="text" value={regBankIFSC} onChange={(e) => setRegBankIFSC(e.target.value)} className="w-full p-2 border border-slate-200 rounded-lg font-mono" />
                  </div>
                </div>
              </div>

              <div className="md:col-span-2 pt-4">
                <button type="submit" className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl transition-all cursor-pointer">
                  Submit Corporate Vendor Registration
                </button>
              </div>
            </form>
          </div>
        )}

      </div>

      {/* Logistics Dispatch Modal (AWB entries) */}
      {processingOrder && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 relative shadow-2xl animate-in zoom-in-95 duration-150 text-xs font-bold">
            <button onClick={() => setProcessingOrder(null)} className="absolute top-4 right-4 p-1 text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
            <h3 className="text-sm font-black text-slate-900 uppercase">Input Air Waybill Tracking (MANDATORY)</h3>
            <p className="text-[11px] text-slate-500 font-medium">To safeguards hospital transactions, suppliers must specify valid logistics couriers before dispatching heavy-duty cargo.</p>
            
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-slate-600">Courier Partner Name <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  value={courierNameInput}
                  onChange={(e) => setCourierNameInput(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-200 bg-slate-50"
                  placeholder="e.g. BlueDart Medical Air Logistics"
                />
              </div>
              <div className="space-y-1">
                <label className="text-slate-600">AWB Tracking Number <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  value={trackingNumInput}
                  onChange={(e) => setTrackingNumInput(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-200 bg-slate-50 font-mono"
                  placeholder="e.g. BD-9908234-A"
                />
              </div>
            </div>

            <div className="pt-2 flex gap-2">
              <button
                onClick={() => setProcessingOrder(null)}
                className="flex-1 py-2.5 border rounded-xl text-slate-700 hover:bg-slate-50 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={confirmShipping}
                className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded-xl cursor-pointer"
              >
                Confirm Dispatch
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
