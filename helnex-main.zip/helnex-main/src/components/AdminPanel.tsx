import React, { useState } from 'react';
import { calculateProductPrices } from '../App';
import { 
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';
import { 
  ShieldAlert, 
  Users, 
  Store, 
  Package, 
  ClipboardList, 
  IndianRupee, 
  Check, 
  X, 
  AlertCircle, 
  Lock, 
  FileText, 
  Settings, 
  Plus, 
  Trash2, 
  Percent, 
  Megaphone, 
  CheckCircle, 
  HelpCircle, 
  Activity, 
  MessageSquare, 
  Download,
  QrCode,
  CreditCard
} from 'lucide-react';
import { Vendor, Product, Order, WithdrawalRequest, Coupon, Review, SupportTicket, CMSPage, ActivityLog, Notification } from '../types';
import { CATEGORIES } from '../data/mockData';

interface AdminPanelProps {
  vendors: Vendor[];
  products: Product[];
  orders: Order[];
  coupons: Coupon[];
  reviews: Review[];
  supportTickets: SupportTicket[];
  cmsPages: CMSPage[];
  activityLogs: ActivityLog[];
  notifications: Notification[];
  withdrawalRequests: WithdrawalRequest[];
  
  onApproveVendor: (id: string) => void;
  onRejectVendor: (id: string) => void;
  onSuspendVendor: (id: string) => void;
  
  onApproveProduct: (id: string) => void;
  onRejectProduct: (id: string) => void;
  onDeleteProduct: (id: string) => void;
  
  onBlockCustomer: (id: string) => void;
  onResetCustomerPassword: (id: string) => void;
  
  onApproveWithdrawal: (id: string) => void;
  onRejectWithdrawal: (id: string) => void;
  onMarkWithdrawalPaid: (id: string) => void;
  
  onAddCoupon: (c: Coupon) => void;
  onDeleteCoupon: (id: string) => void;
  
  onApproveReview: (id: string) => void;
  onRejectReview: (id: string) => void;
  
  onReplyTicket: (id: string, text: string) => void;
  onCloseTicket: (id: string) => void;
  
  onUpdateCMSContent: (slug: string, content: string) => void;
  onSendSystemNotification: (type: 'Email' | 'SMS' | 'WhatsApp' | 'Push', target: string, title: string, message: string) => void;

  globalCommission: number;
  setGlobalCommission: (val: number) => void;
  vendorCommissions: Record<string, number>;
  onSetVendorCommission: (vId: string, val: number) => void;
  categoryCommissions: Record<string, number>;
  onSetCategoryCommission: (catId: string, val: number) => void;
  brandCommissions: Record<string, number>;
  onSetBrandCommission: (brand: string, val: number) => void;
  commissionType: 'Percentage' | 'Fixed';
  setCommissionType: (val: 'Percentage' | 'Fixed') => void;
  minCommission: number;
  setMinCommission: (val: number) => void;
  maxCommission: number;
  setMaxCommission: (val: number) => void;
  gstOnCommission: boolean;
  setGstOnCommission: (val: boolean) => void;
  deductGatewayFee: boolean;
  setDeductGatewayFee: (val: boolean) => void;
  includeShipping: boolean;
  setIncludeShipping: (val: boolean) => void;
  onUpdateProductPricing: (productId: string, vendorPrice: number, mrp: number, customerPriceOverride?: number) => void;
  
  upiMerchantName: string;
  setUpiMerchantName: (val: string) => void;
  upiId: string;
  setUpiId: (val: string) => void;
  upiActive: boolean;
  setUpiActive: (val: boolean) => void;
  upiMinAmount: number;
  setUpiMinAmount: (val: number) => void;
  upiMaxAmount: number;
  setUpiMaxAmount: (val: number) => void;
  upiGatewayStatus: 'Operational' | 'Maintenance' | 'Disabled';
  setUpiGatewayStatus: (val: 'Operational' | 'Maintenance' | 'Disabled') => void;
}

export default function AdminPanel({
  vendors,
  products,
  orders,
  coupons,
  reviews,
  supportTickets,
  cmsPages,
  activityLogs,
  notifications,
  withdrawalRequests,
  onApproveVendor,
  onRejectVendor,
  onSuspendVendor,
  onApproveProduct,
  onRejectProduct,
  onDeleteProduct,
  onBlockCustomer,
  onResetCustomerPassword,
  onApproveWithdrawal,
  onRejectWithdrawal,
  onMarkWithdrawalPaid,
  onAddCoupon,
  onDeleteCoupon,
  onApproveReview,
  onRejectReview,
  onReplyTicket,
  onCloseTicket,
  onUpdateCMSContent,
  onSendSystemNotification,
  globalCommission,
  setGlobalCommission,
  vendorCommissions,
  onSetVendorCommission,
  categoryCommissions,
  onSetCategoryCommission,
  brandCommissions,
  onSetBrandCommission,
  commissionType,
  setCommissionType,
  minCommission,
  setMinCommission,
  maxCommission,
  setMaxCommission,
  gstOnCommission,
  setGstOnCommission,
  deductGatewayFee,
  setDeductGatewayFee,
  includeShipping,
  setIncludeShipping,
  onUpdateProductPricing,
  upiMerchantName,
  setUpiMerchantName,
  upiId,
  setUpiId,
  upiActive,
  setUpiActive,
  upiMinAmount,
  setUpiMinAmount,
  upiMaxAmount,
  setUpiMaxAmount,
  upiGatewayStatus,
  setUpiGatewayStatus
}: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'console' | 'vendors' | 'products' | 'commissions' | 'remittances' | 'coupons' | 'reviews' | 'cms' | 'notifications' | 'security' | 'payments'>('console');

  // IP blocking state
  const [blockedIps, setBlockedIps] = useState<string[]>(['103.88.22.44', '198.51.100.12']);
  const [newBlockedIp, setNewBlockedIp] = useState('');

  // Brand commissions state and helpers
  const [newBrandName, setNewBrandName] = useState('');
  const [newBrandVal, setNewBrandVal] = useState('10');

  // Inline product pricing editing state
  const [editingProdId, setEditingProdId] = useState<string | null>(null);
  const [editMrp, setEditMrp] = useState<number>(0);
  const [editVendorPrice, setEditVendorPrice] = useState<number>(0);
  const [editOverridePrice, setEditOverridePrice] = useState<string>('');

  // New coupon inputs
  const [newCode, setNewCode] = useState('');
  const [newType, setNewType] = useState<'Percentage' | 'Fixed'>('Percentage');
  const [newValue, setNewValue] = useState<string>('10');
  const [newMin, setNewMin] = useState<string>('1000');

  // Support ticket active chat reply
  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [adminReplyText, setAdminReplyText] = useState('');

  // Notification form
  const [notifTarget, setNotifTarget] = useState('all');
  const [notifType, setNotifType] = useState<'Email' | 'SMS' | 'WhatsApp' | 'Push'>('Email');
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [notifSuccess, setNotifSuccess] = useState(false);

  // Active editable CMS Page slug
  const [activeCmsSlug, setActiveCmsSlug] = useState<string>('about-us');
  const [cmsEditContent, setCmsEditContent] = useState<string>('');

  // Derived metrics
  const totalRevenue = orders.reduce((sum, o) => sum + o.total, 0);
  const totalCommissionEarned = orders.reduce((sum, o) => {
    // Collect all commissions from order items
    const comm = o.items.reduce((s, item) => s + (item.commissionAmount * item.quantity), 0);
    return sum + comm;
  }, 0);
  const pendingVendorsCount = vendors.filter(v => v.status === 'Pending').length;
  const pendingProductsCount = products.filter(p => !p.approved).length;
  const pendingWithdrawalsCount = withdrawalRequests.filter(r => r.status === 'Pending').length;

  // Mock static data for Recharts
  const salesChartData = [
    { day: 'Mon', revenue: 15000, commission: 1500 },
    { day: 'Tue', revenue: 28000, commission: 2800 },
    { day: 'Wed', revenue: 32000, commission: 3200 },
    { day: 'Thu', revenue: 19000, commission: 1900 },
    { day: 'Fri', revenue: 46200, commission: 4620 },
    { day: 'Sat', revenue: 52000, commission: 5200 },
    { day: 'Sun', revenue: 64000, commission: 6400 }
  ];

  const vendorPerformanceData = vendors.filter(v => v.status === 'Approved').map(v => {
    // Sum of orders from this vendor
    const vOrders = orders.filter(o => o.items.some(it => it.vendorId === v.id));
    const salesVolume = vOrders.reduce((sum, o) => {
      const share = o.items.filter(it => it.vendorId === v.id).reduce((s, it) => s + (it.sellingPrice * it.quantity), 0);
      return sum + share;
    }, 0);
    return {
      name: v.businessName.substring(0, 15) + '...',
      sales: salesVolume || 5000 // default minimum for display
    };
  });

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCode || !newValue) return;
    onAddCoupon({
      id: Date.now().toString(),
      code: newCode.trim().toUpperCase(),
      type: newType,
      value: parseFloat(newValue) || 0,
      minPurchase: parseFloat(newMin) || 0,
      active: true
    });
    setNewCode('');
    setNewValue('10');
    setNewMin('1000');
  };

  const handleSendNotificationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!notifTitle || !notifMessage) return;
    onSendSystemNotification(notifType, notifTarget, notifTitle, notifMessage);
    setNotifTitle('');
    setNotifMessage('');
    setNotifSuccess(true);
    setTimeout(() => setNotifSuccess(false), 3000);
  };

  const handleSaveCMS = (slug: string) => {
    onUpdateCMSContent(slug, cmsEditContent);
    alert('CMS page content updated and saved to simulated database tables!');
  };

  const loadCmsContent = (slug: string) => {
    setActiveCmsSlug(slug);
    const matched = cmsPages.find(p => p.slug === slug);
    setCmsEditContent(matched ? matched.content : '');
  };

  // Initialize CMS editor content
  React.useEffect(() => {
    if (cmsPages.length > 0 && !cmsEditContent) {
      loadCmsContent('about-us');
    }
  }, [cmsPages]);

  return (
    <div className="bg-white rounded-lg border border-slate-200 grid grid-cols-1 lg:grid-cols-4 overflow-hidden min-h-[80vh]">
      
      {/* Sidebar Nav */}
      <div className="bg-slate-950 text-slate-300 p-6 flex flex-col justify-between border-r border-slate-800">
        <div className="space-y-6">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-slate-400 shrink-0" />
            <h2 className="text-xs font-bold text-white uppercase tracking-wider font-display">Super Admin Console</h2>
          </div>

          <div className="space-y-1">
            {[
              { id: 'console', label: 'Admin Telemetry', icon: Activity },
              { id: 'vendors', label: 'Vendor Approvals', icon: Store, badge: pendingVendorsCount },
              { id: 'products', label: 'Product Audits', icon: Package, badge: pendingProductsCount },
              { id: 'commissions', label: 'Commission Rule Center', icon: Percent },
              { id: 'remittances', label: 'Bank Remittances', icon: IndianRupee, badge: pendingWithdrawalsCount },
              { id: 'coupons', label: 'Coupons & Discounts', icon: Settings },
              { id: 'payments', label: 'UPI & Payment Gateway', icon: QrCode },
              { id: 'reviews', label: 'Reviews & Tickets', icon: MessageSquare },
              { id: 'cms', label: 'CMS Policy Editor', icon: FileText },
              { id: 'notifications', label: 'Mass Broadcaster', icon: Megaphone },
              { id: 'security', label: 'Security Activity Logs', icon: ShieldAlert }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full text-left px-3 py-2 rounded-md text-xs font-medium transition-all flex items-center justify-between cursor-pointer ${
                    activeTab === tab.id 
                      ? 'bg-white text-slate-950 font-semibold shadow-xs' 
                      : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-3.5 h-3.5 shrink-0" />
                    <span>{tab.label}</span>
                  </div>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="bg-rose-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-sm">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Minimalist footer with role label */}
        <div className="pt-6 border-t border-slate-900 text-[10px] font-mono text-slate-500">
          <p>HealNex Master Admin System</p>
        </div>
      </div>

      {/* Workspace Area */}
      <div className="lg:col-span-3 p-6 lg:p-8 space-y-6 overflow-y-auto max-h-[85vh]">
        
        {activeTab === 'console' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Super Admin Performance Telemetry</h2>
            
            {/* Multi Metrics Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-bold">
              <div className="bg-white border p-4 rounded-xl space-y-1">
                <p className="text-slate-500 uppercase text-[9px]">Total Commission Earned</p>
                <p className="text-xl font-black text-blue-700">₹{totalCommissionEarned.toLocaleString()}</p>
                <p className="text-[10px] text-slate-400 font-mono">Formula split verified</p>
              </div>
              <div className="bg-white border p-4 rounded-xl space-y-1">
                <p className="text-slate-500 uppercase text-[9px]">Total Gross Sales</p>
                <p className="text-xl font-black text-slate-950">₹{totalRevenue.toLocaleString()}</p>
                <p className="text-[10px] text-slate-400 font-mono">Gross Order values</p>
              </div>
              <div className="bg-white border p-4 rounded-xl space-y-1">
                <p className="text-slate-500 uppercase text-[9px]">Registered Vendors</p>
                <p className="text-xl font-black text-slate-950">{vendors.length}</p>
                <p className="text-[10px] text-amber-600 font-semibold">{pendingVendorsCount} Pending Approval</p>
              </div>
              <div className="bg-white border p-4 rounded-xl space-y-1">
                <p className="text-slate-500 uppercase text-[9px]">Client Orders Filed</p>
                <p className="text-xl font-black text-slate-950">{orders.length}</p>
                <p className="text-[10px] text-emerald-600 font-semibold">{orders.filter(o => o.status === 'Delivered').length} Delivered</p>
              </div>
            </div>

            {/* Recharts Live Analytics Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Sales area chart */}
              <div className="bg-white border border-slate-200 p-4 rounded-2xl space-y-3">
                <div>
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Revenue Analytics</h3>
                  <p className="text-[10px] text-slate-500">Gross customer checkout flow (simulated weekly telemetry)</p>
                </div>
                <div className="w-full h-56 font-sans">
                  <ResponsiveContainer width="100%" height={200}>
                    <AreaChart data={salesChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip />
                      <Area type="monotone" dataKey="revenue" stroke="#3b82f6" fill="#eff6ff" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Vendor performance bar chart */}
              <div className="bg-white border border-slate-200 p-4 rounded-2xl space-y-3">
                <div>
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Vendor Sales Distribution</h3>
                  <p className="text-[10px] text-slate-500">Gross sales volume generated per approved medical merchant (INR)</p>
                </div>
                <div className="w-full h-56 font-sans">
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={vendorPerformanceData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip />
                      <Bar dataKey="sales" fill="#10b981" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>

            {/* Invoices list and download section */}
            <div className="border rounded-2xl p-5 bg-white space-y-4">
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Payment Ledger & Invoices</h3>
              <div className="border border-slate-100 rounded-xl overflow-hidden divide-y text-xs">
                {orders.map((o) => (
                  <div key={o.id} className="p-3 bg-slate-50/50 hover:bg-slate-50 flex flex-wrap justify-between items-center gap-2">
                    <div>
                      <p className="font-bold text-slate-900">{o.id} ({o.paymentMethod})</p>
                      <p className="text-[10px] text-slate-500">Buyer: {o.billingDetails.name} • Email: {o.billingDetails.email}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="font-bold text-slate-950 font-mono">₹{o.total.toLocaleString()}</span>
                      <button
                        onClick={() => {
                          alert(`Simulating secure invoice download for ${o.id}... invoice_receipt_${o.id}.pdf compiled and downloaded!`);
                        }}
                        className="p-1 text-blue-600 hover:text-blue-800 rounded bg-white border border-slate-200 flex items-center gap-1 text-[10px] font-bold"
                      >
                        <Download className="w-3.5 h-3.5" /> PDF
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'vendors' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Vendor Approvals & Audits</h2>

            {/* Awaiting approvals queue */}
            <div className="space-y-3">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Awaiting Trade License Auditing ({pendingVendorsCount})</h3>
              {pendingVendorsCount === 0 ? (
                <p className="text-xs text-slate-500 italic bg-white p-4 border border-slate-150 rounded-xl">No pending corporate supplier registrations.</p>
              ) : (
                <div className="space-y-4">
                  {vendors.filter(v => v.status === 'Pending').map((v) => (
                    <div key={v.id} className="border border-slate-200 rounded-2xl p-5 bg-white space-y-4">
                      <div className="flex justify-between items-start border-b border-slate-100 pb-3">
                        <div>
                          <p className="text-sm font-bold text-slate-900">{v.businessName}</p>
                          <p className="text-xs text-slate-500">Managing Owner: {v.ownerName} • Email: {v.email}</p>
                        </div>
                        <span className="bg-amber-100 text-amber-800 text-[9px] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">Awaiting Audit</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono text-slate-600 bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <p>📍 Location Address: <span className="font-sans font-bold text-slate-800">{v.businessAddress}</span></p>
                        <p>📞 Contact Phone: <span className="font-sans font-bold text-slate-800">{v.mobile}</span></p>
                        <p>📄 Trade License ID: <span className="font-sans font-bold text-slate-800">{v.tradeLicense} (Mandatory Verified)</span></p>
                        <p>🔢 GST Registered: <span className="font-sans font-bold text-slate-800">{v.gstNumber || 'Not provided'}</span></p>
                        {v.bankDetails && (
                          <p className="md:col-span-2">🏦 Bank Remittance: <span className="font-sans font-bold text-slate-800">{v.bankDetails.bankName} - A/C: {v.bankDetails.accountNumber}</span></p>
                        )}
                      </div>

                      {/* Approve / Reject Actions */}
                      <div className="flex gap-2 justify-end">
                        <button
                          onClick={() => onRejectVendor(v.id)}
                          className="px-3.5 py-2 border border-rose-200 hover:bg-rose-50 text-rose-600 text-xs font-bold rounded-lg cursor-pointer"
                        >
                          Reject Supplier
                        </button>
                        <button
                          onClick={() => onApproveVendor(v.id)}
                          className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-black rounded-lg shadow-sm cursor-pointer"
                        >
                          Approve Trade License & List
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Approved / Active vendors list */}
            <div className="space-y-3">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Active Suppliers Directory</h3>
              <div className="border border-slate-200 rounded-xl overflow-hidden divide-y text-xs">
                {vendors.filter(v => v.status !== 'Pending').map((v) => (
                  <div key={v.id} className="p-4 bg-white flex flex-wrap justify-between items-center gap-3">
                    <div>
                      <p className="font-bold text-slate-900">{v.businessName} (Director: {v.ownerName})</p>
                      <p className="text-[10px] text-slate-500">License: {v.tradeLicense} • Email: {v.email}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        v.status === 'Approved' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                      }`}>
                        {v.status}
                      </span>
                      {v.status === 'Approved' ? (
                        <button
                          onClick={() => onSuspendVendor(v.id)}
                          className="px-2.5 py-1 text-rose-600 border border-rose-150 hover:bg-rose-50 text-[10px] font-bold rounded-md"
                        >
                          Suspend
                        </button>
                      ) : (
                        <button
                          onClick={() => onApproveVendor(v.id)}
                          className="px-2.5 py-1 text-emerald-600 border border-emerald-150 hover:bg-emerald-50 text-[10px] font-bold rounded-md"
                        >
                          Re-approve
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'products' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Clinical Product Audits</h2>

            {/* Queue */}
            <div className="space-y-3">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Pending Product Approvals ({pendingProductsCount})</h3>
              {pendingProductsCount === 0 ? (
                <p className="text-xs text-slate-500 italic bg-white p-4 border rounded-xl">No pending medical device listings.</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {products.filter(p => !p.approved).map((p) => (
                    <div key={p.id} className="border border-slate-200 rounded-xl p-4 bg-white space-y-3 text-xs">
                      <div className="flex gap-2">
                        <div className="w-12 h-12 rounded border bg-slate-50 shrink-0 overflow-hidden">
                          <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <p className="font-bold text-slate-950">{p.name}</p>
                          <p className="text-[10px] text-slate-500">Brand: {p.brand} • Vendor: {p.vendorName}</p>
                        </div>
                      </div>

                      <p className="text-slate-600 leading-relaxed text-[11px] h-12 line-clamp-3">{p.description}</p>

                      <div className="bg-slate-50 p-2 rounded border font-mono text-[10px] space-y-0.5">
                        <p>Vendor Base Price: <strong>₹{p.sellingPrice.toLocaleString()}</strong></p>
                        <p className="text-blue-600 font-bold">Auto Final Customer Price: <strong>₹{p.customerPrice.toLocaleString()}</strong></p>
                      </div>

                      <div className="flex gap-2 pt-2 justify-end">
                        <button
                          onClick={() => onRejectProduct(p.id)}
                          className="px-3 py-1.5 border border-rose-200 text-rose-600 hover:bg-rose-50 rounded font-bold text-[10px]"
                        >
                          Reject
                        </button>
                        <button
                          onClick={() => onApproveProduct(p.id)}
                          className="px-3 py-1.5 bg-blue-600 text-white rounded font-bold text-[10px] hover:bg-blue-700"
                        >
                          Approve & List
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Active directory of products */}
            <div className="space-y-3">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Approved Products Catalog Directory</h3>
              <div className="border border-slate-200 rounded-xl overflow-hidden divide-y text-xs">
                {products.filter(p => p.approved).map((p) => (
                  <div key={p.id} className="p-3 bg-white flex flex-wrap justify-between items-center gap-3">
                    <div className="flex gap-2 items-center">
                      <div className="w-8 h-8 rounded border bg-slate-50 overflow-hidden">
                        <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">{p.name}</p>
                        <p className="text-[10px] text-slate-500">SKU: {p.sku} • Supplier: {p.vendorName}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-6">
                      <div className="text-right font-mono text-[10px] text-slate-600">
                        <p>Base: ₹{p.sellingPrice.toLocaleString()}</p>
                        <p className="text-blue-600 font-bold">Final: ₹{p.customerPrice.toLocaleString()}</p>
                      </div>
                      <button
                        onClick={() => onDeleteProduct(p.id)}
                        className="text-rose-500 hover:text-rose-700 p-1.5"
                        title="Delete Product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'commissions' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center border-b pb-4">
              <div>
                <h2 className="text-base font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                  <Percent className="w-5 h-5 text-blue-600" />
                  Commission Engine & Automated Pricing
                </h2>
                <p className="text-[11px] text-slate-500 font-semibold mt-0.5">Configure rule-based margins and manage client-facing pricing metrics automatically.</p>
              </div>
            </div>

            {/* Hierarchy Notice banner */}
            <div className="bg-blue-50/70 p-4 rounded-xl border border-blue-100 text-xs text-blue-950 space-y-2">
              <p className="font-extrabold uppercase tracking-wider text-[10px] text-blue-800">Hierarchy & Precedence Settings:</p>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-[11px] font-semibold">
                <div className="p-2.5 bg-white rounded-lg border border-blue-100/50">
                  <span className="text-blue-600 font-bold">1st Priority:</span>
                  <p className="text-slate-700 mt-0.5">Vendor Override</p>
                </div>
                <div className="p-2.5 bg-white rounded-lg border border-blue-100/50">
                  <span className="text-blue-600 font-bold">2nd Priority:</span>
                  <p className="text-slate-700 mt-0.5">Brand Override</p>
                </div>
                <div className="p-2.5 bg-white rounded-lg border border-blue-100/50">
                  <span className="text-blue-600 font-bold">3rd Priority:</span>
                  <p className="text-slate-700 mt-0.5">Category Override</p>
                </div>
                <div className="p-2.5 bg-white rounded-lg border border-blue-100/50">
                  <span className="text-blue-600 font-bold">4th Priority:</span>
                  <p className="text-slate-700 mt-0.5">Global Fallback</p>
                </div>
              </div>
            </div>

            {/* Grid 1: Basic Commission Settings & Overrides */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs font-bold">
              
              {/* Box A: Pricing Engine Parameters */}
              <div className="bg-white border border-slate-100 rounded-2xl p-5 space-y-4 shadow-xs">
                <h3 className="text-[11px] font-black text-slate-900 uppercase tracking-widest border-b pb-2">
                  Pricing Parameters
                </h3>
                
                <div className="space-y-3.5">
                  <div className="space-y-1">
                    <label className="text-slate-500 font-bold block text-[10px] uppercase">Commission Formula Structure</label>
                    <select
                      value={commissionType}
                      onChange={(e) => setCommissionType(e.target.value as 'Percentage' | 'Fixed')}
                      className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden"
                    >
                      <option value="Percentage">Percentage Margin (%)</option>
                      <option value="Fixed">Fixed Amount Fee (₹)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-500 block text-[10px] uppercase">Global Base Fallback</label>
                    <div className="relative">
                      <input
                        type="number"
                        value={globalCommission}
                        onChange={(e) => setGlobalCommission(parseFloat(e.target.value) || 0)}
                        className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden pr-8"
                      />
                      <span className="absolute right-2.5 top-2 text-slate-400 font-mono">
                        {commissionType === 'Percentage' ? '%' : '₹'}
                      </span>
                    </div>
                  </div>

                  {/* Min / Max bounds */}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="space-y-1">
                      <label className="text-slate-500 text-[9px] uppercase">Min Bound (₹)</label>
                      <input
                        type="number"
                        value={minCommission}
                        onChange={(e) => setMinCommission(parseFloat(e.target.value) || 0)}
                        className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-500 text-[9px] uppercase">Max Bound (₹)</label>
                      <input
                        type="number"
                        value={maxCommission}
                        onChange={(e) => setMaxCommission(parseFloat(e.target.value) || 0)}
                        className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-hidden"
                      />
                    </div>
                  </div>

                  {/* Advanced Multipliers toggles */}
                  <div className="pt-3 border-t space-y-2.5">
                    <label className="text-slate-500 block text-[9px] uppercase tracking-wider">Advanced Cost Additions</label>
                    
                    <div className="flex justify-between items-center p-2 rounded bg-slate-50/60">
                      <div>
                        <p className="text-[11px] text-slate-800">Apply GST (18% on Comm.)</p>
                        <p className="text-[9px] text-slate-400">Adds GST to final customer price</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={gstOnCommission}
                        onChange={(e) => setGstOnCommission(e.target.checked)}
                        className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
                      />
                    </div>

                    <div className="flex justify-between items-center p-2 rounded bg-slate-50/60">
                      <div>
                        <p className="text-[11px] text-slate-800">Payment Gateway Fee (2%)</p>
                        <p className="text-[9px] text-slate-400">Deducted from vendor remittance</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={deductGatewayFee}
                        onChange={(e) => setDeductGatewayFee(e.target.checked)}
                        className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 animate-none cursor-pointer"
                      />
                    </div>

                    <div className="flex justify-between items-center p-2 rounded bg-slate-50/60">
                      <div>
                        <p className="text-[11px] text-slate-800">Flat Shipping Markup (₹150)</p>
                        <p className="text-[9px] text-slate-400">Incorporated into customer price</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={includeShipping}
                        onChange={(e) => setIncludeShipping(e.target.checked)}
                        className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 animate-none cursor-pointer"
                      />
                    </div>
                  </div>

                </div>
              </div>

              {/* Box B: Category overrides */}
              <div className="bg-white border border-slate-100 rounded-2xl p-5 space-y-4 shadow-xs">
                <h3 className="text-[11px] font-black text-slate-900 uppercase tracking-widest border-b pb-2">
                  Category Overrides
                </h3>
                <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
                  {CATEGORIES.map((cat) => (
                    <div key={cat.id} className="flex justify-between items-center p-2.5 rounded-lg border border-slate-50 bg-slate-50/40">
                      <span className="text-slate-700 font-bold text-[11px]">{cat.name}</span>
                      <div className="flex gap-1.5 items-center">
                        <input
                          type="number"
                          value={categoryCommissions[cat.id] !== undefined ? categoryCommissions[cat.id] : globalCommission}
                          onChange={(e) => onSetCategoryCommission(cat.id, parseFloat(e.target.value) || 0)}
                          className="w-14 p-1 border border-slate-200 bg-white rounded text-center font-bold"
                        />
                        <span className="text-slate-400">{commissionType === 'Percentage' ? '%' : '₹'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Box C: Brand overrides */}
              <div className="bg-white border border-slate-100 rounded-2xl p-5 space-y-4 shadow-xs">
                <h3 className="text-[11px] font-black text-slate-900 uppercase tracking-widest border-b pb-2">
                  Brand Overrides
                </h3>

                <div className="space-y-3">
                  {/* Add Brand override form */}
                  <div className="p-3 bg-slate-50 border rounded-xl space-y-2">
                    <p className="text-[10px] text-slate-500 uppercase tracking-wider">Configure Custom Brand rate</p>
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        placeholder="e.g. Siemens"
                        value={newBrandName}
                        onChange={(e) => setNewBrandName(e.target.value)}
                        className="p-1.5 border bg-white rounded text-xs font-semibold focus:outline-hidden"
                      />
                      <input
                        type="number"
                        placeholder="Rate"
                        value={newBrandVal}
                        onChange={(e) => setNewBrandVal(e.target.value)}
                        className="p-1.5 border bg-white rounded text-xs font-semibold focus:outline-hidden"
                      />
                    </div>
                    <button
                      onClick={() => {
                        if (!newBrandName.trim()) return;
                        onSetBrandCommission(newBrandName.trim(), parseFloat(newBrandVal) || 0);
                        setNewBrandName('');
                      }}
                      className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[10px] rounded font-bold cursor-pointer"
                    >
                      + Add Brand Rule
                    </button>
                  </div>

                  <div className="space-y-2 max-h-[190px] overflow-y-auto pr-1">
                    {Object.keys(brandCommissions).length === 0 ? (
                      <p className="text-slate-400 italic text-[10px] text-center py-4">No special Brand commission rules declared.</p>
                    ) : (
                      Object.entries(brandCommissions).map(([brand, val]) => (
                        <div key={brand} className="flex justify-between items-center p-2 rounded bg-slate-50/50 border">
                          <span className="text-slate-700 font-bold text-[11px]">{brand}</span>
                          <div className="flex gap-1.5 items-center">
                            <input
                              type="number"
                              value={val}
                              onChange={(e) => onSetBrandCommission(brand, parseFloat(e.target.value) || 0)}
                              className="w-14 p-1 border bg-white rounded text-center text-xs font-bold"
                            />
                            <span className="text-slate-400">{commissionType === 'Percentage' ? '%' : '₹'}</span>
                            <button
                              onClick={() => onSetBrandCommission(brand, undefined as any)}
                              className="text-rose-500 hover:text-rose-700 text-[10px] ml-1 font-bold cursor-pointer"
                            >
                              ✕
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Vendor-Specific special overrides (full width) */}
              <div className="bg-white border border-slate-100 rounded-2xl p-5 space-y-3.5 lg:col-span-3 shadow-xs">
                <h3 className="text-[11px] font-black text-slate-900 uppercase tracking-widest border-b pb-2">
                  Vendor-Specific Commission Overrides
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {vendors.filter(v => v.status === 'Approved').map((v) => (
                    <div key={v.id} className="flex justify-between items-center p-3 rounded-xl border border-slate-100 bg-slate-50/30">
                      <div>
                        <p className="text-slate-800 text-[11px] font-bold">{v.businessName}</p>
                        <p className="text-[9px] text-slate-400">ID: {v.id}</p>
                      </div>
                      <div className="flex gap-1.5 items-center">
                        <input
                          type="number"
                          value={vendorCommissions[v.id] !== undefined ? vendorCommissions[v.id] : globalCommission}
                          onChange={(e) => onSetVendorCommission(v.id, parseFloat(e.target.value) || 0)}
                          className="w-16 p-1 border bg-white rounded text-center text-xs font-bold"
                        />
                        <span className="text-slate-400 font-bold">{commissionType === 'Percentage' ? '%' : '₹'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* FULL WIDTH: Product Pricing Table (Admin Only) */}
            <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
              <div className="p-4 border-b bg-slate-50 flex flex-wrap justify-between items-center gap-3">
                <div>
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">
                    Product Pricing Table (Admin Only)
                  </h3>
                  <p className="text-[10px] text-slate-500 font-semibold">Simulate, override, and analyze real-time customer pricing and margins across all medical devices.</p>
                </div>
                <div className="text-[10px] text-blue-800 bg-blue-50 border border-blue-100 px-3 py-1 rounded-lg font-black uppercase tracking-wider">
                  Admin Master Control Center
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-700">
                  <thead className="bg-slate-100/65 text-slate-600 font-bold uppercase tracking-wider text-[10px] border-b">
                    <tr>
                      <th className="p-3.5">Medical Product</th>
                      <th className="p-3.5">Supplier</th>
                      <th className="p-3.5 text-right">MRP (₹)</th>
                      <th className="p-3.5 text-right">Vendor Price (₹)</th>
                      <th className="p-3.5 text-right">Platform Commission</th>
                      <th className="p-3.5 text-right">Final Customer Price (₹)</th>
                      <th className="p-3.5 text-center">Profit / Margin</th>
                      <th className="p-3.5 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {products.map((p) => {
                      const isEditing = editingProdId === p.id;
                      
                      // Dynamic live calculations if currently editing
                      const effectiveVendorPrice = isEditing ? editVendorPrice : (p.vendorPrice || p.sellingPrice || 0);
                      const effectiveMrp = isEditing ? editMrp : (p.mrp || effectiveVendorPrice * 1.5);
                      
                      // Live formula calculations on the flyer
                      const livePrices = calculateProductPrices(
                        effectiveVendorPrice,
                        effectiveMrp,
                        p.category,
                        p.brand,
                        p.vendorId,
                        globalCommission,
                        vendorCommissions,
                        categoryCommissions,
                        brandCommissions,
                        commissionType,
                        minCommission,
                        maxCommission,
                        gstOnCommission,
                        deductGatewayFee,
                        includeShipping
                      );

                      // Final display prices
                      const displayCustomerPrice = isEditing
                        ? (editOverridePrice !== '' ? parseInt(editOverridePrice) || 0 : livePrices.customerPrice)
                        : (p.customerPrice || livePrices.customerPrice);

                      const displayCommAmount = isEditing
                        ? (displayCustomerPrice - effectiveVendorPrice)
                        : (p.customerPrice - (p.vendorPrice || p.sellingPrice || 0));

                      const displayMargin = displayCustomerPrice > 0
                        ? Math.round((displayCommAmount / displayCustomerPrice) * 100)
                        : 0;

                      return (
                        <tr key={p.id} className={`hover:bg-slate-50/50 transition-colors ${isEditing ? 'bg-blue-50/20' : ''}`}>
                          {/* Col 1: Product details */}
                          <td className="p-3.5 font-bold">
                            <div className="flex items-center gap-2.5">
                              <img src={p.imageUrl} alt={p.name} className="w-8 h-8 rounded-lg border object-cover shrink-0" />
                              <div>
                                <p className="text-slate-900 text-[11px] line-clamp-1">{p.name}</p>
                                <p className="text-[9px] text-slate-400 font-mono">SKU: {p.sku} • {p.brand}</p>
                              </div>
                            </div>
                          </td>

                          {/* Col 2: Vendor */}
                          <td className="p-3.5 text-slate-600 font-semibold">{p.vendorName}</td>

                          {/* Col 3: MRP */}
                          <td className="p-3.5 text-right font-mono font-bold text-slate-700">
                            {isEditing ? (
                              <input
                                type="number"
                                value={editMrp}
                                onChange={(e) => setEditMrp(Math.max(0, parseInt(e.target.value) || 0))}
                                className="w-20 p-1 border border-slate-300 rounded bg-white text-right font-mono text-xs font-bold"
                              />
                            ) : (
                              `₹${(p.mrp || 0).toLocaleString()}`
                            )}
                          </td>

                          {/* Col 4: Vendor Price */}
                          <td className="p-3.5 text-right font-mono font-bold text-emerald-700">
                            {isEditing ? (
                              <input
                                type="number"
                                value={editVendorPrice}
                                onChange={(e) => setEditVendorPrice(Math.max(0, parseInt(e.target.value) || 0))}
                                className="w-20 p-1 border border-slate-300 rounded bg-white text-right font-mono text-xs font-bold"
                              />
                            ) : (
                              `₹${(p.vendorPrice || p.sellingPrice || 0).toLocaleString()}`
                            )}
                          </td>

                          {/* Col 5: Platform Commission */}
                          <td className="p-3.5 text-right text-blue-700 font-bold">
                            <div className="font-mono text-xs">
                              ₹{displayCommAmount.toLocaleString()}
                            </div>
                            <span className="text-[9px] text-slate-400 font-sans block mt-0.5">
                              {isEditing ? `Live Rate Rules applied` : `${p.commissionPercent}% standard share`}
                            </span>
                          </td>

                          {/* Col 6: Final Customer Price */}
                          <td className="p-3.5 text-right">
                            {isEditing ? (
                              <div className="space-y-1">
                                <input
                                  type="number"
                                  placeholder="Override Price"
                                  value={editOverridePrice}
                                  onChange={(e) => setEditOverridePrice(e.target.value)}
                                  className="w-24 p-1 border border-slate-300 rounded bg-white text-right font-mono text-xs font-bold text-blue-700 focus:outline-hidden"
                                />
                                <span className="text-[8px] text-slate-400 block font-semibold">Blank = use rule-based price (₹{livePrices.customerPrice.toLocaleString()})</span>
                              </div>
                            ) : (
                              <div>
                                <span className="font-mono font-black text-slate-900 text-xs">₹{displayCustomerPrice.toLocaleString()}</span>
                                {p.customerPriceOverride !== undefined && (
                                  <span className="bg-amber-100 text-amber-800 text-[8px] font-black uppercase px-1 py-0.2 rounded block mt-0.5 w-max ml-auto">Overridden</span>
                                )}
                              </div>
                            )}
                          </td>

                          {/* Col 7: Profit / Margin */}
                          <td className="p-3.5 text-center">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                              displayMargin > 15 ? 'bg-emerald-50 text-emerald-700' :
                              displayMargin > 5 ? 'bg-blue-50 text-blue-700' :
                              'bg-rose-50 text-rose-700'
                            }`}>
                              {displayMargin}% Marg.
                            </span>
                            <span className="block font-mono text-[9px] text-slate-400 mt-1">₹{displayCommAmount.toLocaleString()} profit</span>
                          </td>

                          {/* Col 8: Actions */}
                          <td className="p-3.5 text-center">
                            {isEditing ? (
                              <div className="flex gap-1.5 justify-center">
                                <button
                                  onClick={() => {
                                    const parsedOverride = editOverridePrice === '' ? undefined : parseInt(editOverridePrice) || undefined;
                                    onUpdateProductPricing(p.id, editVendorPrice, editMrp, parsedOverride);
                                    setEditingProdId(null);
                                  }}
                                  className="px-2 py-1 bg-emerald-500 hover:bg-emerald-600 text-slate-950 rounded text-[9px] font-extrabold cursor-pointer"
                                >
                                  Save
                                </button>
                                <button
                                  onClick={() => setEditingProdId(null)}
                                  className="px-2 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-[9px] font-extrabold cursor-pointer"
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => {
                                  setEditingProdId(p.id);
                                  setEditMrp(p.mrp || (p.vendorPrice || p.sellingPrice || 0) * 1.5);
                                  setEditVendorPrice(p.vendorPrice || p.sellingPrice || 0);
                                  setEditOverridePrice(p.customerPriceOverride !== undefined ? p.customerPriceOverride.toString() : '');
                                }}
                                className="px-2.5 py-1.5 border border-slate-200 hover:bg-slate-50 rounded text-[10px] text-slate-700 font-bold cursor-pointer"
                              >
                                Edit Pricing
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {activeTab === 'remittances' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Vendor Withdrawals & Remittances</h2>
            
            <div className="space-y-3">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Remittance Queue ({pendingWithdrawalsCount})</h3>
              {withdrawalRequests.filter(r => r.status === 'Pending').length === 0 ? (
                <p className="text-xs text-slate-500 italic bg-white p-4 border rounded-xl">No pending supplier withdrawals filed.</p>
              ) : (
                <div className="space-y-4">
                  {withdrawalRequests.filter(r => r.status === 'Pending').map((r) => (
                    <div key={r.id} className="border border-slate-200 rounded-2xl p-5 bg-white space-y-4 text-xs font-bold">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-slate-900 font-bold">Remittance Request ID: {r.id}</p>
                          <p className="text-xs text-slate-500 mt-0.5">Filed by vendor: <strong>{r.vendorName}</strong></p>
                        </div>
                        <span className="text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider">Pending Release</span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-3 bg-slate-50 rounded-xl font-mono text-slate-600">
                        <p>🏦 Target Bank Name: <span className="font-sans font-bold text-slate-800">{r.bankDetails.bankName}</span></p>
                        <p>🔢 Account Holder: <span className="font-sans font-bold text-slate-800">{r.bankDetails.accountName}</span></p>
                        <p>🔢 Account Number: <span className="font-sans font-bold text-slate-800 text-blue-600">{r.bankDetails.accountNumber}</span></p>
                        <p>🔢 Bank IFSC Code: <span className="font-sans font-bold text-slate-800">{r.bankDetails.ifscCode}</span></p>
                        <p className="md:col-span-2 text-sm text-slate-800 font-sans font-black pt-2 border-t">Remittance Sum: ₹{r.amount.toLocaleString()}</p>
                      </div>

                      {/* Remittance release triggers */}
                      <div className="flex justify-end gap-2">
                        <button
                          onClick={() => onRejectWithdrawal(r.id)}
                          className="px-3 py-1.5 border border-rose-200 text-rose-600 rounded text-xs hover:bg-rose-50"
                        >
                          Reject Remittance
                        </button>
                        <button
                          onClick={() => onMarkWithdrawalPaid(r.id)}
                          className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black rounded text-xs flex items-center gap-1"
                        >
                          ✓ Confirm Bank Transfer & Release
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Processed Withdrawals */}
            <div className="space-y-3">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Historic Released Bank Remittances</h3>
              <div className="border border-slate-200 rounded-xl overflow-hidden divide-y text-xs">
                {withdrawalRequests.filter(r => r.status !== 'Pending').map((r) => (
                  <div key={r.id} className="p-3 bg-white flex justify-between items-center">
                    <div>
                      <p className="font-bold text-slate-900">{r.vendorName} (Ref: {r.id})</p>
                      <p className="text-[10px] text-slate-500">Bank: {r.bankDetails.bankName} • Account: {r.bankDetails.accountNumber}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono font-black text-slate-950">₹{r.amount.toLocaleString()}</p>
                      <span className={`text-[9px] font-bold ${r.status === 'Paid' ? 'text-emerald-600' : 'text-rose-500'}`}>
                        {r.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'coupons' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Coupons & Banners Management</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Active Coupons List */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Live Coupons ({coupons.length})</h3>
                <div className="border border-slate-200 rounded-xl overflow-hidden divide-y text-xs">
                  {coupons.map((c) => (
                    <div key={c.id} className="p-3 bg-white flex justify-between items-center">
                      <div>
                        <p className="font-mono font-bold text-slate-900">{c.code}</p>
                        <p className="text-[10px] text-slate-500">
                          {c.type === 'Percentage' ? `${c.value}% discount` : `₹${c.value} discount`} • Min spend: ₹{c.minPurchase}
                        </p>
                      </div>
                      <button
                        onClick={() => onDeleteCoupon(c.id)}
                        className="text-rose-500 hover:text-rose-700 p-1.5"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Create coupon form */}
              <div className="border p-5 rounded-xl bg-white space-y-4">
                <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest font-mono">Issue Promo Coupon Code</h3>
                <form onSubmit={handleCreateCoupon} className="space-y-3 text-xs font-bold">
                  <div className="space-y-1">
                    <label className="text-slate-600">Coupon Code (Uppercase)</label>
                    <input
                      type="text"
                      placeholder="e.g. CLINIC50"
                      value={newCode}
                      onChange={(e) => setNewCode(e.target.value)}
                      className="w-full p-2 border rounded-lg uppercase"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-slate-600">Discount Formula</label>
                      <select
                        value={newType}
                        onChange={(e) => setNewType(e.target.value as any)}
                        className="w-full p-2 border rounded-lg bg-white font-bold text-slate-800"
                      >
                        <option value="Percentage">Percentage %</option>
                        <option value="Fixed">Fixed Amount (INR)</option>
                      </select>
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-600">Value</label>
                      <input
                        type="number"
                        value={newValue}
                        onChange={(e) => setNewValue(e.target.value)}
                        className="w-full p-2 border rounded-lg"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-slate-600">Minimum Spending Limit (₹)</label>
                    <input
                      type="number"
                      value={newMin}
                      onChange={(e) => setNewMin(e.target.value)}
                      className="w-full p-2 border rounded-lg"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg cursor-pointer"
                  >
                    Issue Coupon Code
                  </button>
                </form>
              </div>

            </div>
          </div>
        )}

        {activeTab === 'payments' && (
          <div className="space-y-6">
            <div className="flex flex-wrap justify-between items-center gap-4">
              <div>
                <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">UPI & Payment Gateway Administration</h2>
                <p className="text-[11px] text-slate-500 font-semibold uppercase mt-0.5">Configure Merchant UPI IDs, Transaction Limits, and Gateway Failover Switches</p>
              </div>
              <span className={`text-[10px] border font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg ${
                upiActive && upiGatewayStatus === 'Operational' 
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                  : 'bg-amber-50 text-amber-800 border-amber-200'
              }`}>
                UPI Gateway: {upiActive ? upiGatewayStatus : 'DISABLED'}
              </span>
            </div>

            {/* UPI quick operational stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 border rounded-xl bg-white space-y-1 shadow-xs">
                <span className="text-[9px] uppercase font-black tracking-wider text-slate-500 block leading-none">UPI Sales Volume</span>
                <span className="text-base font-black text-slate-900 block">
                  ₹{orders.filter(o => o.paymentMethod === 'UPI').reduce((sum, o) => sum + o.total, 0).toLocaleString()}
                </span>
                <span className="text-[9px] text-slate-400 font-bold block">From active UPI orders</span>
              </div>
              <div className="p-4 border rounded-xl bg-white space-y-1 shadow-xs">
                <span className="text-[9px] uppercase font-black tracking-wider text-slate-500 block leading-none">UPI Transactions</span>
                <span className="text-base font-black text-slate-900 block">
                  {orders.filter(o => o.paymentMethod === 'UPI').length} Orders
                </span>
                <span className="text-[9px] text-slate-400 font-bold block">100% routing resolution</span>
              </div>
              <div className="p-4 border rounded-xl bg-white space-y-1 shadow-xs">
                <span className="text-[9px] uppercase font-black tracking-wider text-slate-500 block leading-none">Min / Max Guardrails</span>
                <span className="text-base font-black text-blue-700 block">
                  ₹{upiMinAmount} - ₹{upiMaxAmount.toLocaleString()}
                </span>
                <span className="text-[9px] text-slate-400 font-bold block">Enforced on shopping cart</span>
              </div>
              <div className="p-4 border rounded-xl bg-white space-y-1 shadow-xs">
                <span className="text-[9px] uppercase font-black tracking-wider text-slate-500 block leading-none">VPA Routing ID</span>
                <span className="text-xs font-mono font-bold text-emerald-700 block truncate" title={upiId}>
                  {upiId}
                </span>
                <span className="text-[9px] text-slate-400 font-bold block">Verified on NCPI network</span>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Left Column: Config Panel */}
              <div className="lg:col-span-2 space-y-6">
                <div className="border rounded-xl bg-white p-6 space-y-5 shadow-xs">
                  <div className="border-b border-slate-100 pb-3 flex justify-between items-center">
                    <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest font-mono flex items-center gap-1.5">
                      <Settings className="w-4 h-4 text-slate-700" />
                      <span>Unified Payments Interface (UPI) Settings</span>
                    </h3>
                    <label className="relative inline-flex items-center cursor-pointer select-none">
                      <input 
                        type="checkbox" 
                        checked={upiActive} 
                        onChange={(e) => setUpiActive(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
                      <span className="ml-2 text-[10px] font-black uppercase text-slate-500">Active</span>
                    </label>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-bold text-slate-700">
                    <div className="space-y-1.5">
                      <label className="text-slate-600 uppercase text-[9px] tracking-wider">UPI VPA Address (ID)</label>
                      <input
                        type="text"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                        placeholder="e.g. healnex@okaxis"
                        className="w-full p-2.5 border rounded-lg font-mono focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
                      />
                      <p className="text-[9px] text-slate-400 font-semibold leading-relaxed">Where medical purchase sums are credited instantly on scan verification.</p>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-slate-600 uppercase text-[9px] tracking-wider">Merchant Display Name</label>
                      <input
                        type="text"
                        value={upiMerchantName}
                        onChange={(e) => setUpiMerchantName(e.target.value)}
                        placeholder="e.g. HealNex Medical Systems"
                        className="w-full p-2.5 border rounded-lg focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
                      />
                      <p className="text-[9px] text-slate-400 font-semibold leading-relaxed">This name will be displayed in Google Pay, PhonePe, BHIM, and Paytm apps.</p>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-slate-600 uppercase text-[9px] tracking-wider">Minimum Limit Per Cart Transaction (₹)</label>
                      <input
                        type="number"
                        value={upiMinAmount}
                        onChange={(e) => setUpiMinAmount(Math.max(1, parseInt(e.target.value) || 0))}
                        className="w-full p-2.5 border rounded-lg font-mono focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
                      />
                      <p className="text-[9px] text-slate-400 font-semibold leading-relaxed">Under this amount, UPI payment will be grayed out in checkout.</p>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-slate-600 uppercase text-[9px] tracking-wider">Maximum Limit Per Cart Transaction (₹)</label>
                      <input
                        type="number"
                        value={upiMaxAmount}
                        onChange={(e) => setUpiMaxAmount(Math.max(1, parseInt(e.target.value) || 0))}
                        className="w-full p-2.5 border rounded-lg font-mono focus:ring-1 focus:ring-blue-500 focus:outline-hidden"
                      />
                      <p className="text-[9px] text-slate-400 font-semibold leading-relaxed">Safety cap for B2B clinical equipment purchases. Enforced on cart.</p>
                    </div>

                    <div className="space-y-1.5 md:col-span-2">
                      <label className="text-slate-600 uppercase text-[9px] tracking-wider">Gateway Status & Failover Routine</label>
                      <select
                        value={upiGatewayStatus}
                        onChange={(e) => setUpiGatewayStatus(e.target.value as any)}
                        className="w-full p-2.5 border rounded-lg bg-white focus:ring-1 focus:ring-blue-500 focus:outline-hidden font-bold text-slate-800"
                      >
                        <option value="Operational">🟢 Operational (Standard Real-time Ingress)</option>
                        <option value="Maintenance">🟡 Scheduled Maintenance (Simulate slow validation)</option>
                        <option value="Disabled">🔴 Disabled (Force failover to Razorpay/PayU)</option>
                      </select>
                      <p className="text-[9px] text-slate-400 font-semibold leading-relaxed">In case of NPCI network speed issues, failover routing can redirect customers to card / netbanking options automatically.</p>
                    </div>
                  </div>

                  <div className="bg-slate-50 p-4 border rounded-xl space-y-2 text-xs">
                    <h4 className="font-mono font-black text-slate-800 uppercase tracking-wider flex items-center gap-1">
                      <CheckCircle className="w-4 h-4 text-emerald-500" />
                      <span>Security & NCPI Compliance</span>
                    </h4>
                    <p className="text-slate-500 font-semibold leading-relaxed text-[10px]">
                      The platform enforces 256-bit SSL token encryption on client device handshakes. In addition, transaction reference numbers generated on UPI app callback are stored in our secure auditable ledger database tables.
                    </p>
                  </div>
                </div>

                {/* Historic UPI orders ledger */}
                <div className="border rounded-xl bg-white p-6 space-y-4 shadow-xs text-xs">
                  <h3 className="font-mono font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5">
                    <IndianRupee className="w-4 h-4 text-emerald-500" />
                    <span>Live UPI Order Ledger</span>
                  </h3>
                  
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-100 text-[9px] uppercase font-black text-slate-400 tracking-wider">
                          <th className="py-2">Order ID</th>
                          <th className="py-2">Customer & Details</th>
                          <th className="py-2">Amount Paid</th>
                          <th className="py-2 text-center">Payment Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50 font-semibold">
                        {orders.filter(o => o.paymentMethod === 'UPI').map((o) => (
                          <tr key={o.id} className="hover:bg-slate-50 transition-colors">
                            <td className="py-3 font-mono font-bold text-slate-900">{o.id}</td>
                            <td className="py-3">
                              <span className="block text-slate-800 font-bold">{o.billingDetails?.name || 'Clinic Procure'}</span>
                              <span className="text-[9px] text-slate-400 block font-sans font-semibold mt-0.5">{o.createdAt} • {o.items.length} Medical Devices</span>
                            </td>
                            <td className="py-3 font-mono text-slate-900 font-bold">₹{o.total.toLocaleString()}</td>
                            <td className="py-3 text-center">
                              <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                                o.paymentStatus === 'Paid' 
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                  : 'bg-amber-50 text-amber-700 border border-amber-200'
                              }`}>
                                {o.paymentStatus}
                              </span>
                            </td>
                          </tr>
                        ))}
                        {orders.filter(o => o.paymentMethod === 'UPI').length === 0 && (
                          <tr>
                            <td colSpan={4} className="text-center py-6 text-slate-400 italic">No orders registered via UPI yet.</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Right Column: Live Mock Visualizer */}
              <div className="space-y-6">
                <div className="border rounded-xl bg-slate-900 p-5 text-slate-100 space-y-4 shadow-lg relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 rounded-full blur-xl"></div>
                  <div className="absolute bottom-0 left-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl"></div>

                  <h3 className="text-xs font-black uppercase tracking-widest font-mono text-white flex items-center gap-1.5 border-b border-slate-800 pb-3">
                    <QrCode className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>Checkout UPI Placard Preview</span>
                  </h3>

                  <p className="text-[10px] text-slate-400 leading-relaxed font-semibold">
                    This shows exactly how the dynamic QR code is assembled and presented on the customer's viewport at payment selection.
                  </p>

                  {/* QR Placard Simulation */}
                  <div className="bg-white text-slate-900 p-4 rounded-xl border border-slate-800 space-y-4 max-w-[260px] mx-auto shadow-inner">
                    <div className="flex justify-between items-center text-[10px] font-mono font-bold text-slate-500 border-b border-slate-100 pb-2">
                      <span>HEALNEX UPI PAY</span>
                      <span className="text-blue-600 font-sans font-black uppercase">NPCI SECURE</span>
                    </div>

                    <div className="bg-slate-50 border p-3 rounded-lg flex flex-col items-center justify-center space-y-2">
                      {/* Dynamic google chart or qrserver simulation URL */}
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(
                          `upi://pay?pa=${upiId}&pn=${encodeURIComponent(upiMerchantName)}&am=1000&cu=INR`
                        )}`}
                        alt="UPI QR Code" 
                        className="w-36 h-36 border-2 border-slate-200 rounded p-1 bg-white"
                        referrerPolicy="no-referrer"
                      />
                      <span className="text-[8px] font-mono text-slate-400 font-bold break-all max-w-[160px] text-center">
                        upi://pay?pa={upiId}&pn=...
                      </span>
                    </div>

                    <div className="text-center space-y-1">
                      <p className="text-[9px] text-slate-400 font-black uppercase">MERCHANT NAME</p>
                      <p className="text-xs font-black text-slate-900 truncate">{upiMerchantName || 'HealNex Medical Systems'}</p>
                      
                      <p className="text-[9px] text-slate-400 font-black uppercase pt-1">PAY TO (VPA ID)</p>
                      <p className="text-[10px] font-mono font-bold text-blue-600 truncate">{upiId || 'healnex@okaxis'}</p>
                    </div>

                    <div className="bg-emerald-50 border border-emerald-100 p-2 rounded text-center text-[9px] font-bold text-emerald-800">
                      🔒 Secured with Bhim, GPay, Paytm protocols
                    </div>
                  </div>

                  <div className="space-y-2 text-[10px] text-slate-400 leading-relaxed font-semibold">
                    <p className="text-white font-mono text-xs font-black border-b border-slate-800 pb-1">Dynamic URI Construction Formula:</p>
                    <p className="font-mono text-[9px] text-blue-400 bg-slate-950/70 p-2 rounded border border-slate-800/80 break-all select-all">
                      {`upi://pay?pa=${upiId}&pn=${encodeURIComponent(upiMerchantName)}&am={amount}&cu=INR`}
                    </p>
                    <p className="text-[9px] text-slate-500">
                      During checkout, HealNex evaluates the shopping cart total, inserts it dynamically into this URI schema, and generates a clean raster-vector QR code instantly using secure image protocols.
                    </p>
                  </div>
                </div>

                <div className="border p-5 rounded-xl bg-white space-y-3 text-xs">
                  <h4 className="font-mono font-black text-slate-900 uppercase tracking-wider">Gateway Fallback Logic</h4>
                  <div className="space-y-2 font-semibold text-slate-600">
                    <p className="leading-relaxed text-[11px]">
                      If the customer cart total is less than <strong>₹{upiMinAmount}</strong> or exceeds <strong>₹{upiMaxAmount.toLocaleString()}</strong>, UPI gateway is auto-disabled and fallback gateways process card details securely.
                    </p>
                    <div className="border-t pt-2 mt-2 space-y-1 text-[10px] font-bold">
                      <div className="flex justify-between text-slate-500">
                        <span>Min Transaction Guard</span>
                        <span className="text-slate-900">₹{upiMinAmount}</span>
                      </div>
                      <div className="flex justify-between text-slate-500">
                        <span>Max Transaction Guard</span>
                        <span className="text-slate-900">₹{upiMaxAmount.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {activeTab === 'reviews' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Product Reviews & Client Tickets</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Auditing reviews queue */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Awaiting Review Approval ({reviews.filter(r => !r.approved).length})</h3>
                {reviews.filter(r => !r.approved).length === 0 ? (
                  <p className="text-xs text-slate-500 italic bg-white p-4 border rounded-xl">No pending reviews submitted.</p>
                ) : (
                  <div className="space-y-3">
                    {reviews.filter(r => !r.approved).map((r) => (
                      <div key={r.id} className="border rounded-xl p-4 bg-white space-y-3 text-xs">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-bold text-slate-900">{r.customerName}</p>
                            <p className="text-[10px] text-slate-500">Device: {r.productName} • Rating: {'★'.repeat(r.rating)}</p>
                          </div>
                          <span className="bg-amber-50 text-amber-800 text-[8px] px-1.5 py-0.5 rounded uppercase font-bold">Queued</span>
                        </div>
                        <p className="text-slate-600 italic">"{r.comment}"</p>
                        <div className="flex gap-2 justify-end">
                          <button
                            onClick={() => onRejectReview(r.id)}
                            className="px-2.5 py-1 border border-rose-200 text-rose-600 text-[10px] font-bold rounded"
                          >
                            Reject
                          </button>
                          <button
                            onClick={() => onApproveReview(r.id)}
                            className="px-3 py-1 bg-emerald-500 text-slate-950 text-[10px] font-black rounded hover:bg-emerald-600"
                          >
                            Approve
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Approved Reviews */}
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider pt-4">Approved Product Reviews Directory</h3>
                <div className="border border-slate-200 rounded-xl overflow-hidden divide-y text-xs">
                  {reviews.filter(r => r.approved).map((r) => (
                    <div key={r.id} className="p-3 bg-white flex justify-between gap-3">
                      <div>
                        <p className="font-bold text-slate-900">{r.customerName} (Device: {r.productName})</p>
                        <p className="text-slate-500 italic mt-0.5">"{r.comment}"</p>
                      </div>
                      <span className="text-amber-500 shrink-0">{'★'.repeat(r.rating)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Support Tickets Console */}
              <div className="space-y-3">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-wider">Active Support Tickets ({supportTickets.length})</h3>
                <div className="space-y-3">
                  {supportTickets.map((t) => (
                    <div key={t.id} className="border rounded-xl p-4 bg-white space-y-3 text-xs font-bold">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-slate-950">Subject: {t.subject}</p>
                          <p className="text-[10px] text-slate-500">From: {t.userName} ({t.userRole})</p>
                        </div>
                        <span className={`px-2 py-0.5 rounded text-[10px] ${
                          t.status === 'Open' ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-500'
                        }`}>
                          {t.status}
                        </span>
                      </div>

                      {/* Chat messages */}
                      <div className="space-y-2 bg-slate-50 p-2.5 rounded-lg max-h-32 overflow-y-auto">
                        {t.messages.map((m, i) => (
                          <div key={i} className={`p-1.5 rounded text-[10px] leading-relaxed ${m.sender === 'Admin' ? 'bg-blue-50 text-blue-800 ml-4' : 'bg-slate-200 text-slate-800 mr-4'}`}>
                            <p className="font-black">{m.sender}:</p>
                            <p className="font-medium mt-0.5">{m.text}</p>
                          </div>
                        ))}
                      </div>

                      {t.status !== 'Closed' && (
                        <div className="space-y-2">
                          <textarea
                            placeholder="Type admin response..."
                            value={activeTicketId === t.id ? adminReplyText : ''}
                            onChange={(e) => {
                              setActiveTicketId(t.id);
                              setAdminReplyText(e.target.value);
                            }}
                            rows={2}
                            className="w-full p-2 border rounded-lg text-xs font-medium"
                          />
                          <div className="flex justify-between">
                            <button
                              onClick={() => onCloseTicket(t.id)}
                              className="px-2 py-1 text-slate-500 border rounded text-[10px]"
                            >
                              Close Ticket
                            </button>
                            <button
                              onClick={() => {
                                if (activeTicketId === t.id && adminReplyText) {
                                  onReplyTicket(t.id, adminReplyText);
                                  setAdminReplyText('');
                                  setActiveTicketId(null);
                                }
                              }}
                              className="px-3 py-1 bg-blue-600 text-white rounded text-[10px] hover:bg-blue-700"
                            >
                              Send Reply
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        )}

        {activeTab === 'cms' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">CMS Core Pages Policy Editor</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-bold">
              {/* Selector */}
              <div className="flex flex-col gap-1 md:col-span-1">
                {cmsPages.map(page => (
                  <button
                    key={page.slug}
                    onClick={() => loadCmsContent(page.slug)}
                    className={`text-left p-2.5 rounded-lg border transition-all ${
                      activeCmsSlug === page.slug 
                        ? 'bg-blue-600 text-white border-blue-600' 
                        : 'bg-white text-slate-700 border-slate-150 hover:bg-slate-50'
                    }`}
                  >
                    {page.title}
                  </button>
                ))}
              </div>

              {/* Editor */}
              <div className="md:col-span-3 border p-5 rounded-xl bg-white space-y-4">
                <div className="flex justify-between items-center border-b pb-2">
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest font-mono">
                    Edit Content: {cmsPages.find(p => p.slug === activeCmsSlug)?.title}
                  </h3>
                  <button
                    onClick={() => handleSaveCMS(activeCmsSlug)}
                    className="px-4 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-xs font-bold cursor-pointer"
                  >
                    Save CMS Page
                  </button>
                </div>
                <textarea
                  value={cmsEditContent}
                  onChange={(e) => setCmsEditContent(e.target.value)}
                  rows={12}
                  className="w-full p-3 border rounded-xl font-mono text-xs text-slate-800 leading-relaxed focus:outline-hidden"
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'notifications' && (
          <div className="space-y-6">
            <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Mass Notification Broadcaster</h2>
            
            {notifSuccess && (
              <div className="p-3 bg-emerald-50 text-emerald-800 rounded-lg text-xs font-bold">
                ✓ Mass notification dispatched successfully across selected channels!
              </div>
            )}

            <form onSubmit={handleSendNotificationSubmit} className="max-w-xl border p-5 rounded-xl bg-white space-y-4 text-xs font-bold">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-600">Target Audiences</label>
                  <select
                    value={notifTarget}
                    onChange={(e) => setNotifTarget(e.target.value)}
                    className="w-full p-2 border rounded bg-white text-slate-800"
                  >
                    <option value="all">All Registered Accounts</option>
                    <option value="vendors">Verified Vendors Only</option>
                    <option value="customers">Hospital Procurement Representatives</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-slate-600">Secure Dispatch Channel</label>
                  <select
                    value={notifType}
                    onChange={(e) => setNotifType(e.target.value as any)}
                    className="w-full p-2 border rounded bg-white text-slate-800"
                  >
                    <option value="Email">Email SMTP Broadcast</option>
                    <option value="SMS">SMS Gateway Protocol</option>
                    <option value="WhatsApp">WhatsApp Business API</option>
                    <option value="Push">App Push Notification</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-600">Broadcast Title Header</label>
                <input
                  type="text"
                  placeholder="e.g. Critical Safety Alert - Digital ICU Vent System"
                  value={notifTitle}
                  onChange={(e) => setNotifTitle(e.target.value)}
                  className="w-full p-2.5 border rounded-lg focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-600">Message Body Content</label>
                <textarea
                  placeholder="Enter full broadcast text detailing specifications..."
                  value={notifMessage}
                  onChange={(e) => setNotifMessage(e.target.value)}
                  rows={4}
                  className="w-full p-2.5 border rounded-lg font-medium focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-slate-900 text-white font-bold rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Dispatch Secure Broadcast
              </button>
            </form>
          </div>
        )}

        {activeTab === 'security' && (
          <div className="space-y-6">
            <div className="flex flex-wrap justify-between items-center gap-4">
              <div>
                <h2 className="text-lg font-black text-slate-900 uppercase tracking-wider">Enterprise Security Operations Console</h2>
                <p className="text-[11px] text-slate-500 font-semibold uppercase mt-0.5">Real-time threat mitigation, network access control, and auditing logs</p>
              </div>
              <span className="text-[10px] bg-blue-900 text-blue-100 border border-blue-800 font-mono font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg">WAF ACTIVE</span>
            </div>

            {/* SOC Threat stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Brute-Force Interventions', count: '14 Attempts Blocked', bg: 'bg-emerald-50 text-emerald-800 border-emerald-200' },
                { label: 'SQL Injection Stripped', count: '4 Payloads Blocked', bg: 'bg-blue-50 text-blue-800 border-blue-200' },
                { label: 'HSTS Transport Bindings', count: '100% Endpoints Secure', bg: 'bg-indigo-50 text-indigo-800 border-indigo-200' },
                { label: 'Active Blocked IP Ranges', count: `${blockedIps.length} Subnets Sealed`, bg: 'bg-rose-50 text-rose-800 border-rose-200' }
              ].map((stat, i) => (
                <div key={i} className={`p-4 border rounded-xl space-y-1 ${stat.bg}`}>
                  <span className="text-[9px] uppercase font-black tracking-wider opacity-80 block leading-none">{stat.label}</span>
                  <span className="text-xs font-black block">{stat.count}</span>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              
              {/* Column 1: Live Logs & Ledger Audits */}
              <div className="lg:col-span-2 space-y-4">
                <div className="border rounded-xl bg-white p-5 space-y-4">
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest font-mono flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-emerald-500" />
                    <span>Cryptographic Audit Ledger Ledger</span>
                  </h3>
                  
                  <div className="overflow-x-auto text-[11px] font-medium text-slate-700">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-100 text-[10px] uppercase font-black tracking-wider text-slate-400">
                          <th className="py-2.5">Timestamp</th>
                          <th className="py-2.5">Actor (User)</th>
                          <th className="py-2.5">Security Action Details</th>
                          <th className="py-2.5 text-center">Audit Source IP</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-55">
                        {activityLogs.map((log) => (
                          <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                            <td className="py-3 font-mono text-slate-400 font-semibold">{log.timestamp}</td>
                            <td className="py-3">
                              <span className="font-bold text-slate-900 block">{log.user}</span>
                              <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded font-black uppercase font-mono tracking-wider">
                                {log.role || 'Guest'}
                              </span>
                            </td>
                            <td className="py-3 text-slate-600 font-sans pr-2">{log.action}</td>
                            <td className="py-3 font-mono text-center text-slate-500">
                              <span className="block">{log.ipAddress || '157.34.120.91'}</span>
                              <span className="text-[8px] text-slate-400 font-bold block truncate max-w-[100px]" title={log.device || 'Chrome/macOS'}>
                                {log.device || 'Chrome/macOS'}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    
                    {activityLogs.length === 0 && (
                      <p className="text-center py-6 text-slate-400 italic">No activity entries registered in ledger.</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Column 2: Firewall & IP Control Panel */}
              <div className="space-y-4">
                
                {/* IP Access Control panel */}
                <div className="border rounded-xl bg-white p-5 space-y-4">
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest font-mono flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 text-rose-500" />
                    <span>Firewall IP Blocking</span>
                  </h3>
                  
                  <p className="text-[10px] text-slate-500 font-semibold leading-relaxed">
                    Instantly seal connections from suspicious gateways, bad actors, or unauthorized subnets. Sealed IPs cannot bypass catalog routes.
                  </p>

                  <div className="space-y-3">
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        placeholder="e.g. 198.51.100.24"
                        value={newBlockedIp}
                        onChange={(e) => setNewBlockedIp(e.target.value)}
                        className="flex-1 p-2 border rounded-lg text-xs font-mono focus:outline-hidden"
                      />
                      <button
                        onClick={() => {
                          if (!newBlockedIp) return;
                          setBlockedIps([...blockedIps, newBlockedIp]);
                          setNewBlockedIp('');
                          alert(`✓ Subnet/IP gateway successfully locked: ${newBlockedIp}`);
                        }}
                        className="px-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold cursor-pointer"
                      >
                        Block IP
                      </button>
                    </div>

                    <div className="divide-y divide-slate-100 text-xs">
                      {blockedIps.map((ip, i) => (
                        <div key={i} className="py-2.5 first:pt-0 last:pb-0 flex justify-between items-center">
                          <span className="font-mono font-bold text-slate-800">{ip}</span>
                          <button
                            onClick={() => {
                              setBlockedIps(blockedIps.filter(item => item !== ip));
                              alert(`✓ Unsealed Gateway traffic for: ${ip}`);
                            }}
                            className="text-[10px] text-rose-600 hover:underline font-bold"
                          >
                            Unseal Gateway
                          </button>
                        </div>
                      ))}
                      
                      {blockedIps.length === 0 && (
                        <p className="text-slate-400 italic text-[11px] text-center py-4">No IP gateways locked. Ingress traffic clean.</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Password / 2FA status indicators */}
                <div className="border rounded-xl bg-white p-5 space-y-3 text-xs">
                  <h4 className="font-black text-slate-900 uppercase tracking-wider font-mono">Authentication Controls</h4>
                  
                  <div className="space-y-2 font-semibold">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-600">Multi-Factor Authenticator (MFA)</span>
                      <span className="text-[9px] bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded font-black uppercase">Active (RFC 6238)</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-600">Password Policy Enforcement</span>
                      <span className="text-[9px] bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded font-black uppercase">Active (12+ Char)</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-600">Anti-Brute Force Account Lockout</span>
                      <span className="text-[9px] bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded font-black uppercase">Active (3 Limits)</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-slate-600">Audit Source Telemetry Tracking</span>
                      <span className="text-[9px] bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded font-black uppercase">Active (IP/Device)</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          </div>
        )}

      </div>

    </div>
  );
}
