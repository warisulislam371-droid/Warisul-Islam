import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ShoppingBag, 
  Heart, 
  Star, 
  ArrowLeftRight, 
  Check, 
  ShieldCheck, 
  Plus, 
  Minus, 
  Trash2, 
  ChevronRight, 
  FileText, 
  AlertCircle, 
  Clock, 
  CreditCard, 
  CheckCircle2, 
  ArrowLeft, 
  Share2, 
  Percent, 
  Eye 
} from 'lucide-react';
import { Product, Vendor, Coupon, CMSPage, Order } from '../types';
import { CATEGORIES } from '../data/mockData';

interface HomeViewProps {
  products: Product[];
  vendors: Vendor[];
  coupons: Coupon[];
  cmsPages: CMSPage[];
  cart: { product: Product; quantity: number }[];
  wishlist: string[]; // product IDs
  compareList: Product[];
  onAddToCart: (p: Product) => void;
  onRemoveFromCart: (pId: string) => void;
  onUpdateCartQty: (pId: string, q: number) => void;
  onToggleWishlist: (p: Product) => void;
  onToggleCompare: (p: Product) => void;
  onPlaceOrder: (billingDetails: any, paymentMethod: string, couponCode: string) => Order;
  activeCategory: string;
  setActiveCategory: (catId: string) => void;
  searchTerm: string;
  activeCmsPage: string | null;
  setActiveCmsPage: (slug: string | null) => void;
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  wishlistOpen: boolean;
  setWishlistOpen: (open: boolean) => void;
  compareOpen: boolean;
  setCompareOpen: (open: boolean) => void;
  
  upiId: string;
  upiMerchantName: string;
  upiActive: boolean;
  upiMinAmount: number;
  upiMaxAmount: number;
  upiGatewayStatus: 'Operational' | 'Maintenance' | 'Disabled';
}

export default function HomeView({
  products,
  vendors,
  coupons,
  cmsPages,
  cart,
  wishlist,
  compareList,
  onAddToCart,
  onRemoveFromCart,
  onUpdateCartQty,
  onToggleWishlist,
  onToggleCompare,
  onPlaceOrder,
  activeCategory,
  setActiveCategory,
  searchTerm,
  activeCmsPage,
  setActiveCmsPage,
  cartOpen,
  setCartOpen,
  wishlistOpen,
  setWishlistOpen,
  compareOpen,
  setCompareOpen,
  upiId,
  upiMerchantName,
  upiActive,
  upiMinAmount,
  upiMaxAmount,
  upiGatewayStatus
}: HomeViewProps) {
  // States
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeBannerIdx, setActiveBannerIdx] = useState(0);
  const [selectedVendorStore, setSelectedVendorStore] = useState<Vendor | null>(null);
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'billing' | 'payment' | 'success'>('cart');
  const [couponCodeInput, setCouponCodeInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');

  // Checkout inputs
  const [billingName, setBillingName] = useState('Karan Mehra');
  const [billingMobile, setBillingMobile] = useState('+91 99887 22110');
  const [billingEmail, setBillingEmail] = useState('karan@outlook.com');
  const [billingAddress, setBillingAddress] = useState('Apt 4B, Skyview Towers, Koramangala');
  const [billingState, setBillingState] = useState('Karnataka');
  const [billingCity, setBillingCity] = useState('Bengaluru');
  const [billingPin, setBillingPin] = useState('560034');
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  
  // UPI client payment states
  const [upiUtr, setUpiUtr] = useState('');
  const [upiUtrError, setUtrError] = useState('');
  const [upiUtrChecking, setUpiUtrChecking] = useState(false);
  const [upiUtrVerified, setUpiUtrVerified] = useState(false);

  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);

  // Banners array
  const banners = [
    {
      id: 'b-1',
      title: "India's Trusted Medical Multi-Vendor Marketplace",
      subtitle: "Buy Medical Equipment, Healthcare Products, Diagnostic Devices, Hospital Supplies, and More with Global Quality Guarantees.",
      image: "https://images.unsplash.com/photo-1538108176447-280586497d96?auto=format&fit=crop&q=80&w=1200",
      cta: "Explore Equipments"
    },
    {
      id: 'b-2',
      title: "Admin-Verified Trade Licenses & Instant Commission Splits",
      subtitle: "All suppliers undergo a thorough double-verification standard to safeguard hospital procurement chains.",
      image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&q=80&w=1200",
      cta: "Become a Vendor"
    }
  ];

  // Filtering products
  const approvedProducts = products.filter(p => p.approved);
  const filteredProducts = approvedProducts.filter(p => {
    const matchesCategory = activeCategory === 'all' || p.category === CATEGORIES.find(c => c.id === activeCategory)?.name;
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesVendor = selectedVendorStore ? p.vendorId === selectedVendorStore.id : true;
    return matchesCategory && matchesSearch && matchesVendor;
  });

  // Calculate cart cost
  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.customerPrice * item.quantity, 0);
  const discountAmount = appliedCoupon 
    ? (appliedCoupon.type === 'Percentage' ? (cartSubtotal * appliedCoupon.value) / 100 : appliedCoupon.value) 
    : 0;
  const cartTotal = Math.max(0, cartSubtotal - discountAmount);

  const handleApplyCoupon = () => {
    setCouponError('');
    const code = couponCodeInput.trim().toUpperCase();
    const found = coupons.find(c => c.code === code && c.active);
    if (!found) {
      setCouponError('Invalid or expired coupon code.');
      setAppliedCoupon(null);
      return;
    }
    if (cartSubtotal < found.minPurchase) {
      setCouponError(`Minimum purchase of ₹${found.minPurchase} required.`);
      setAppliedCoupon(null);
      return;
    }
    setAppliedCoupon(found);
  };

  const submitCheckout = () => {
    if (!billingName || !billingMobile || !billingEmail || !billingAddress || !billingPin) {
      alert('Please fill out all mandatory billing fields.');
      return;
    }

    const isUpiAllowed = upiActive && upiGatewayStatus !== 'Disabled' && cartTotal >= upiMinAmount && cartTotal <= upiMaxAmount;
    if (paymentMethod === 'UPI') {
      if (!isUpiAllowed) {
        alert('⚠️ UPI payment is currently not available for this transaction. Please choose another payment method.');
        return;
      }
      if (!upiUtrVerified) {
        alert('⚠️ Payment Pending Verification: Please scan the UPI QR code and click "Verify & Secure Payment" using a valid 12-digit UTR reference code to proceed.');
        return;
      }
    }

    const billingDetails = {
      name: billingName,
      mobile: billingMobile,
      email: billingEmail,
      address: billingAddress,
      state: billingState,
      city: billingCity,
      pinCode: billingPin
    };

    const order = onPlaceOrder(billingDetails, paymentMethod, appliedCoupon?.code || '');
    setLastPlacedOrder(order);
    setCheckoutStep('success');
    setAppliedCoupon(null);
    setCouponCodeInput('');
    setUpiUtr('');
    setUpiUtrVerified(false);
  };

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Top Slider Hero Banner */}
      {!selectedVendorStore && !activeCmsPage && checkoutStep === 'cart' && (
        <div className="bg-slate-950 text-white relative overflow-hidden border-b border-slate-800">
          <div className="max-w-7xl mx-auto px-6 py-12 lg:py-20 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            
            <motion.div 
              key={activeBannerIdx}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-5"
            >
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 text-emerald-400 text-[10px] font-mono uppercase tracking-wider border border-slate-700">
                <ShieldCheck className="w-3 h-3" />
                100% Verified Clinical Supply Chains
              </span>
              <h1 className="text-2xl sm:text-3xl lg:text-5xl font-bold tracking-tight leading-tight font-display">
                {banners[activeBannerIdx].title}
              </h1>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed font-sans max-w-lg">
                {banners[activeBannerIdx].subtitle}
              </p>
              <div className="flex flex-wrap gap-3 pt-1">
                <button 
                  onClick={() => setActiveCategory('all')}
                  className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-bold text-xs rounded-lg transition-all cursor-pointer"
                >
                  Shop Now
                </button>
                <button 
                  onClick={() => {
                    const btn = document.getElementById('header-become-vendor-btn');
                    if (btn) btn.click();
                  }}
                  className="px-5 py-2.5 bg-slate-900 hover:bg-slate-850 text-white font-medium text-xs rounded-lg transition-all border border-slate-800 cursor-pointer"
                >
                  Become a Vendor
                </button>
              </div>
            </motion.div>

            {/* Visual preview */}
            <div className="relative flex justify-center lg:justify-end">
              <div className="w-full max-w-md h-64 lg:h-80 rounded-lg overflow-hidden border border-slate-800 relative shadow-sm">
                <img 
                  src={banners[activeBannerIdx].image} 
                  alt="Medical Hardware"
                  className="w-full h-full object-cover grayscale opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>
                <div className="absolute bottom-4 right-4 flex gap-1.5">
                  {banners.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveBannerIdx(i)}
                      className={`w-2 h-2 rounded-full transition-all ${
                        activeBannerIdx === i ? 'bg-emerald-400 w-5' : 'bg-white/35'
                      }`}
                    ></button>
                  ))}
                </div>
              </div>
            </div>
          </div>
          {/* Decorative shapes */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl -z-0"></div>
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-slate-500/5 rounded-full blur-3xl -z-0"></div>
        </div>
      )}

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 lg:px-6 py-8">
        
        {/* Render CMS Pages if active */}
        {activeCmsPage ? (
          <div className="bg-white rounded-2xl p-6 lg:p-10 border border-slate-200 shadow-xs max-w-4xl mx-auto">
            <button
              onClick={() => setActiveCmsPage(null)}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-800 mb-6 cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> Back to Storefront
            </button>
            {cmsPages.filter(p => p.slug === activeCmsPage).map(page => (
              <div key={page.slug} className="space-y-4">
                <h2 className="text-3xl font-extrabold text-slate-900 border-b border-slate-100 pb-4">
                  {page.title}
                </h2>
                <p className="text-slate-600 leading-relaxed whitespace-pre-wrap font-sans text-sm lg:text-base">
                  {page.content}
                </p>
              </div>
            ))}
          </div>
        ) : checkoutStep === 'billing' || checkoutStep === 'payment' ? (
          /* Step-by-step checkout workspace */
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left 2 columns - forms */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Back navigation */}
              <button
                onClick={() => setCheckoutStep(checkoutStep === 'payment' ? 'billing' : 'cart')}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-800 cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" /> Back to {checkoutStep === 'payment' ? 'Billing Info' : 'Shopping Cart'}
              </button>

              {/* Steps Indicator */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 flex justify-between items-center text-xs font-bold">
                <div className="flex items-center gap-1.5 text-emerald-600">
                  <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">1</span>
                  <span>Review Cart</span>
                </div>
                <div className="h-px bg-slate-200 flex-1 mx-4"></div>
                <div className={`flex items-center gap-1.5 ${checkoutStep === 'billing' || checkoutStep === 'payment' ? 'text-blue-600' : 'text-slate-400'}`}>
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center ${checkoutStep === 'billing' || checkoutStep === 'payment' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'}`}>2</span>
                  <span>Billing Details</span>
                </div>
                <div className="h-px bg-slate-200 flex-1 mx-4"></div>
                <div className={`flex items-center gap-1.5 ${checkoutStep === 'payment' ? 'text-blue-600' : 'text-slate-400'}`}>
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center ${checkoutStep === 'payment' ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'}`}>3</span>
                  <span>Secure Payment</span>
                </div>
              </div>

              {checkoutStep === 'billing' && (
                <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
                  <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
                    Hospital/Client Billing Information
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-bold">
                    <div className="space-y-1">
                      <label className="text-slate-600">Client / Hospital Name <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={billingName}
                        onChange={(e) => setBillingName(e.target.value)}
                        className="w-full p-2.5 rounded-lg border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-blue-500"
                        placeholder="Enter full name"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-600">Contact Number <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={billingMobile}
                        onChange={(e) => setBillingMobile(e.target.value)}
                        className="w-full p-2.5 rounded-lg border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-blue-500"
                        placeholder="+91 xxxxx xxxxx"
                      />
                    </div>
                    <div className="space-y-1 md:col-span-2">
                      <label className="text-slate-600">Email Address <span className="text-red-500">*</span></label>
                      <input
                        type="email"
                        value={billingEmail}
                        onChange={(e) => setBillingEmail(e.target.value)}
                        className="w-full p-2.5 rounded-lg border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-blue-500"
                        placeholder="procurement@hospital.com"
                      />
                    </div>
                    <div className="space-y-1 md:col-span-2">
                      <label className="text-slate-600">Shipping & Billing Address <span className="text-red-500">*</span></label>
                      <textarea
                        value={billingAddress}
                        onChange={(e) => setBillingAddress(e.target.value)}
                        rows={3}
                        className="w-full p-2.5 rounded-lg border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-blue-500"
                        placeholder="Hospital Block, Street Name, Landmark..."
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-600">City <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={billingCity}
                        onChange={(e) => setBillingCity(e.target.value)}
                        className="w-full p-2.5 rounded-lg border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-blue-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-600">State <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={billingState}
                        onChange={(e) => setBillingState(e.target.value)}
                        className="w-full p-2.5 rounded-lg border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-blue-500"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-slate-600">PIN Code <span className="text-red-500">*</span></label>
                      <input
                        type="text"
                        value={billingPin}
                        onChange={(e) => setBillingPin(e.target.value)}
                        className="w-full p-2.5 rounded-lg border border-slate-200 text-xs font-medium focus:outline-hidden focus:border-blue-500"
                      />
                    </div>
                  </div>
                  <div className="pt-4">
                    <button
                      onClick={() => setCheckoutStep('payment')}
                      className="w-full py-3 bg-blue-600 text-white font-bold text-sm rounded-xl shadow-md hover:bg-blue-700 transition-colors cursor-pointer"
                    >
                      Proceed to Payment Selection
                    </button>
                  </div>
                </div>
              )}

              {checkoutStep === 'payment' && (() => {
                const isUpiAllowed = upiActive && upiGatewayStatus !== 'Disabled' && cartTotal >= upiMinAmount && cartTotal <= upiMaxAmount;
                return (
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
                    <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
                      Choose Your Secure Medical Payment Gateway
                    </h3>
                    
                    {/* Gateway selector */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {[
                        { id: 'UPI', label: 'UPI / Google Pay / PhonePe', desc: 'Instant dispatch verification' },
                        { id: 'Razorpay', label: 'Razorpay Secure Checkout', desc: 'Cards, Netbanking & Wallets' },
                        { id: 'PayU', label: 'PayU Medical Gateway', desc: 'Specialized hospital banking' },
                        { id: 'Stripe', label: 'Stripe International Card processing', desc: 'Secure debit/credit card protocols' },
                        { id: 'COD', label: 'Cash on Delivery (COD)', desc: 'Verification OTP on delivery' }
                      ].map((g) => {
                        const isUPI = g.id === 'UPI';
                        const isOptionAllowed = isUPI ? isUpiAllowed : true;
                        
                        // Formulate disable reasoning badge
                        let badgeText = '';
                        if (isUPI) {
                          if (!upiActive || upiGatewayStatus === 'Disabled') {
                            badgeText = 'OFFLINE';
                          } else if (cartTotal < upiMinAmount) {
                            badgeText = `MIN ₹${upiMinAmount} REQUIRED`;
                          } else if (cartTotal > upiMaxAmount) {
                            badgeText = `MAX ₹${upiMaxAmount.toLocaleString()} EXCEEDED`;
                          }
                        }

                        return (
                          <div
                            key={g.id}
                            onClick={() => {
                              if (isOptionAllowed) {
                                setPaymentMethod(g.id);
                              } else {
                                alert(`⚠️ This payment gateway is currently unavailable for this transaction: ${badgeText}`);
                              }
                            }}
                            className={`p-3.5 border rounded-xl transition-all flex items-start gap-3 relative ${
                              !isOptionAllowed 
                                ? 'opacity-50 bg-slate-50 border-slate-200 cursor-not-allowed' 
                                : paymentMethod === g.id 
                                  ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-100 cursor-pointer' 
                                  : 'border-slate-200 hover:bg-slate-50 cursor-pointer'
                            }`}
                          >
                            <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                              !isOptionAllowed 
                                ? 'border-slate-300 bg-slate-100' 
                                : paymentMethod === g.id 
                                  ? 'border-blue-600 bg-blue-600' 
                                  : 'border-slate-300'
                            }`}>
                              {paymentMethod === g.id && isOptionAllowed && <span className="w-1.5 h-1.5 rounded-full bg-white"></span>}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-1.5">
                                <p className="text-xs font-bold text-slate-900">{g.label}</p>
                                {badgeText && (
                                  <span className="shrink-0 text-[8px] font-black bg-rose-50 text-rose-600 px-1.5 py-0.5 rounded border border-rose-100">
                                    {badgeText}
                                  </span>
                                )}
                              </div>
                              <p className="text-[10px] text-slate-500 font-medium mt-0.5">{g.desc}</p>
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Interactive UPI QR verification placard */}
                    {paymentMethod === 'UPI' && isUpiAllowed && (
                      <div className="border border-slate-200 rounded-xl p-4 bg-slate-50 space-y-4 animate-in fade-in slide-in-from-top-1 duration-200 text-xs">
                        <div className="flex items-center justify-between border-b pb-2">
                          <div className="flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-mono text-[8px] font-bold uppercase">UPI RECONCILIATION</span>
                            <h4 className="text-xs font-black uppercase text-slate-800">Direct QR Transfer Sandbox</h4>
                          </div>
                          {upiGatewayStatus === 'Maintenance' && (
                            <span className="text-[8px] font-black bg-amber-100 text-amber-800 border border-amber-200 px-1.5 py-0.5 rounded animate-pulse">NETWORK LATENCY ACTIVE</span>
                          )}
                        </div>

                        <div className="flex flex-col sm:flex-row gap-4 items-center">
                          <div className="bg-white p-2.5 rounded-lg border flex flex-col items-center justify-center shrink-0 shadow-xs">
                            <img 
                              src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(
                                `upi://pay?pa=${upiId}&pn=${encodeURIComponent(upiMerchantName)}&am=${cartTotal}&cu=INR`
                              )}`}
                              alt="UPI QR Code" 
                              className="w-28 h-28 border rounded p-1 bg-white"
                              referrerPolicy="no-referrer"
                            />
                            <span className="text-[7px] font-mono text-slate-400 mt-1 uppercase font-bold">Scan with GPay/Paytm</span>
                          </div>

                          <div className="flex-1 space-y-2">
                            <div className="space-y-0.5">
                              <p className="text-[9px] uppercase font-black text-slate-400 leading-none">Registered Merchant</p>
                              <p className="font-bold text-slate-800">{upiMerchantName}</p>
                            </div>
                            <div className="space-y-0.5">
                              <p className="text-[9px] uppercase font-black text-slate-400 leading-none">Unified Payments VPA Address</p>
                              <p className="font-mono font-bold text-blue-600 select-all" title="Click to copy">{upiId}</p>
                            </div>
                            <div className="space-y-0.5">
                              <p className="text-[9px] uppercase font-black text-slate-400 leading-none">B2B Order Sum</p>
                              <p className="font-black text-slate-900 text-sm">₹{cartTotal.toLocaleString()} <span className="text-[9px] text-slate-500 font-semibold">(INR)</span></p>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-2 pt-2 border-t border-slate-200">
                          <label className="text-[9px] font-black text-slate-600 uppercase tracking-wider block">
                            Enter 12-Digit UPI Transaction Reference Number (UTR) / Ref ID
                          </label>
                          
                          <div className="flex gap-2">
                            <input
                              type="text"
                              maxLength={12}
                              placeholder="e.g. 308944558822"
                              value={upiUtr}
                              disabled={upiUtrVerified || upiUtrChecking}
                              onChange={(e) => {
                                setUtrError('');
                                setUpiUtr(e.target.value.replace(/[^0-9]/g, ''));
                              }}
                              className="flex-1 p-2 border rounded-lg text-xs font-mono font-bold focus:outline-hidden focus:ring-1 focus:ring-blue-500 bg-white"
                            />
                            <button
                              type="button"
                              disabled={upiUtrVerified || upiUtrChecking}
                              onClick={() => {
                                const mockUtr = Array.from({length: 12}, () => Math.floor(Math.random() * 10)).join('');
                                setUpiUtr(mockUtr);
                                setUtrError('');
                              }}
                              className="px-2.5 border border-slate-200 rounded-lg hover:bg-slate-100 font-bold text-[9px] uppercase"
                            >
                              Auto-Fill UTR
                            </button>
                          </div>

                          {upiUtrError && <p className="text-[9px] text-rose-500 font-semibold">{upiUtrError}</p>}

                          <button
                            type="button"
                            disabled={upiUtrVerified || upiUtrChecking || upiUtr.length < 12}
                            onClick={() => {
                              setUtrError('');
                              setUpiUtrChecking(true);
                              const delay = upiGatewayStatus === 'Maintenance' ? 3000 : 1200;
                              setTimeout(() => {
                                setUpiUtrChecking(false);
                                setUpiUtrVerified(true);
                              }, delay);
                            }}
                            className={`w-full py-2 rounded-lg font-bold text-xs transition-all flex items-center justify-center gap-1 cursor-pointer ${
                              upiUtrVerified 
                                ? 'bg-emerald-50 border border-emerald-200 text-emerald-800 cursor-default font-black' 
                                : upiUtr.length < 12 
                                  ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                                  : 'bg-slate-900 text-white hover:bg-slate-800'
                            }`}
                          >
                            {upiUtrChecking ? (
                              <span className="flex items-center gap-1.5 font-mono text-[9px] text-slate-500 animate-pulse">
                                ⌛ Reconciling UPI Handshake on bank switch...
                              </span>
                            ) : upiUtrVerified ? (
                              <span className="flex items-center gap-1">
                                ✓ Transaction Verified! Proceed to place your order.
                              </span>
                            ) : (
                              <span>Verify & Lock Payment</span>
                            )}
                          </button>
                        </div>
                      </div>
                    )}

                    <div className="p-3 bg-amber-50 rounded-lg text-[11px] text-amber-800 font-medium flex gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
                      <span>Sandbox simulated checkout. Clicking "Place Order" will generate an active order in our simulated database tables which you can immediately track, pack, and ship in the Vendor/Admin dashboards.</span>
                    </div>

                    <div className="pt-4">
                      <button
                        onClick={submitCheckout}
                        disabled={paymentMethod === 'UPI' && isUpiAllowed && !upiUtrVerified}
                        className={`w-full py-3 font-black text-sm rounded-xl shadow-lg transition-all cursor-pointer flex items-center justify-center ${
                          paymentMethod === 'UPI' && isUpiAllowed && !upiUtrVerified 
                            ? 'bg-slate-200 text-slate-400 shadow-none cursor-not-allowed'
                            : 'bg-emerald-500 hover:bg-emerald-600 text-slate-950 shadow-emerald-100'
                        }`}
                      >
                        Place Order (₹{cartTotal.toLocaleString()})
                      </button>
                    </div>
                  </div>
                );
              })()}

            </div>

            {/* Right sidebar - order summary */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200 h-fit space-y-4">
              <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">
                Order Items Summary
              </h3>
              
              <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                {cart.map((item) => (
                  <div key={item.product.id} className="py-2.5 flex justify-between gap-2 text-xs">
                    <div>
                      <p className="font-bold text-slate-800">{item.product.name}</p>
                      <p className="text-[10px] text-slate-500">Qty: {item.quantity} × ₹{item.product.customerPrice.toLocaleString()}</p>
                      <p className="text-[9px] text-blue-600 font-semibold bg-blue-50 px-1.5 py-0.5 rounded w-fit mt-1">
                        Brand: {item.product.brand} | Supplier: {item.product.vendorName}
                      </p>
                    </div>
                    <span className="font-bold text-slate-900">₹{(item.product.customerPrice * item.quantity).toLocaleString()}</span>
                  </div>
                ))}
              </div>

              {/* Promo Code Input */}
              <div className="pt-2 border-t border-slate-100">
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Enter Coupon Code"
                    value={couponCodeInput}
                    onChange={(e) => setCouponCodeInput(e.target.value)}
                    className="flex-1 p-2 border border-slate-200 rounded-lg text-xs font-bold uppercase focus:outline-hidden"
                  />
                  <button
                    onClick={handleApplyCoupon}
                    className="px-3 bg-slate-900 text-white text-xs font-bold rounded-lg hover:bg-slate-800 transition-colors"
                  >
                    Apply
                  </button>
                </div>
                {couponError && <p className="text-[10px] text-rose-500 font-semibold mt-1">{couponError}</p>}
                {appliedCoupon && (
                  <div className="mt-2 p-1.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded flex justify-between items-center">
                    <span>Code Applied: {appliedCoupon.code} ({appliedCoupon.type === 'Percentage' ? `${appliedCoupon.value}%` : `₹${appliedCoupon.value}`} discount)</span>
                    <button onClick={() => setAppliedCoupon(null)} className="text-emerald-900 font-extrabold hover:underline">Remove</button>
                  </div>
                )}
              </div>

              {/* Calculations */}
              <div className="pt-4 border-t border-slate-100 space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Cart Subtotal:</span>
                  <span className="font-bold text-slate-800">₹{cartSubtotal.toLocaleString()}</span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-600">
                    <span>Coupon Discount:</span>
                    <span className="font-bold">- ₹{discountAmount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>Simulated Tax & Delivery:</span>
                  <span className="text-emerald-500 font-bold">FREE</span>
                </div>
                <div className="flex justify-between text-sm font-black text-slate-900 pt-2 border-t border-dashed border-slate-200">
                  <span>Final Customer Price:</span>
                  <span>₹{cartTotal.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        ) : checkoutStep === 'success' ? (
          /* Checkout order completion success banner */
          <div className="max-w-xl mx-auto bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-6">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h2 className="text-2xl font-extrabold text-slate-900">Order Placed Successfully!</h2>
              <p className="text-slate-500 text-xs font-semibold mt-1.5">
                Your order is safely recorded. Switch roles to **Admin** or **Vendor** in the top black bar to verify.
              </p>
            </div>

            {lastPlacedOrder && (
              <div className="bg-slate-50 p-4 rounded-xl text-left text-xs space-y-2 font-mono text-slate-700">
                <div className="flex justify-between font-bold">
                  <span>Order Reference:</span>
                  <span className="text-slate-900">{lastPlacedOrder.id}</span>
                </div>
                <div className="flex justify-between">
                  <span>Amount Paid:</span>
                  <span className="text-slate-900 font-bold">₹{lastPlacedOrder.total.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Payment Gateway:</span>
                  <span className="text-blue-600 font-bold">{lastPlacedOrder.paymentMethod}</span>
                </div>
                <div className="flex justify-between">
                  <span>Status:</span>
                  <span className="text-amber-600 font-bold uppercase">{lastPlacedOrder.status}</span>
                </div>
              </div>
            )}

            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setCheckoutStep('cart')}
                className="px-5 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 cursor-pointer"
              >
                Continue Shopping
              </button>
              <button
                onClick={() => {
                  setCheckoutStep('cart');
                  const btn = document.getElementById('cust-nav-orders');
                  if (btn) btn.click();
                }}
                className="px-5 py-2.5 bg-slate-100 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-200 cursor-pointer"
              >
                Track My Orders
              </button>
            </div>
          </div>
        ) : (
          /* Standard Storefront Catalog */
          <div className="space-y-12">
            
            {/* Vendor Filter Store Banner */}
            {selectedVendorStore && (
              <div className="bg-white p-6 rounded-2xl border border-blue-100 shadow-xs flex flex-wrap gap-4 items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-xl bg-slate-100 overflow-hidden border border-slate-200 flex items-center justify-center">
                    <img 
                      src={selectedVendorStore.logoUrl} 
                      alt={selectedVendorStore.businessName}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h2 className="text-xl font-bold text-slate-900">{selectedVendorStore.businessName}</h2>
                      {selectedVendorStore.verified && (
                        <span className="bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full text-[10px] font-bold inline-flex items-center gap-0.5">
                          <ShieldCheck className="w-3 h-3" /> Verified Partner
                        </span>
                      )}
                    </div>
                    <p className="text-slate-500 text-xs mt-1">Managed by {selectedVendorStore.ownerName} • {selectedVendorStore.businessAddress}</p>
                    <div className="flex items-center gap-1 text-xs text-amber-500 font-bold mt-1">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span>{selectedVendorStore.rating} Rating</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedVendorStore(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg cursor-pointer"
                >
                  Show All Stores
                </button>
              </div>
            )}

            {/* Categories Horizontal Banner */}
            {!selectedVendorStore && (
              <div className="space-y-4">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 font-mono">
                  Browse Certified Clinical Categories
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
                  {CATEGORIES.map((cat) => (
                    <div
                      key={cat.id}
                      onClick={() => setActiveCategory(activeCategory === cat.id ? 'all' : cat.id)}
                      className={`p-3.5 rounded-lg border cursor-pointer select-none transition-all duration-150 ${
                        activeCategory === cat.id 
                          ? 'bg-slate-950 text-white border-slate-950 shadow-xs' 
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                      }`}
                    >
                      <p className="font-bold text-xs tracking-tight line-clamp-1 font-display">{cat.name}</p>
                      <p className={`text-[10px] mt-0.5 line-clamp-2 font-sans ${activeCategory === cat.id ? 'text-slate-300' : 'text-slate-400'}`}>
                        {cat.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Featured Products Catalog Grid */}
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-extrabold text-slate-900">
                  {selectedVendorStore ? `${selectedVendorStore.businessName} Catalog` : 'Verified Products Catalog'}
                  <span className="text-xs font-semibold text-slate-500 ml-2">({filteredProducts.length} devices available)</span>
                </h3>
                {activeCategory !== 'all' && (
                  <button
                    onClick={() => setActiveCategory('all')}
                    className="text-xs font-bold text-blue-600 hover:underline"
                  >
                    Clear Filter
                  </button>
                )}
              </div>

              {filteredProducts.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-md mx-auto space-y-3">
                  <AlertCircle className="w-12 h-12 text-slate-400 mx-auto" />
                  <p className="text-slate-800 font-bold text-sm">No clinical devices match your filter.</p>
                  <p className="text-slate-500 text-xs">Try selecting another category or resetting the search box.</p>
                  <button
                    onClick={() => {
                      setActiveCategory('all');
                      setSelectedVendorStore(null);
                    }}
                    className="px-4 py-2 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 cursor-pointer mt-2"
                  >
                    Reset Store View
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {filteredProducts.map((p) => {
                    const isWishlisted = wishlist.includes(p.id);
                    const isComparing = compareList.some(item => item.id === p.id);
                    return (
                      <div 
                        key={p.id}
                        className="bg-white rounded-lg border border-slate-200/80 hover:border-slate-900 transition-all shadow-xs flex flex-col group relative overflow-hidden"
                      >
                        {/* Discount Sticker badge */}
                        {p.discountPercent && p.discountPercent > 0 ? (
                          <span className="absolute top-3 left-3 z-10 bg-emerald-500 text-slate-950 font-bold text-[9px] px-2 py-0.5 rounded-sm uppercase tracking-wider">
                            Save {p.discountPercent}%
                          </span>
                        ) : null}

                        {/* Image Frame */}
                        <div className="w-full h-44 bg-slate-50/50 relative overflow-hidden flex items-center justify-center border-b border-slate-100">
                          <img 
                            src={p.imageUrl} 
                            alt={p.name}
                            className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                          />
                          {/* Wishlist toggle absolute button */}
                          <button
                            onClick={() => onToggleWishlist(p)}
                            className={`absolute top-2.5 right-2.5 p-1.5 rounded-md shadow-xs cursor-pointer ${
                              isWishlisted ? 'bg-rose-500 text-white' : 'bg-white text-slate-400 hover:text-rose-500 border border-slate-200/60'
                            }`}
                          >
                            <Heart className="w-3 h-3 fill-current" />
                          </button>
                        </div>

                        {/* Details Body */}
                        <div className="p-3.5 flex-1 flex flex-col space-y-2">
                          <div className="flex justify-between items-center text-[9px] text-slate-400 font-mono uppercase tracking-wider">
                            <span>{p.category}</span>
                            <span>{p.brand}</span>
                          </div>

                          <h4 
                            onClick={() => setSelectedProduct(p)}
                            className="text-xs font-bold text-slate-900 group-hover:text-slate-800 transition-colors cursor-pointer line-clamp-2 font-display"
                          >
                            {p.name}
                          </h4>

                          {/* Vendor with Verified icon */}
                          <div className="flex items-center gap-1 text-[10px]">
                            <span className="text-slate-400">Store: </span>
                            <span 
                              onClick={() => {
                                const matched = vendors.find(v => v.id === p.vendorId);
                                if (matched) setSelectedVendorStore(matched);
                              }}
                              className="text-slate-900 font-semibold hover:underline cursor-pointer"
                            >
                              {p.vendorName}
                            </span>
                          </div>

                          {/* Ratings and reviews */}
                          <div className="flex items-center gap-1.5 text-xs text-amber-500 font-bold">
                            <Star className="w-3 h-3 fill-current" />
                            <span className="text-slate-700 text-[10px]">{p.rating || '4.5'}</span>
                            <span className="text-slate-200">|</span>
                            <span className="text-slate-400 text-[9px] font-mono">In Stock: {p.stock}</span>
                          </div>

                          {/* Beautiful customer-facing price display block */}
                          <div className="flex items-baseline justify-between mt-1">
                            <div className="space-y-0.5">
                              <span className="text-base font-black text-slate-900 font-mono">
                                ₹{p.customerPrice.toLocaleString()}
                              </span>
                              {p.mrp && p.mrp > p.customerPrice ? (
                                <div className="flex items-center gap-1">
                                  <span className="text-[9px] text-slate-400 line-through">
                                    MRP: ₹{p.mrp.toLocaleString()}
                                  </span>
                                  <span className="text-[9px] text-emerald-600 font-black">
                                    ({Math.round((1 - p.customerPrice / p.mrp) * 100)}% OFF)
                                  </span>
                                </div>
                              ) : null}
                            </div>
                            <span className="text-[9px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-sm font-bold font-mono">
                              MOQ: {p.moq || 1}
                            </span>
                          </div>

                          {/* Action area */}
                          <div className="pt-2 mt-auto space-y-1.5">
                            {/* Compare checklist */}
                            <button
                              onClick={() => onToggleCompare(p)}
                              className={`w-full py-1.5 text-[10px] font-medium border rounded-md flex items-center justify-center gap-1 cursor-pointer transition-colors ${
                                isComparing 
                                  ? 'border-emerald-600 bg-emerald-50/50 text-emerald-800 font-semibold' 
                                  : 'border-slate-200 text-slate-600 hover:bg-slate-50/50'
                              }`}
                            >
                              <ArrowLeftRight className="w-3 h-3" />
                              {isComparing ? 'Comparing (Remove)' : 'Compare Device'}
                            </button>

                            {/* Buy Now & Add to Cart button layout */}
                            <div className="grid grid-cols-2 gap-1.5">
                              <button
                                onClick={() => {
                                  onAddToCart(p);
                                  setCartOpen(true);
                                }}
                                className="py-2 bg-slate-50 border border-slate-200 text-slate-800 text-[10px] font-medium rounded-md hover:bg-slate-100 hover:border-slate-300 cursor-pointer transition-colors text-center"
                              >
                                Add to Cart
                              </button>
                              <button
                                onClick={() => {
                                  onAddToCart(p);
                                  setCheckoutStep('billing');
                                }}
                                className="py-2 bg-slate-950 text-white text-[10px] font-medium rounded-md hover:bg-slate-850 cursor-pointer transition-colors text-center"
                              >
                                Buy Now
                              </button>
                            </div>
                          </div>

                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Vendor Stores Grid Carousel Section */}
            {!selectedVendorStore && (
              <div className="bg-white p-6 rounded-lg border border-slate-200/80 space-y-6">
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  India's Verified Medical & Hospital Suppliers
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {vendors.filter(v => v.status === 'Approved').map((v) => (
                    <div 
                      key={v.id}
                      className="border border-slate-200 rounded-lg p-4 space-y-3 hover:border-slate-900 transition-all"
                    >
                      <div className="flex gap-3 items-center">
                        <div className="w-12 h-12 rounded-lg overflow-hidden bg-slate-50 border border-slate-200/60 shrink-0 flex items-center justify-center">
                          <img src={v.logoUrl} alt={v.businessName} className="w-full h-full object-cover" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-900 font-display">{v.businessName}</p>
                          <p className="text-[10px] text-slate-400 font-medium">Owner: {v.ownerName}</p>
                        </div>
                      </div>
                      <div className="text-[10px] text-slate-500 space-y-1 bg-slate-50/60 p-2 rounded-md font-mono">
                        <p className="line-clamp-1">📍 {v.businessAddress}</p>
                        <p>📄 License: <span>{v.tradeLicense}</span></p>
                      </div>
                      <button
                        onClick={() => setSelectedVendorStore(v)}
                        className="w-full py-1.5 bg-slate-50 hover:bg-slate-100 text-slate-900 text-xs font-semibold rounded-md border border-slate-200 transition-colors cursor-pointer"
                      >
                        Visit Certified Store
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        )}
      </div>

      {/* Product Details Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 relative shadow-2xl max-h-[90vh] overflow-y-auto space-y-4">
            <button
              onClick={() => setSelectedProduct(null)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 cursor-pointer"
            >
              <Minus className="w-4 h-4" />
            </button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
              <div className="w-full h-64 bg-slate-50 rounded-xl overflow-hidden border">
                <img src={selectedProduct.imageUrl} alt={selectedProduct.name} className="w-full h-full object-cover" />
              </div>

              <div className="space-y-3">
                <span className="bg-blue-100 text-blue-700 font-bold text-[9px] px-2 py-0.5 rounded-full uppercase">
                  {selectedProduct.category}
                </span>
                <h3 className="text-base font-bold text-slate-900 leading-snug">{selectedProduct.name}</h3>
                <p className="text-[10px] text-slate-500 font-mono">SKU: {selectedProduct.sku} • Brand: {selectedProduct.brand}</p>
                <p className="text-xs text-slate-600 leading-relaxed">{selectedProduct.description}</p>

                {/* Client-friendly Pricing Block */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                  <div className="flex items-baseline justify-between">
                    <div>
                      <p className="text-[9px] text-slate-400 uppercase tracking-widest font-bold">Offer Price</p>
                      <span className="text-2xl font-black text-slate-900 font-mono">
                        ₹{selectedProduct.customerPrice.toLocaleString()}
                      </span>
                    </div>
                    {selectedProduct.mrp && selectedProduct.mrp > selectedProduct.customerPrice ? (
                      <span className="bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-1 rounded-sm uppercase tracking-wide">
                        Save {Math.round((1 - selectedProduct.customerPrice / selectedProduct.mrp) * 100)}%
                      </span>
                    ) : null}
                  </div>

                  {selectedProduct.mrp && selectedProduct.mrp > selectedProduct.customerPrice ? (
                    <div className="text-xs text-slate-500 font-medium flex items-center gap-2">
                      <span>Maximum Retail Price:</span>
                      <span className="line-through font-mono">₹{selectedProduct.mrp.toLocaleString()}</span>
                      <span className="text-emerald-600 font-bold font-mono">(You save ₹{(selectedProduct.mrp - selectedProduct.customerPrice).toLocaleString()})</span>
                    </div>
                  ) : null}

                  <div className="pt-2 border-t border-slate-200/60 grid grid-cols-2 gap-4 text-[10px] font-mono text-slate-500">
                    <div>
                      <span>Stock Status:</span>
                      <span className="text-emerald-600 font-bold ml-1">In Stock ({selectedProduct.stock} units)</span>
                    </div>
                    <div>
                      <span>Min Order Qty:</span>
                      <span className="text-slate-800 font-bold ml-1">{selectedProduct.moq || 1} unit(s)</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => {
                      onAddToCart(selectedProduct);
                      setSelectedProduct(null);
                      setCartOpen(true);
                    }}
                    className="flex-1 py-2.5 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    Add to Cart
                  </button>
                  <button
                    onClick={() => {
                      onAddToCart(selectedProduct);
                      setSelectedProduct(null);
                      setCheckoutStep('billing');
                    }}
                    className="flex-1 py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 transition-colors cursor-pointer"
                  >
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Shopping Cart Drawer */}
      {cartOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex justify-end">
          <div className="bg-white w-full max-w-md h-full shadow-2xl p-6 flex flex-col justify-between animate-in slide-in-from-right duration-200">
            <div>
              <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                  <ShoppingBag className="w-5 h-5 text-blue-600" />
                  Your Procurement Cart ({cart.length})
                </h3>
                <button
                  onClick={() => setCartOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <Minus className="w-5 h-5" />
                </button>
              </div>

              {cart.length === 0 ? (
                <div className="text-center py-12 space-y-3">
                  <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto" />
                  <p className="text-xs text-slate-500 font-bold">Your cart is empty.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 max-h-[60vh] overflow-y-auto pr-1">
                  {cart.map((item) => (
                    <div key={item.product.id} className="py-4 flex gap-3">
                      <div className="w-14 h-14 bg-slate-50 rounded border shrink-0 overflow-hidden">
                        <img src={item.product.imageUrl} alt={item.product.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <p className="text-xs font-bold text-slate-900 line-clamp-1">{item.product.name}</p>
                        <p className="text-[10px] text-slate-500 font-semibold font-mono">₹{item.product.customerPrice.toLocaleString()}/unit</p>
                        
                        <div className="flex items-center justify-between pt-1">
                          <div className="flex items-center border rounded-lg overflow-hidden bg-slate-50">
                            <button
                              onClick={() => onUpdateCartQty(item.product.id, item.quantity - 1)}
                              className="px-2 py-1 text-slate-500 hover:bg-slate-100 cursor-pointer"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2.5 text-xs font-bold text-slate-800">{item.quantity}</span>
                            <button
                              onClick={() => onUpdateCartQty(item.product.id, item.quantity + 1)}
                              className="px-2 py-1 text-slate-500 hover:bg-slate-100 cursor-pointer"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          
                          <button
                            onClick={() => onRemoveFromCart(item.product.id)}
                            className="p-1 text-rose-500 hover:text-rose-700 cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <div className="border-t border-slate-100 pt-4 space-y-3">
                <div className="flex justify-between text-xs text-slate-600">
                  <span>Procurement Subtotal:</span>
                  <span className="font-bold text-slate-900">₹{cartSubtotal.toLocaleString()}</span>
                </div>
                <div className="p-2 bg-blue-50/50 rounded-lg text-[10px] text-blue-800 font-semibold flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Verified dynamic commission tracking complete.</span>
                </div>
                <button
                  onClick={() => {
                    setCartOpen(false);
                    setCheckoutStep('billing');
                  }}
                  className="w-full py-3 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-md hover:bg-blue-700 transition-colors cursor-pointer"
                >
                  Proceed to Secure Checkout
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Wishlist Sidebar Drawer */}
      {wishlistOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex justify-end">
          <div className="bg-white w-full max-w-md h-full shadow-2xl p-6 flex flex-col justify-between animate-in slide-in-from-right duration-200">
            <div>
              <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-1.5">
                  <Heart className="w-5 h-5 text-rose-500 fill-current" />
                  Saved Wishlist ({wishlist.length})
                </h3>
                <button
                  onClick={() => setWishlistOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <Minus className="w-5 h-5" />
                </button>
              </div>

              {wishlist.length === 0 ? (
                <div className="text-center py-12 space-y-3">
                  <Heart className="w-12 h-12 text-slate-300 mx-auto" />
                  <p className="text-xs text-slate-500 font-bold">Your wishlist is empty.</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 max-h-[70vh] overflow-y-auto pr-1">
                  {wishlist.map((id) => {
                    const matchedProd = products.find(p => p.id === id);
                    if (!matchedProd) return null;
                    return (
                      <div key={id} className="py-4 flex gap-3">
                        <div className="w-12 h-12 bg-slate-50 rounded border overflow-hidden shrink-0">
                          <img src={matchedProd.imageUrl} alt={matchedProd.name} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 space-y-1">
                          <p className="text-xs font-bold text-slate-950 line-clamp-1">{matchedProd.name}</p>
                          <p className="text-[10px] font-mono text-blue-600">₹{matchedProd.customerPrice.toLocaleString()}</p>
                          <div className="flex gap-2 pt-1">
                            <button
                              onClick={() => {
                                onAddToCart(matchedProd);
                                onToggleWishlist(matchedProd);
                              }}
                              className="px-2.5 py-1 bg-slate-900 text-white text-[9px] font-bold rounded-lg cursor-pointer"
                            >
                              Add to Cart
                            </button>
                            <button
                              onClick={() => onToggleWishlist(matchedProd)}
                              className="px-2 py-1 text-rose-500 text-[9px] font-bold hover:underline cursor-pointer"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Product Comparison Engine Overlay */}
      {compareOpen && (
        <div className="fixed inset-x-0 bottom-0 bg-white border-t-2 border-blue-500 shadow-2xl z-50 p-6 max-h-[50vh] overflow-y-auto animate-in slide-in-from-bottom duration-250">
          <div className="max-w-7xl mx-auto space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5">
                  <ArrowLeftRight className="w-4 h-4 text-blue-600" />
                  Clinical Device Comparison Panel
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">Compare specifications and pricing across up to 3 medical vendors.</p>
              </div>
              <button
                onClick={() => setCompareOpen(false)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg cursor-pointer"
              >
                Close Panel
              </button>
            </div>

            {compareList.length === 0 ? (
              <p className="text-center text-xs text-slate-500 py-6">Select "Compare Device" on product cards above to start benchmarking.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
                {/* Headers column */}
                <div className="hidden md:block space-y-3 font-bold text-slate-500 pt-24 text-right pr-4">
                  <div className="h-10">Brand</div>
                  <div className="h-10">Category</div>
                  <div className="h-10">Rating</div>
                  <div className="h-10">Stock Count</div>
                  <div className="h-10">Vendor Store</div>
                  <div className="h-10">Selling Price</div>
                  <div className="h-10">Customer Price</div>
                </div>

                {/* Products comparison */}
                {compareList.slice(0, 3).map((p) => (
                  <div key={p.id} className="border border-slate-200 rounded-xl p-3.5 bg-slate-50 space-y-3 relative">
                    <button
                      onClick={() => onToggleCompare(p)}
                      className="absolute top-2 right-2 text-rose-500 hover:text-rose-700 font-extrabold"
                    >
                      Remove
                    </button>
                    <div className="flex gap-2 items-center">
                      <div className="w-10 h-10 rounded overflow-hidden shrink-0 border bg-white">
                        <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover" />
                      </div>
                      <p className="font-bold text-slate-900 line-clamp-2 h-8 text-[11px] leading-tight">{p.name}</p>
                    </div>

                    <div className="space-y-3 md:pt-4">
                      <div className="md:h-10 flex md:block justify-between items-center"><span className="md:hidden font-bold text-slate-500">Brand: </span>{p.brand}</div>
                      <div className="md:h-10 flex md:block justify-between items-center"><span className="md:hidden font-bold text-slate-500">Category: </span>{p.category}</div>
                      <div className="md:h-10 flex md:block justify-between items-center"><span className="md:hidden font-bold text-slate-500">Rating: </span>★ {p.rating || '4.5'}</div>
                      <div className="md:h-10 flex md:block justify-between items-center"><span className="md:hidden font-bold text-slate-500">Stock: </span>{p.stock} units</div>
                      <div className="md:h-10 flex md:block justify-between items-center"><span className="md:hidden font-bold text-slate-500">Store: </span>{p.vendorName}</div>
                      <div className="md:h-10 flex md:block justify-between items-center text-slate-600"><span className="md:hidden font-bold text-slate-500">Base Price: </span>₹{p.sellingPrice.toLocaleString()}</div>
                      <div className="md:h-10 flex md:block justify-between items-center text-blue-700 font-extrabold text-[13px]"><span className="md:hidden font-bold text-slate-500">Customer Price: </span>₹{p.customerPrice.toLocaleString()}</div>
                    </div>

                    <button
                      onClick={() => onAddToCart(p)}
                      className="w-full py-1.5 bg-slate-900 text-white text-[10px] font-bold rounded-lg cursor-pointer"
                    >
                      Add to Cart
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Bottom Legal / CMS Navigation links */}
      <footer className="bg-slate-900 text-slate-300 mt-20 border-t border-slate-800 text-xs">
        <div className="max-w-7xl mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <p className="text-white font-extrabold tracking-widest text-sm">HEALNEX MED BAZAR</p>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              India's premier digital marketplace connecting healthcare centers with verified clinical device manufacturers. Approved under Super Admin verification standards.
            </p>
          </div>
          <div>
            <p className="text-white font-bold mb-3 uppercase text-[11px] tracking-wider">Quick Info Pages</p>
            <div className="flex flex-col gap-2 font-medium">
              <button onClick={() => setActiveCmsPage('about-us')} className="text-left hover:text-white transition-colors cursor-pointer">About Us</button>
              <button onClick={() => setActiveCmsPage('faq')} className="text-left hover:text-white transition-colors cursor-pointer">Frequently Asked Questions (FAQ)</button>
              <button onClick={() => setActiveCmsPage('contact-us')} className="text-left hover:text-white transition-colors cursor-pointer">Support Hub</button>
            </div>
          </div>
          <div>
            <p className="text-white font-bold mb-3 uppercase text-[11px] tracking-wider">Policies</p>
            <div className="flex flex-col gap-2 font-medium">
              <button onClick={() => setActiveCmsPage('privacy-policy')} className="text-left hover:text-white transition-colors cursor-pointer">Privacy Policy</button>
              <button onClick={() => setActiveCmsPage('terms-and-conditions')} className="text-left hover:text-white transition-colors cursor-pointer">Terms & Conditions</button>
              <button onClick={() => setActiveCmsPage('return-policy')} className="text-left hover:text-white transition-colors cursor-pointer">Return Policy</button>
            </div>
          </div>
          <div>
            <p className="text-white font-bold mb-3 uppercase text-[11px] tracking-wider">Suppliers Guidelines</p>
            <button onClick={() => setActiveCmsPage('vendor-policy')} className="text-left hover:text-white transition-colors cursor-pointer font-medium block">
              Vendor Policy & Guidelines
            </button>
          </div>
        </div>
        <div className="border-t border-slate-800 py-6 text-center text-[11px] text-slate-500 font-medium">
          © 2026 HealNex Med Bazar Corp. Powered by AI Studio Sandbox Engine.
        </div>
      </footer>

    </div>
  );
}
