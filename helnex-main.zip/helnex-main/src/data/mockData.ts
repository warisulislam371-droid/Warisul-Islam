import { Product, Vendor, Coupon, SupportTicket, Review, Banner, CMSPage, Order } from '../types';

export const CATEGORIES = [
  { id: 'med-equip', name: 'Medical Equipment', icon: 'HeartPulse', description: 'Advanced surgical & monitoring systems' },
  { id: 'diag-equip', name: 'Diagnostic Equipment', icon: 'Stethoscope', description: 'Blood monitors, imaging, and lab tools' },
  { id: 'hosp-furn', name: 'Hospital Furniture', icon: 'BedDouble', description: 'ICU beds, stretchers, and cabinets' },
  { id: 'home-health', name: 'Home Healthcare', icon: 'Home', description: 'Daily aids, walkers, and wheelchairs' },
  { id: 'surg-inst', name: 'Surgical Instruments', icon: 'Scissors', description: 'Precision surgical blades and forcep kits' },
  { id: 'lab-equip', name: 'Laboratory Equipment', icon: 'FlaskConical', description: 'Microscopes, centrifuges, and test kits' },
  { id: 'icu-equip', name: 'ICU Equipment', icon: 'Activity', description: 'Ventilators, infusion pumps, and monitors' },
  { id: 'pharmacy', name: 'Pharmacy Products', icon: 'Pills', description: 'Over-the-counter & prescription medicines' },
  { id: 'wellness', name: 'Wellness Products', icon: 'Sparkles', description: 'Supplements, massage tools, and nutrition' },
  { id: 'health-mon', name: 'Health Monitoring Devices', icon: 'ActivitySquare', description: 'Oximeters, thermometers, and scales' }
];

export const INITIAL_VENDORS: Vendor[] = [
  {
    id: 'vendor-1',
    businessName: 'Apex Hospital Systems',
    ownerName: 'Dr. Rajesh Patel',
    mobile: '+91 98765 43210',
    email: 'contact@apexsystems.com',
    gstNumber: '22AAAAA0000A1Z5',
    panNumber: 'ABCDE1234F',
    tradeLicense: 'TL-2024-8891A',
    businessAddress: 'Sector-5, Salt Lake, Kolkata, West Bengal, India - 700091',
    bankDetails: {
      accountName: 'Apex Hospital Systems Pvt Ltd',
      accountNumber: '50200012345678',
      bankName: 'HDFC Bank',
      ifscCode: 'HDFC0000012'
    },
    status: 'Approved',
    rating: 4.8,
    productCount: 4,
    logoUrl: 'https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?auto=format&fit=crop&q=80&w=200',
    verified: true,
    trustLevel: 'Premium Verified'
  },
  {
    id: 'vendor-2',
    businessName: 'HealLife Medical Supplies',
    ownerName: 'Mrs. Sunita Rao',
    mobile: '+91 87654 32109',
    email: 'info@heallifemedical.in',
    gstNumber: '29BBBBB1111B2Z3',
    panNumber: 'FGHIJ5678K',
    tradeLicense: 'TL-2023-4561X',
    businessAddress: 'Peenya Industrial Area, Bengaluru, Karnataka, India - 560058',
    bankDetails: {
      accountName: 'HealLife Supplies',
      accountNumber: '918000987654321',
      bankName: 'Axis Bank',
      ifscCode: 'UTIB0000123'
    },
    status: 'Approved',
    rating: 4.5,
    productCount: 4,
    logoUrl: 'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&q=80&w=200',
    verified: true,
    trustLevel: 'Verified'
  },
  {
    id: 'vendor-3',
    businessName: 'Global Diagnostic Instruments',
    ownerName: 'Mr. Vivek Anand',
    mobile: '+91 76543 21098',
    email: 'sales@globaldiags.com',
    gstNumber: '27CCCCC2222C3Z1',
    panNumber: 'KLMNO9012P',
    tradeLicense: 'TL-2025-9903P',
    businessAddress: 'Bandra Kurla Complex, Mumbai, Maharashtra, India - 400051',
    bankDetails: {
      accountName: 'Global Diagnostic Group',
      accountNumber: '100234567890',
      bankName: 'State Bank of India',
      ifscCode: 'SBIN0000234'
    },
    status: 'Approved',
    rating: 4.6,
    productCount: 4,
    logoUrl: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=200',
    verified: true,
    trustLevel: 'Trusted Seller'
  },
  {
    id: 'vendor-4',
    businessName: 'Eastern Surgical Warehouse',
    ownerName: 'Mr. Rohan Gupta',
    mobile: '+91 99887 76655',
    email: 'support@easternsurgical.com',
    gstNumber: '19DDDDD3333D4Z2',
    panNumber: 'PQRST3456X',
    tradeLicense: 'TL-2024-5121Q',
    businessAddress: 'Lamington Road, New Delhi, India - 110002',
    status: 'Pending',
    rating: 0,
    productCount: 0,
    logoUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=200',
    verified: false,
    trustLevel: 'Pending Verification'
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  // Diagnostic Equipment
  {
    id: 'p-1',
    name: 'Multi-parameter ICU Patient Monitor V12',
    sku: 'SKU-APX-ICUMON12',
    category: 'ICU Equipment',
    brand: 'ApexTech',
    description: 'Highly accurate 12.1 inch multi-parameter ICU monitor displaying real-time ECG, SpO2, NIBP, Respiration rate, Temp, and Pulse rate. Features visual and auditory alarms for swift patient care.',
    imageUrl: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?auto=format&fit=crop&q=80&w=400',
    stock: 12,
    mrp: 65000,
    vendorPrice: 42000,
    gstRate: 18,
    moq: 1,
    sellingPrice: 42000, // Vendor gets this
    commissionPercent: 10, // Global Admin Comm is 10%
    customerPrice: 46200, // Client pays 42000 * 1.1 = 46200
    vendorId: 'vendor-1',
    vendorName: 'Apex Hospital Systems',
    rating: 4.9,
    discountPercent: 29, // ((65000-46200)/65000)*100
    approved: true
  },
  {
    id: 'p-2',
    name: 'Automatic Digital Blood Pressure Monitor Pro',
    sku: 'SKU-GDI-BPMON',
    category: 'Diagnostic Equipment',
    brand: 'Omron Elite',
    description: 'Fully automatic blood pressure monitor featuring standard oscillometric system. Easy single-touch operation, standard memory recall for up to 90 readings, and irregular heartbeat tracking indicator.',
    imageUrl: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=400',
    stock: 150,
    mrp: 3500,
    vendorPrice: 1800,
    gstRate: 12,
    moq: 5,
    sellingPrice: 1800,
    commissionPercent: 10,
    customerPrice: 1980,
    vendorId: 'vendor-3',
    vendorName: 'Global Diagnostic Instruments',
    rating: 4.7,
    discountPercent: 43,
    approved: true
  },
  {
    id: 'p-3',
    name: 'Premium OLED Pulse Oximeter Pro-X',
    sku: 'SKU-GDI-OXI99',
    category: 'Health Monitoring Devices',
    brand: 'Oxylink',
    description: 'Pulse Oximeter with clear multi-directional dual color OLED display. Accurately measures Arterial Oxygen Saturation (SpO2) and Pulse Rate (PR). Compact, lightweight, with carry pouch.',
    imageUrl: 'https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&q=80&w=400',
    stock: 500,
    mrp: 1999,
    vendorPrice: 850,
    gstRate: 12,
    moq: 10,
    sellingPrice: 850,
    commissionPercent: 10,
    customerPrice: 935,
    vendorId: 'vendor-3',
    vendorName: 'Global Diagnostic Instruments',
    rating: 4.8,
    discountPercent: 53,
    approved: true
  },
  // Hospital Furniture
  {
    id: 'p-4',
    name: 'Premium 3-Function Manual ICU Bed',
    sku: 'SKU-APX-BED3F',
    category: 'Hospital Furniture',
    brand: 'BedMasters',
    description: 'Standard hospital ICU bed featuring dual fold collapsible aluminum side-rails, backrest adjustment, knee-rest adjustment, and adjustable height controls with manual crank system. Complete with heavy duty lockable caster wheels.',
    imageUrl: 'https://images.unsplash.com/photo-1586773860418-d37222d8fce2?auto=format&fit=crop&q=80&w=400',
    stock: 8,
    mrp: 45000,
    vendorPrice: 28000,
    gstRate: 18,
    moq: 1,
    sellingPrice: 28000,
    commissionPercent: 10,
    customerPrice: 30800,
    vendorId: 'vendor-1',
    vendorName: 'Apex Hospital Systems',
    rating: 4.5,
    discountPercent: 32,
    approved: true
  },
  // Home Healthcare
  {
    id: 'p-5',
    name: 'Foldable Lightweight Wheelchair LiteRide',
    sku: 'SKU-HLL-WC1',
    category: 'Home Healthcare',
    brand: 'MobilityMax',
    description: 'Ergonomic lightweight foldable wheelchair with high-strength steel alloy chassis. Comfortable padded black nylon canvas seating, desk-length armrests, detachable swing-away footrests, and solid rubber puncture-proof wheels.',
    imageUrl: 'https://images.unsplash.com/photo-1547082299-de196ea013d6?auto=format&fit=crop&q=80&w=400',
    stock: 25,
    mrp: 12000,
    vendorPrice: 6500,
    gstRate: 5,
    moq: 2,
    sellingPrice: 6500,
    commissionPercent: 10,
    customerPrice: 7150,
    vendorId: 'vendor-2',
    vendorName: 'HealLife Medical Supplies',
    rating: 4.6,
    discountPercent: 40,
    approved: true
  },
  // Surgical Instruments
  {
    id: 'p-6',
    name: 'Clinical Grade Stainless Surgical Scalpel Kit',
    sku: 'SKU-APX-SK10',
    category: 'Surgical Instruments',
    brand: 'ApexSurg',
    description: 'Professional surgical scalpel handle set including 2 surgical grade handle grips (No 3, No 4) and 50 carbon steel sterile disposable scalpel blades of varying sizes (No 10, 11, 15, 20). Packaged safely in protective slots.',
    imageUrl: 'https://images.unsplash.com/photo-1606206591513-adbf6da2ad41?auto=format&fit=crop&q=80&w=400',
    stock: 90,
    mrp: 2500,
    vendorPrice: 1200,
    gstRate: 12,
    moq: 15,
    sellingPrice: 1200,
    commissionPercent: 10,
    customerPrice: 1320,
    vendorId: 'vendor-1',
    vendorName: 'Apex Hospital Systems',
    rating: 4.7,
    discountPercent: 47,
    approved: true
  },
  // Laboratory Equipment
  {
    id: 'p-7',
    name: 'Clinical Binocular Compound Microscope 2000x',
    sku: 'SKU-HLL-MIC2K',
    category: 'Laboratory Equipment',
    brand: 'ZeissLab',
    description: 'Compound microscope offering double-layer mechanical stage, co-axial coarse & fine focusing adjustments, LED illumination, and premium semi-plan achromatic objective glass lenses (4x, 10x, 40x, 100x Oil). Perfect for clinical lab tests.',
    imageUrl: 'https://images.unsplash.com/photo-1579165466521-35b84393b6b0?auto=format&fit=crop&q=80&w=400',
    stock: 5,
    mrp: 35000,
    vendorPrice: 18500,
    gstRate: 18,
    moq: 1,
    sellingPrice: 18500,
    commissionPercent: 10,
    customerPrice: 20350,
    vendorId: 'vendor-2',
    vendorName: 'HealLife Medical Supplies',
    rating: 4.8,
    discountPercent: 42,
    approved: true
  },
  // Home Healthcare
  {
    id: 'p-8',
    name: 'Ergonomic Comfort Wheelchair Cushion Gel',
    sku: 'SKU-HLL-GELPAD',
    category: 'Home Healthcare',
    brand: 'HealSupport',
    description: 'Medical grade gel seat cushion designed specifically for standard wheelchairs and office chairs. Relieves pelvic pressure, avoids pressure sores, features a breathable non-slip mesh cover.',
    imageUrl: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=400',
    stock: 40,
    mrp: 2999,
    vendorPrice: 1400,
    gstRate: 12,
    moq: 5,
    sellingPrice: 1400,
    commissionPercent: 10,
    customerPrice: 1540,
    vendorId: 'vendor-2',
    vendorName: 'HealLife Medical Supplies',
    rating: 4.4,
    discountPercent: 49,
    approved: true
  },
  // Unapproved products (testing and approval simulation)
  {
    id: 'p-9',
    name: 'Professional Digital Pocket Otoscope',
    sku: 'SKU-GDI-OTO01',
    category: 'Diagnostic Equipment',
    brand: 'Diagnostix',
    description: 'Compact otoscope with bright fiber optic LED illumination. Provides wide magnifying glass viewport, safe reusable diagnostic ear tips, battery operated.',
    imageUrl: 'https://images.unsplash.com/photo-1579684389782-64d84b5e901a?auto=format&fit=crop&q=80&w=400',
    stock: 30,
    mrp: 6000,
    vendorPrice: 3200,
    gstRate: 12,
    moq: 3,
    sellingPrice: 3200,
    commissionPercent: 10,
    customerPrice: 3520,
    vendorId: 'vendor-3',
    vendorName: 'Global Diagnostic Instruments',
    rating: 0,
    approved: false // Needs Super Admin approval
  }
];

export const INITIAL_COUPONS: Coupon[] = [
  { id: 'c-1', code: 'HEALNEX10', type: 'Percentage', value: 10, minPurchase: 1000, active: true },
  { id: 'c-2', code: 'MEDBAZAR500', type: 'Fixed', value: 500, minPurchase: 5000, active: true },
  { id: 'c-3', code: 'SUPERCLINIC', type: 'Percentage', value: 15, minPurchase: 15000, active: true }
];

export const INITIAL_BANNERS: Banner[] = [
  {
    id: 'b-1',
    imageUrl: 'https://images.unsplash.com/photo-1538108176447-280586497d96?auto=format&fit=crop&q=80&w=1200',
    title: "India's Trusted Medical Multi-Vendor Marketplace",
    subtitle: 'Buy Medical Equipment, Healthcare Products, Diagnostic Devices, Hospital Supplies and More',
    linkTo: 'shop'
  },
  {
    id: 'b-2',
    imageUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=1200',
    title: 'Equip Your Clinic with ICU Grade Monitors',
    subtitle: 'Super Admin Approved, 100% Verified Healthcare Suppliers and Secure Payments',
    linkTo: 'category/icu-equip'
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'r-1',
    productId: 'p-1',
    productName: 'Multi-parameter ICU Patient Monitor V12',
    customerName: 'Fortis Hospital Procurement (Kolkata)',
    rating: 5,
    comment: 'Exceptional build quality. Readings exactly match clinical standards. Highly recommended supplier Apex!',
    createdAt: '2026-06-20',
    approved: true
  },
  {
    id: 'r-2',
    productId: 'p-2',
    productName: 'Automatic Digital Blood Pressure Monitor Pro',
    customerName: 'Dr. Anita Joshi',
    rating: 4,
    comment: 'Very easy to use for elder patients. Fits standard cuffs perfectly. Quick shipping.',
    createdAt: '2026-06-25',
    approved: true
  },
  {
    id: 'r-3',
    productId: 'p-3',
    productName: 'Premium OLED Pulse Oximeter Pro-X',
    customerName: 'Nitin Sharma',
    rating: 5,
    comment: 'Bright OLED, batteries included. Very accurate readings of heart beats.',
    createdAt: '2026-07-01',
    approved: true
  }
];

export const INITIAL_SUPPORT_TICKETS: SupportTicket[] = [
  {
    id: 't-1',
    userId: 'cust-101',
    userName: 'Karan Mehra',
    userRole: 'Customer',
    subject: 'Order Delay for ICU Bed',
    category: 'Delivery',
    status: 'Replied',
    createdAt: '2026-07-08',
    messages: [
      { sender: 'User', text: 'Hello, my ICU bed order is showing processing for 3 days. Any updates?', timestamp: '2026-07-08 10:00' },
      { sender: 'Admin', text: 'Dear Karan, we verified with Apex Hospital Systems. The bed is currently being safely packed and will be shipped today. Tracking will update shortly.', timestamp: '2026-07-08 15:30' }
    ]
  },
  {
    id: 't-2',
    userId: 'vendor-2',
    userName: 'HealLife Medical Supplies',
    userRole: 'Vendor',
    subject: 'Clarification regarding Gel cushion category commission',
    category: 'Commission',
    status: 'Open',
    createdAt: '2026-07-10',
    messages: [
      { sender: 'User', text: 'Hi Admin, I see the commission for Gel seat cushion is showing 10%. Can we get an discount waiver for home healthcare items?', timestamp: '2026-07-10 11:15' }
    ]
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'HN-ORD-1024',
    customerId: 'cust-101',
    customerName: 'Karan Mehra',
    billingDetails: {
      name: 'Karan Mehra',
      mobile: '+91 99887 22110',
      email: 'karan@outlook.com',
      address: 'Apt 4B, Skyview Towers, Koramangala',
      state: 'Karnataka',
      city: 'Bengaluru',
      pinCode: '560034'
    },
    paymentMethod: 'UPI (GPay)',
    paymentStatus: 'Paid',
    items: [
      {
        productId: 'p-2',
        productName: 'Automatic Digital Blood Pressure Monitor Pro',
        vendorId: 'vendor-3',
        vendorName: 'Global Diagnostic Instruments',
        quantity: 2,
        unitPrice: 1980,
        sellingPrice: 1800,
        commissionAmount: 180,
        total: 3960
      },
      {
        productId: 'p-3',
        productName: 'Premium OLED Pulse Oximeter Pro-X',
        vendorId: 'vendor-3',
        vendorName: 'Global Diagnostic Instruments',
        quantity: 1,
        unitPrice: 935,
        sellingPrice: 850,
        commissionAmount: 85,
        total: 935
      }
    ],
    subtotal: 4895,
    discount: 500, // MEDBAZAR500 applied
    total: 4395,
    status: 'Delivered',
    createdAt: '2026-07-05',
    courierName: 'Delhivery',
    trackingNumber: 'DLV99023451'
  },
  {
    id: 'HN-ORD-1025',
    customerId: 'cust-102',
    customerName: 'LifeLine Pharmacy Care',
    billingDetails: {
      name: 'Dr. Somesh Das',
      mobile: '+91 91234 56789',
      email: 's.das@lifelinepharmacy.com',
      address: 'Ground Floor, Plot 12, Gariahat Road',
      state: 'West Bengal',
      city: 'Kolkata',
      pinCode: '700019'
    },
    paymentMethod: 'Net Banking (ICICI)',
    paymentStatus: 'Paid',
    items: [
      {
        productId: 'p-1',
        productName: 'Multi-parameter ICU Patient Monitor V12',
        vendorId: 'vendor-1',
        vendorName: 'Apex Hospital Systems',
        quantity: 1,
        unitPrice: 46200,
        sellingPrice: 42000,
        commissionAmount: 4200,
        total: 46200
      }
    ],
    subtotal: 46200,
    discount: 0,
    total: 46200,
    status: 'Shipped',
    createdAt: '2026-07-10',
    courierName: 'BlueDart Air',
    trackingNumber: 'BD982341235'
  }
];

export const CMS_PAGES: CMSPage[] = [
  {
    slug: 'about-us',
    title: 'About HealNex Med Bazar',
    content: 'HealNex Med Bazar is India\'s trusted Multi-Vendor Medical & Healthcare Marketplace connecting healthcare providers, hospitals, medical professionals, and clinics with verified healthcare manufacturers, distributors, and suppliers. Our mission is to democratize high-quality medical supply chains and ensure complete transparency with Super Admin verification, standardized commission processing, and live tracking of heavy-duty medical devices.'
  },
  {
    slug: 'contact-us',
    title: 'Contact Support Hub',
    content: 'Reach our Dedicated Healthcare Helpline: 1800-HEALNEX (1800-432-5639).\nEmail: corporate@healnexmedbazar.in\nHeadquarters: Tower B, DLF Tech Park, Phase II, Gurugram, Haryana - 122002.'
  },
  {
    slug: 'faq',
    title: 'Frequently Asked Questions (FAQ)',
    content: 'Q: How are vendors verified?\nA: Every vendor is manually audited by the HealNex Super Admin. Trade Licenses and GST certifications are required before a vendor is approved to sell.\n\nQ: How is the customer price calculated?\nA: The customer price is calculated automatically. Selling Price (entered by vendor) + Admin Commission (defined per category or vendor) = Customer Price.\n\nQ: Can hospitals buy in bulk?\nA: Yes, hospital procurement centers can order high volumes, and payment options include Credit/Debit card, UPI, and Net Banking.'
  },
  {
    slug: 'privacy-policy',
    title: 'Privacy Policy',
    content: 'HealNex Med Bazar prioritizes data protection for all hospitals, medical specialists, and patients. All health credentials, financial transactions, and billing details are securely encrypted and protected under HIPAA and Indian Digital Health standards.'
  },
  {
    slug: 'terms-and-conditions',
    title: 'Terms & Conditions',
    content: 'By using HealNex Med Bazar, vendors agree to present authentic clinical-grade medical hardware. Admin reserves all rights to suspend vendors failing Trade License specifications.'
  },
  {
    slug: 'return-policy',
    title: 'Return Policy',
    content: 'Medical equipment and sterile surgical instruments are subject to specialized returns. Damaged components or non-conforming items can be logged for return within 7 working days with proper unboxing video documentation.'
  },
  {
    slug: 'vendor-policy',
    title: 'Vendor Policy & Guidelines',
    content: 'All suppliers must upload standard Trade Licenses and maintain active stock. Delivery requires valid tracking numbers and courier verification.'
  }
];

// LocalStorage helpers
export const getStoredData = <T>(key: string, initial: T): T => {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : initial;
  } catch (e) {
    return initial;
  }
};

export const setStoredData = <T>(key: string, data: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error('Error saving storage', e);
  }
};
